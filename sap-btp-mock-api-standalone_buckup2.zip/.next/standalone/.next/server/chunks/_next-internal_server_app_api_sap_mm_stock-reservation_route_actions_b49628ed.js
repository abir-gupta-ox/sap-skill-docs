module.exports=[67460,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sap_mm_stock-reservation_route_actions_b49628ed.js.map