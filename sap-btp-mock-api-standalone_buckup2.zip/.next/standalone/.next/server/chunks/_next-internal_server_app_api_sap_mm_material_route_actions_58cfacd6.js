module.exports=[20743,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sap_mm_material_route_actions_58cfacd6.js.map