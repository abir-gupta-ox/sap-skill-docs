module.exports=[18244,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sap_mm_material-stock_route_actions_d64ce183.js.map