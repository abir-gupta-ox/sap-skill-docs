module.exports=[51652,(e,o,d)=>{}];

//# sourceMappingURL=bec2d_app_sap_opu_odata_sap_API_RESERVATION_SRV_A_Reservation_route_actions_63986528.js.map