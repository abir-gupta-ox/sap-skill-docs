module.exports=[16366,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sap_mm_goods-movement_route_actions_7b11f1d6.js.map