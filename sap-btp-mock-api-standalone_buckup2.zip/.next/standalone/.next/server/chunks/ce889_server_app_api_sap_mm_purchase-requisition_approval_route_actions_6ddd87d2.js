module.exports=[26685,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_sap_mm_purchase-requisition_approval_route_actions_6ddd87d2.js.map