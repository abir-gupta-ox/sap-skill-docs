module.exports=[57493,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sap_mm_purchase-order_route_actions_77b4517c.js.map