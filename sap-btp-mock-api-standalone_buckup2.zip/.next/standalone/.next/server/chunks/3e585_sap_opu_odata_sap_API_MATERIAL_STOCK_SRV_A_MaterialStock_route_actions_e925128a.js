module.exports=[61580,(e,o,d)=>{}];

//# sourceMappingURL=3e585_sap_opu_odata_sap_API_MATERIAL_STOCK_SRV_A_MaterialStock_route_actions_e925128a.js.map