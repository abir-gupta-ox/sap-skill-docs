module.exports=[77278,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sap_mm_purchase-requisition_route_actions_8e2592c8.js.map