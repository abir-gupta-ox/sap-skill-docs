module.exports=[50240,(e,o,d)=>{}];

//# sourceMappingURL=96888_odata_sap_API_PURCHASEORDER_PROCESS_SRV_A_PurchaseOrder_route_actions_f605a25e.js.map