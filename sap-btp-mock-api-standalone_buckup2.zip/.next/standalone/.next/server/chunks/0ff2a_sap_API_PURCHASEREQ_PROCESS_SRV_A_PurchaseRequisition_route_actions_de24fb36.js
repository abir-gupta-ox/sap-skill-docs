module.exports=[5694,(e,o,d)=>{}];

//# sourceMappingURL=0ff2a_sap_API_PURCHASEREQ_PROCESS_SRV_A_PurchaseRequisition_route_actions_de24fb36.js.map