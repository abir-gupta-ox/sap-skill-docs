module.exports=[23789,(e,o,d)=>{}];

//# sourceMappingURL=bec2d_app_sap_opu_odata_sap_API_GOODSMVT_SRV_A_GoodsMovement_route_actions_35cbc0c3.js.map