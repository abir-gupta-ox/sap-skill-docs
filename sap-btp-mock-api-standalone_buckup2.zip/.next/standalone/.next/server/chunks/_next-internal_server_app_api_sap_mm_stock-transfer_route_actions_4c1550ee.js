module.exports=[31668,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sap_mm_stock-transfer_route_actions_4c1550ee.js.map