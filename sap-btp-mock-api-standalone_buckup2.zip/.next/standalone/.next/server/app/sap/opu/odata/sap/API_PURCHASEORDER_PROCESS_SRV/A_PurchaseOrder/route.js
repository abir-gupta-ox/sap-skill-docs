var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/sap/opu/odata/sap/API_PURCHASEORDER_PROCESS_SRV/A_PurchaseOrder/route.js")
R.c("server/chunks/[root-of-the-server]__8d4307b8._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/96888_odata_sap_API_PURCHASEORDER_PROCESS_SRV_A_PurchaseOrder_route_actions_f605a25e.js")
R.m(82431)
module.exports=R.m(82431).exports
