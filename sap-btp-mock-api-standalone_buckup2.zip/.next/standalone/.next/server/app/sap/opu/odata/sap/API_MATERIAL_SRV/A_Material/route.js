var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/sap/opu/odata/sap/API_MATERIAL_SRV/A_Material/route.js")
R.c("server/chunks/[root-of-the-server]__d9d3445a._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/ce889_server_app_sap_opu_odata_sap_API_MATERIAL_SRV_A_Material_route_actions_2e99f4b8.js")
R.m(34621)
module.exports=R.m(34621).exports
