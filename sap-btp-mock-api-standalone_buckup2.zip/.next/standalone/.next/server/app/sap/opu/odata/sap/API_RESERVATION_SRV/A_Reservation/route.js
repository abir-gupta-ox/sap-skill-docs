var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/sap/opu/odata/sap/API_RESERVATION_SRV/A_Reservation/route.js")
R.c("server/chunks/[root-of-the-server]__e3587990._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/bec2d_app_sap_opu_odata_sap_API_RESERVATION_SRV_A_Reservation_route_actions_63986528.js")
R.m(18195)
module.exports=R.m(18195).exports
