var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/sap/opu/odata/sap/API_MATERIAL_STOCK_SRV/A_MaterialStock/route.js")
R.c("server/chunks/[root-of-the-server]__4774c595._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/3e585_sap_opu_odata_sap_API_MATERIAL_STOCK_SRV_A_MaterialStock_route_actions_e925128a.js")
R.m(18799)
module.exports=R.m(18799).exports
