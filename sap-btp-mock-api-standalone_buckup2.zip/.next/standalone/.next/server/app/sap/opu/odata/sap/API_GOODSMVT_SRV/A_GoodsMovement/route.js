var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/sap/opu/odata/sap/API_GOODSMVT_SRV/A_GoodsMovement/route.js")
R.c("server/chunks/[root-of-the-server]__f57f1e84._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/bec2d_app_sap_opu_odata_sap_API_GOODSMVT_SRV_A_GoodsMovement_route_actions_35cbc0c3.js")
R.m(52789)
module.exports=R.m(52789).exports
