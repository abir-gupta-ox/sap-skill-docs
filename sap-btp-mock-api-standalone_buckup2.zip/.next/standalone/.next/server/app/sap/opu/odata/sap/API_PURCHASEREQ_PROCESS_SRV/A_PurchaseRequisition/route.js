var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/sap/opu/odata/sap/API_PURCHASEREQ_PROCESS_SRV/A_PurchaseRequisition/route.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__df63855d._.js")
R.c("server/chunks/0ff2a_sap_API_PURCHASEREQ_PROCESS_SRV_A_PurchaseRequisition_route_actions_de24fb36.js")
R.m(35559)
module.exports=R.m(35559).exports
