var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sap/mm/material/route.js")
R.c("server/chunks/[root-of-the-server]__a8b66302._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/_next-internal_server_app_api_sap_mm_material_route_actions_58cfacd6.js")
R.m(99938)
module.exports=R.m(99938).exports
