var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sap/mm/stock-reservation/route.js")
R.c("server/chunks/[root-of-the-server]__7960a5ff._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/_next-internal_server_app_api_sap_mm_stock-reservation_route_actions_b49628ed.js")
R.m(27756)
module.exports=R.m(27756).exports
