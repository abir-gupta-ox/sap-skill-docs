var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sap/mm/purchase-requisition/route.js")
R.c("server/chunks/[root-of-the-server]__c50c64f1._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/_next-internal_server_app_api_sap_mm_purchase-requisition_route_actions_8e2592c8.js")
R.m(38482)
module.exports=R.m(38482).exports
