var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sap/mm/goods-movement/route.js")
R.c("server/chunks/[root-of-the-server]__1b8ae906._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/_next-internal_server_app_api_sap_mm_goods-movement_route_actions_7b11f1d6.js")
R.m(35225)
module.exports=R.m(35225).exports
