var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sap/mm/material-stock/route.js")
R.c("server/chunks/[root-of-the-server]__09f21cf1._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/_next-internal_server_app_api_sap_mm_material-stock_route_actions_d64ce183.js")
R.m(28467)
module.exports=R.m(28467).exports
