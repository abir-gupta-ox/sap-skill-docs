var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sap/mm/purchase-order/route.js")
R.c("server/chunks/[root-of-the-server]__f9cbd36f._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/_next-internal_server_app_api_sap_mm_purchase-order_route_actions_77b4517c.js")
R.m(47869)
module.exports=R.m(47869).exports
