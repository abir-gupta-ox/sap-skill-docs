var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sap/mm/stock-transfer/route.js")
R.c("server/chunks/[root-of-the-server]__4d3c534f._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/_next-internal_server_app_api_sap_mm_stock-transfer_route_actions_4c1550ee.js")
R.m(1065)
module.exports=R.m(1065).exports
