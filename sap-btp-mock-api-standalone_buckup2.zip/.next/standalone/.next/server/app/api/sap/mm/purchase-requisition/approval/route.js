var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sap/mm/purchase-requisition/approval/route.js")
R.c("server/chunks/[root-of-the-server]__6d3f4e92._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__959558ae._.js")
R.c("server/chunks/ce889_server_app_api_sap_mm_purchase-requisition_approval_route_actions_6ddd87d2.js")
R.m(78724)
module.exports=R.m(78724).exports
