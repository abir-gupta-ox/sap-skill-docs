1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/2f236954d6a65e12.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/2f236954d6a65e12.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"M2HzwoSJ4FzQRAE-eeHCk","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[]}]}]}],null]}],"loading":null,"isPartial":false}
