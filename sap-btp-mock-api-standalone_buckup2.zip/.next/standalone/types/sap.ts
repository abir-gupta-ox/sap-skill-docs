export type ModuleKey = 'MM' | 'PM' | 'FI' | 'CO' | 'SD' | 'EWM' | 'BTP' | 'EHS' | 'HCM' | 'OPS';

export type MMTabKey = 'material' | 'purchase-requisition' | 'goods-movement' | 'purchase-order' | 'stock-reservation';

export interface SAPModule {
  code: string;
  name: string;
  icon: string;
  count: number;
  available: boolean;
}

export interface MMTab {
  key: MMTabKey;
  label: string;
  icon: string;
  endpoint: string;
  available: boolean;
}

export interface SAPMaterial {
  MATNR: string;
  MTART: string;
  MATKL: string;
  MAKTX: string;
  MEINS: string;
  WERKS: string;
  EISBE: number;
  STPRS: number;
  WAERS: string;
  ZZSYNC_STATUS: string;
}

export interface SAPPurchaseRequisition {
  BANFN: string;              // Purchase Requisition Number
  BNFPO: string;              // Item Number
  BSART: string;              // Document Type
  BADAT: string;              // Requisition Date
  ERNAM: string;              // Created By
  MATNR?: string;             // Material Number
  TXZ01: string;              // Short Text/Description
  MENGE: number;              // Quantity
  MEINS: string;              // Unit of Measure
  LFDAT?: string;             // Delivery Date
  WERKS: string;              // Plant
  EKGRP: string;              // Purchasing Group
  EKORG: string;              // Purchasing Organization
  PREIS?: number;             // Estimated Price
  WAERS?: string;             // Currency
  KNTTP?: string;             // Account Assignment Category
  AUFNR?: string;             // Work Order Number
  STATU: string;              // Processing Status
  ZZOXMAINT_WO_REF?: string;  // OXmaint Work Order Reference
  ZZSYNC_STATUS: string;      // Sync Status
  ZZSAP_DOC_NO: string;       // SAP Document Number
}

export interface SAPGoodsReceipt {
  MBLNR: string;              // Material Document Number
  MJAHR: string;              // Material Document Year
  ZEILE: string;              // Item Number
  BLDAT: string;              // Document Date
  BUDAT: string;              // Posting Date
  USNAM: string;              // Created By
  BWART: string;              // Movement Type
  MATNR: string;              // Material Number
  WERKS: string;              // Plant
  LGORT: string;              // Storage Location
  MENGE: number;              // Quantity
  MEINS: string;              // Unit of Measure
  EBELN?: string;             // Purchase Order Number
  AUFNR?: string;             // Work Order Number
  DMBTR?: number;             // Amount
  WAERS?: string;             // Currency
  CHARG?: string;             // Batch Number
  SGTXT?: string;             // Item Text
  ZZOXMAINT_WO_REF?: string;  // OXmaint Work Order Reference
  ZZSYNC_STATUS: string;      // Sync Status
  ZZSAP_DOC_NO: string;       // SAP Document Number
}

export interface SAPPurchaseOrder {
  EBELN: string;              // PO Number
  EBELP: string;              // PO Item Number
  BSART: string;              // Document Type
  STATU?: string;             // Status
  ERNAM: string;              // Created By
  ERDAT: string;              // Created On
  LIFNR: string;              // Vendor Number
  EKORG: string;              // Purchasing Organization
  EKGRP: string;              // Purchasing Group
  WAERS: string;              // Currency
  BEDAT: string;              // PO Date
  MATNR?: string;             // Material Number
  TXZ01: string;              // Short Text
  MENGE: number;              // PO Quantity
  MEINS: string;              // Unit of Measure
  NETPR: number;              // Net Price
  NETWR: number;              // Net Value
  EINDT?: string;             // Delivery Date
  WERKS: string;              // Plant
  BANFN?: string;             // PR Number (source)
  BNFPO?: string;             // PR Item Number (source)
  AUFNR?: string;             // Work Order Number
  ZZOXMAINT_WO_REF?: string;  // OXmaint Work Order Reference
  ZZSYNC_STATUS: string;      // Sync Status
  ZZSAP_DOC_NO: string;       // SAP Document Number
}

export interface SAPStockReservation {
  RSNUM: string;              // Reservation Number
  RSPOS: string;              // Reservation Item Number
  MATNR?: string;             // Material Number
  WERKS: string;              // Plant
  LGORT?: string;             // Storage Location
  BDMNG: number;              // Required Quantity
  MEINS: string;              // Unit of Measure
  BDTER: string;              // Requirement Date
  BWART?: string;             // Movement Type
  AUFNR?: string;             // Work Order Number
  ZZOXMAINT_WO_REF?: string;  // OXmaint Work Order Reference
  ZZSYNC_STATUS: string;      // Sync Status
  ZZSAP_DOC_NO: string;       // SAP Document Number
}

export const SAP_MODULES: Record<ModuleKey, SAPModule> = {
  MM: { code: 'MM', name: 'Materials Management', icon: '📦', count: 0, available: true },
  PM: { code: 'PM', name: 'Plant Maintenance', icon: '🔧', count: 0, available: false },
  FI: { code: 'FI', name: 'Finance', icon: '💰', count: 0, available: false },
  CO: { code: 'CO', name: 'Controlling', icon: '📊', count: 0, available: false },
  SD: { code: 'SD', name: 'Sales & Distribution', icon: '🛒', count: 0, available: false },
  EWM: { code: 'EWM', name: 'Warehouse Management', icon: '🏭', count: 0, available: false },
  BTP: { code: 'BTP', name: 'SAP BTP Integration', icon: '☁️', count: 0, available: false },
  EHS: { code: 'EHS', name: 'Environment, Health & Safety', icon: '🛡️', count: 0, available: false },
  HCM: { code: 'HCM', name: 'Human Capital Mgmt', icon: '👥', count: 0, available: false },
  OPS: { code: 'OPS', name: 'Operations', icon: '⚙️', count: 0, available: false },
};

export const MM_TABS: MMTab[] = [
  { key: 'material', label: 'Material', icon: '📦', endpoint: '/api/sap/mm/material', available: true },
  { key: 'purchase-requisition', label: 'Purchase Requisition', icon: '📋', endpoint: '/api/sap/mm/purchase-requisition', available: true },
  { key: 'goods-movement', label: 'Goods Movement', icon: '📦', endpoint: '/api/sap/mm/goods-movement', available: true },
  { key: 'purchase-order', label: 'Purchase Order', icon: '🛍️', endpoint: '/api/sap/mm/purchase-order', available: true },
  { key: 'stock-reservation', label: 'Stock Reservation', icon: '🧾', endpoint: '/api/sap/mm/stock-reservation', available: true },
];
