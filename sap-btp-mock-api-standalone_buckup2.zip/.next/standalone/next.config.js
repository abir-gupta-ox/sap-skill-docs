/** @type {import('next').NextConfig} */
const nextConfig = {
  // Enable standalone output for SAP BTP deployment
  output: 'standalone',

  // API routes only - no React pages needed
  reactStrictMode: true,

  // CORS headers for cross-origin requests
  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          { key: 'Access-Control-Allow-Credentials', value: 'true' },
          { key: 'Access-Control-Allow-Origin', value: '*' },
          { key: 'Access-Control-Allow-Methods', value: 'GET, POST, PUT, DELETE, OPTIONS' },
          { key: 'Access-Control-Allow-Headers', value: 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization, X-SAP-Client, X-Organization-Id' },
        ],
      },
    ];
  },

  // Ensure local data files are bundled into the standalone output
  outputFileTracingIncludes: {
    '*': ['data/**', 'lib/**'],
  },
};

module.exports = nextConfig;
