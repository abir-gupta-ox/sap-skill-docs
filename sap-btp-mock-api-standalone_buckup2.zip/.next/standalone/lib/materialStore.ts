// JSON-backed store for materials (simulates SAP database with persistence)
// In production, this would connect to SAP S/4HANA via RFC or OData
// Field names align with SAP MM (Material Master) transaction codes MM01/MM02/MM03

import db from './database';

export interface SAPMaterial {
  // Basic Data 1 (MM01 - Basic Data view)
  MATNR: string;              // Material Number
  MTART: string;              // Material Type
  MATKL: string;              // Material Group
  MAKTX: string;              // Material Description
  MEINS: string;              // Base Unit of Measure
  MAKTG?: string;             // Material Description (uppercase)
  BISMT?: string;             // Old Material Number
  EAN11?: string;             // International Article Number (EAN/UPC)
  NUMTP?: string;             // Category of International Article Number
  BRGEW?: number;             // Gross Weight
  NTGEW?: number;             // Net Weight
  GEWEI?: string;             // Weight Unit
  VOLUM?: number;             // Volume
  VOLEH?: string;             // Volume Unit
  GROES?: string;             // Size/Dimensions

  // Plant Data / MRP (MM01 - MRP views)
  WERKS: string;              // Plant
  LGORT: string;              // Storage Location
  DISMM: string;              // MRP Type
  DISLS: string;              // Lot Size
  MINBE: number;              // Reorder Point
  EISBE: number;              // Safety Stock
  PLIFZ: number;              // Planned Delivery Time (days)
  WEBAZ?: number;             // Goods Receipt Processing Time
  FHORI?: string;             // Scheduling Margin Key
  DISPO?: string;             // MRP Controller
  DISPR?: string;             // MRP Profile
  BESKZ?: string;             // Procurement Type (E=In-house, F=External)
  SOBSL?: string;             // Special Procurement Type
  RGEKZ?: string;             // Backflush Indicator
  FEVOR?: string;             // Production Scheduler

  // Purchasing (MM01 - Purchasing view)
  EKGRP?: string;             // Purchasing Group
  KORDB?: boolean;            // Source List Requirement
  MFRGR?: string;             // Material Freight Group

  // Accounting (MM01 - Accounting views)
  BKLAS?: string;             // Valuation Class
  VPRSV?: string;             // Price Control (S=Standard, V=Moving Avg)
  VERPR?: number;             // Moving Average Price
  STPRS?: number;             // Standard Price
  PEINH?: number;             // Price Unit
  WAERS?: string;             // Currency

  // Administrative Data
  ERNAM: string;              // Created By
  ERSDA: string;              // Created On (YYYYMMDD)
  LAEDA: string;              // Last Changed On (YYYYMMDD)
  AENAM: string;              // Changed By
  LVORM?: boolean;            // Deletion Flag

  // Custom/Extension Fields for OXmaint Integration
  ZZOXMAINT_REF?: string;     // OXmaint Reference ID
  ZZSYNC_STATUS: 'PENDING' | 'SYNCED' | 'ERROR';  // Sync Status
  ZZSAP_DOC_NO: string;       // SAP Document Number
}

// Request interface using SAP field names
export interface MaterialCreateRequest {
  MATNR?: string;             // Material Number (optional - auto-generated if not provided)
  MTART: string;              // Material Type
  MATKL: string;              // Material Group
  MAKTX: string;              // Material Description
  MEINS: string;              // Base Unit of Measure
  WERKS: string;              // Plant
  LGORT: string;              // Storage Location
  DISMM?: string;             // MRP Type
  DISLS?: string;             // Lot Size
  EISBE?: number;             // Safety Stock
  MINBE?: number;             // Reorder Point
  PLIFZ?: number;             // Planned Delivery Time
  BRGEW?: number;             // Gross Weight
  NTGEW?: number;             // Net Weight
  GEWEI?: string;             // Weight Unit
  BKLAS?: string;             // Valuation Class
  VPRSV?: string;             // Price Control
  STPRS?: number;             // Standard Price
  WAERS?: string;             // Currency
  EKGRP?: string;             // Purchasing Group
  DISPO?: string;             // MRP Controller
  ZZOXMAINT_REF?: string;     // OXmaint Reference ID
}

export interface SAPResponse<T = unknown> {
  d?: {                       // SAP OData response wrapper
    results?: T;
    __metadata?: {
      uri: string;
      type: string;
    };
  };
  success: boolean;
  message: string;
  data?: T;
  ZZSAP_DOC_NO?: string;      // SAP Document Number
  error?: {
    code: string;
    message: {
      lang: string;
      value: string;
    };
  };
  timestamp: string;
}

// Mock SAP Material Types (Table T134)
export const SAP_MATERIAL_TYPES: Record<string, string> = {
  HAWA: 'Trading Goods',
  FERT: 'Finished Product',
  HALB: 'Semi-Finished Product',
  ROH: 'Raw Material',
  ERSA: 'Spare Parts',
  NLAG: 'Non-Stock Material',
  VERP: 'Packaging Material',
  DIEN: 'Services',
};

// Mock SAP Material Groups (Table T023) - Istanbul Airport
export const SAP_MATERIAL_GROUPS: Record<string, string> = {
  'BHS': 'Baggage Handling Systems',
  'RWY': 'Runway & Taxiway Equipment',
  'TRM': 'Terminal Systems',
  'GSE': 'Ground Support Equipment',
  'ELE': 'Electrical Systems',
  'HVA': 'HVAC Systems',
  'SEC': 'Security Equipment',
  'SAF': 'Safety Equipment',
  'LGT': 'Lighting Systems',
  'PLB': 'Plumbing & Water Systems',
};

// Mock SAP Plants (Table T001W) - Istanbul Airport Locations
export const SAP_PLANTS: Record<string, string> = {
  'IST1': 'Terminal 1 - International',
  'IST2': 'Terminal 2 - Domestic',
  'ISTC': 'Cargo Terminal',
  'ISTM': 'Maintenance Hangar',
  'ISTR': 'Runway Operations',
};

// Mock SAP Storage Locations (Table T001L) - Istanbul Airport
export const SAP_STORAGE_LOCATIONS: Record<string, string> = {
  'WH01': 'Main Warehouse',
  'WH02': 'Terminal Storage',
  'WH03': 'Airside Storage',
  'WH04': 'Emergency Stock',
  'WH05': 'Maintenance Bay',
};

// Mock SAP Units of Measure (Table T006)
export const SAP_UNITS: Record<string, string> = {
  EA: 'Each',
  PC: 'Piece',
  KG: 'Kilogram',
  G: 'Gram',
  L: 'Liter',
  M: 'Meter',
  M2: 'Square Meter',
  M3: 'Cubic Meter',
  BOX: 'Box',
  PAL: 'Pallet',
};

// =====================================================
// PURCHASE REQUISITION (ME51N/ME52N/ME53N) - SAP MM-PUR
// =====================================================

export const SAP_PR_DOCUMENT_TYPES: Record<string, string> = {
  'NB': 'Standard Purchase Requisition',
  'ZNB': 'Custom Purchase Requisition',
  'ZSER': 'Service Purchase Requisition',
  'ZSTO': 'Stock Transport Requisition',
  'ZURG': 'Urgent Purchase Requisition',
};

export const SAP_PURCHASING_ORGS: Record<string, string> = {
  'P001': 'Istanbul Airport Procurement',
  'P002': 'Technical Services Procurement',
  'P003': 'Facility Management Procurement',
};

export const SAP_PURCHASING_GROUPS: Record<string, string> = {
  '001': 'Spare Parts Purchasing',
  '002': 'Equipment Purchasing',
  '003': 'Consumables Purchasing',
  '004': 'Services Purchasing',
  '005': 'Emergency Purchasing',
};

export const SAP_ACCOUNT_ASSIGNMENT_CATEGORIES: Record<string, string> = {
  '': 'No Account Assignment',
  'K': 'Cost Center',
  'F': 'Production/Maintenance Order',
  'P': 'Project (WBS Element)',
  'A': 'Asset',
  'N': 'Network',
};

export const SAP_PR_STATUS: Record<string, string> = {
  'N': 'New/Not Processed',
  'B': 'Blocked',
  'A': 'Released/Approved',
  'L': 'Locked',
  'X': 'Deleted',
};

export const SAP_PR_ITEM_CATEGORIES: Record<string, string> = {
  '0': 'Standard',
  '2': 'Consignment',
  '3': 'Subcontracting',
  '5': 'Third-Party',
  '7': 'Stock Transfer',
  '9': 'Service',
};

// Purchase Requisition Interface
export interface SAPPurchaseRequisition {
  BANFN: string;
  BNFPO: string;
  BSART: string;
  BADAT: string;
  ERNAM: string;
  ERDAT: string;
  MATNR?: string;
  TXZ01: string;
  MENGE: number;
  MEINS: string;
  LFDAT?: string;
  WERKS: string;
  LGORT?: string;
  EKGRP: string;
  EKORG: string;
  PREIS?: number;
  PEINH?: number;
  WAERS?: string;
  KNTTP?: string;
  KOSTL?: string;
  AUFNR?: string;
  PS_PSP_PNR?: string;
  SAKTO?: string;
  STATU: string;
  LOEKZ?: string;
  FRGKZ?: string;
  FRGST?: string;
  FRGZU?: string;
  BANPR?: string;
  FLIEF?: string;
  LIFNR?: string;
  PSTYP?: string;
  ZZOXMAINT_WO_REF?: string;
  ZZOXMAINT_WO_LINE?: string;
  ZZSYNC_STATUS: 'PENDING' | 'SYNCED' | 'ERROR';
  ZZSAP_DOC_NO: string;
  AENAM?: string;
  AEDAT?: string;
  // Approval-related fields
  FRGDT?: string;             // Release Date (YYYYMMDD)
  FRGRL?: string;             // Release Has Occurred (X = yes)
  FRGGR?: string;             // Release Group
  FRGCO?: string;             // Release Code
  // Custom approval fields for OXmaint integration
  ZZAPPROVER_ID?: string;     // Approver User ID
  ZZAPPROVER_NAME?: string;   // Approver Name
  ZZAPPROVAL_NOTES?: string;  // Approval Notes/Comments
  ZZAPPROVAL_LEVEL?: number;  // Approval Level (1, 2, 3, etc.)
}

export interface PurchaseRequisitionCreateRequest {
  BANFN?: string;
  BNFPO?: string;
  BSART: string;
  MATNR?: string;
  TXZ01: string;
  MENGE: number;
  MEINS: string;
  WERKS: string;
  EKGRP: string;
  EKORG: string;
  LFDAT?: string;
  LGORT?: string;
  PREIS?: number;
  WAERS?: string;
  BANPR?: string;
  KNTTP?: string;
  KOSTL?: string;
  AUFNR?: string;
  PS_PSP_PNR?: string;
  SAKTO?: string;
  LIFNR?: string;
  PSTYP?: string;
  ZZOXMAINT_WO_REF?: string;
  ZZOXMAINT_WO_LINE?: string;
}

// =====================================================
// PURCHASE ORDER (ME21N/ME23N) - SAP MM-PUR
// =====================================================

// SAP PO Document Types (BSART)
export const SAP_PO_DOC_TYPES: Record<string, string> = {
  'NB': 'Standard PO',
  'FO': 'Framework Order',
  'UB': 'Stock Transport Order',
  'ZNB': 'Custom Standard PO',
  'ZNBS': 'Service PO',
};

// SAP PO Status
export const SAP_PO_STATUS: Record<string, string> = {
  'O': 'Open',
  'P': 'Partially Delivered',
  'C': 'Completed',
  'X': 'Deleted',
  'B': 'Blocked',
};

// SAP PO Item Category (PSTYP)
export const SAP_PO_ITEM_CATEGORY: Record<string, string> = {
  '0': 'Standard',
  '2': 'Consignment',
  '3': 'Subcontracting',
  '5': 'Third-Party',
  '7': 'Service',
  '9': 'Limit',
};

export interface SAPPurchaseOrder {
  EBELN: string;              // PO Number
  EBELP: string;              // PO Item Number
  BSART: string;              // Document Type
  BSTYP?: string;             // Document Category
  LOEKZ?: string;             // Deletion Indicator
  STATU?: string;             // Status
  AEDAT?: string;             // Changed On
  ERNAM: string;              // Created By
  ERDAT: string;              // Created On
  LIFNR: string;              // Vendor Number
  EKORG: string;              // Purchasing Organization
  EKGRP: string;              // Purchasing Group
  WAERS: string;              // Currency
  WKURS?: number;             // Exchange Rate
  BEDAT: string;              // PO Date
  KDATB?: string;             // Start of Validity
  KDATE?: string;             // End of Validity
  BWTAR?: string;             // Valuation Type
  MATNR?: string;             // Material Number
  TXZ01: string;              // Short Text
  MENGE: number;              // PO Quantity
  MEINS: string;              // Unit of Measure
  NETPR: number;              // Net Price
  PEINH: number;              // Price Unit
  NETWR: number;              // Net Value
  BRTWR?: number;             // Gross Value
  MWSKZ?: string;             // Tax Code
  MWSTZ?: number;             // Tax Rate
  EINDT?: string;             // Delivery Date
  LFDAT?: string;             // Requested Delivery Date
  WERKS: string;              // Plant
  LGORT?: string;             // Storage Location
  MATKL?: string;             // Material Group
  INFNR?: string;             // Info Record Number
  PSTYP?: string;             // Item Category
  KNTTP?: string;             // Account Assignment Category
  KOSTL?: string;             // Cost Center
  AUFNR?: string;             // Order Number (Work Order)
  SAKTO?: string;             // GL Account
  PS_PSP_PNR?: string;        // WBS Element
  // PR Reference
  BANFN?: string;             // PR Number
  BNFPO?: string;             // PR Item Number
  // Delivery tracking
  ELIKZ?: string;             // Delivery Completed Indicator
  EREKZ?: string;             // Invoice Receipt Indicator
  RETPO?: string;             // Return Item
  EMLIF?: number;             // Quantity Delivered
  WEPOS?: string;             // GR Indicator
  WEUNB?: string;             // GR Non-Valuated
  // OXmaint custom fields
  ZZOXMAINT_WO_REF?: string;  // OXmaint Work Order Reference
  ZZOXMAINT_WO_LINE?: string; // OXmaint Work Order Line ID
  ZZSYNC_STATUS: 'PENDING' | 'SYNCED' | 'ERROR';
  ZZSAP_DOC_NO: string;       // SAP Document Number
}

export interface PurchaseOrderCreateRequest {
  EBELN?: string;
  EBELP?: string;
  BSART?: string;
  LIFNR: string;
  EKORG: string;
  EKGRP: string;
  WAERS?: string;
  BEDAT?: string;
  MATNR?: string;
  TXZ01: string;
  MENGE: number;
  MEINS: string;
  NETPR: number;
  PEINH?: number;
  EINDT?: string;
  LFDAT?: string;
  WERKS: string;
  LGORT?: string;
  MATKL?: string;
  PSTYP?: string;
  KNTTP?: string;
  KOSTL?: string;
  AUFNR?: string;
  SAKTO?: string;
  PS_PSP_PNR?: string;
  BANFN?: string;
  BNFPO?: string;
  ZZOXMAINT_WO_REF?: string;
  ZZOXMAINT_WO_LINE?: string;
}

// =====================================================
// GOODS RECEIPT (MIGO) - SAP MM-IM
// =====================================================

export const SAP_MOVEMENT_TYPES: Record<string, string> = {
  '101': 'GR for Purchase Order',
  '103': 'GR for Production Order',
  '105': 'GR Free of Charge',
  '122': 'Return to Vendor',
  '161': 'GR for Maintenance Order',
  '201': 'Goods Issue for Cost Center',
  '221': 'Goods Issue for Project',
  '261': 'Goods Issue for Order',
  '301': 'Plant Transfer - Receiving',
  '311': 'Storage Location Transfer - Receiving',
  '501': 'Receipt without Purchase Order',
  '561': 'Initial Entry of Stock',
};

export interface SAPGoodsReceipt {
  MBLNR: string;
  MJAHR: string;
  ZEILE: string;
  BLDAT: string;
  BUDAT: string;
  USNAM: string;
  TCODE?: string;
  BKTXT?: string;
  BWART: string;
  MATNR: string;
  WERKS: string;
  LGORT: string;
  MENGE: number;
  MEINS: string;
  ERFMG?: number;
  ERFME?: string;
  EBELN?: string;
  EBELP?: string;
  AUFNR?: string;
  RSNUM?: string;
  RSPOS?: string;
  LIFNR?: string;
  DMBTR?: number;
  WAERS?: string;
  EXBWR?: number;
  SHKZG?: string;
  SOBKZ?: string;
  KZBEW?: string;
  KZZUG?: string;
  KZVBR?: string;
  UMWRK?: string;
  UMLGO?: string;
  CHARG?: string;
  VFDAT?: string;
  SGTXT?: string;
  GRUND?: string;
  KOSTL?: string;
  CANCELLED?: boolean;
  XBLNR?: string;
  ZZOXMAINT_WO_REF?: string;
  ZZOXMAINT_INV_REF?: string;
  ZZSYNC_STATUS: 'PENDING' | 'SYNCED' | 'ERROR';
  ZZSAP_DOC_NO: string;
}

export interface GoodsReceiptCreateRequest {
  MBLNR?: string;
  MJAHR?: string;
  ZEILE?: string;
  BLDAT?: string;
  BUDAT?: string;
  BKTXT?: string;
  BWART: string;
  MATNR: string;
  WERKS: string;
  LGORT: string;
  MENGE: number;
  MEINS: string;
  EBELN?: string;
  EBELP?: string;
  AUFNR?: string;
  RSNUM?: string;
  RSPOS?: string;
  LIFNR?: string;
  DMBTR?: number;
  WAERS?: string;
  EXBWR?: number;
  UMWRK?: string;
  UMLGO?: string;
  CHARG?: string;
  VFDAT?: string;
  SGTXT?: string;
  GRUND?: string;
  KOSTL?: string;
  XBLNR?: string;
  ZZOXMAINT_WO_REF?: string;
  ZZOXMAINT_INV_REF?: string;
}

// =====================================================
// STOCK RESERVATION (MB21/MB22/MB23) - SAP MM-IM
// =====================================================

export interface SAPStockReservation {
  RSNUM: string;              // Reservation Number
  RSPOS: string;              // Reservation Item Number
  MATNR?: string;             // Material Number
  WERKS: string;              // Plant
  LGORT?: string;             // Storage Location
  BDMNG: number;              // Required Quantity
  MEINS: string;              // Unit of Measure
  BDTER: string;              // Requirement Date (YYYYMMDD)
  BWART?: string;             // Movement Type
  AUFNR?: string;             // Work Order Number
  KOSTL?: string;             // Cost Center
  SGTXT?: string;             // Item Text
  ERNAM: string;              // Created By
  ERDAT: string;              // Created On
  AENAM?: string;             // Changed By
  AEDAT?: string;             // Changed On
  ZZOXMAINT_WO_REF?: string;  // OXmaint Work Order Reference
  ZZSYNC_STATUS: 'PENDING' | 'SYNCED' | 'ERROR';
  ZZSAP_DOC_NO: string;       // SAP Document Number
}

export interface StockReservationCreateRequest {
  RSNUM?: string;
  RSPOS?: string;
  MATNR?: string;
  WERKS?: string;
  LGORT?: string;
  BDMNG?: number;
  MEINS?: string;
  BDTER?: string;
  BWART?: string;
  AUFNR?: string;
  KOSTL?: string;
  SGTXT?: string;
  ZZOXMAINT_WO_REF?: string;
}

// Helper to format date as SAP format (YYYYMMDD)
const toSAPDate = (date: Date): string => {
  return date.toISOString().slice(0, 10).replace(/-/g, '');
};

// Generate document numbers
export const generateSAPDocumentNumber = (): string => {
  return (db.getMaxMaterialNumber() + 4890000000).toString();
};

export const generateMaterialNumber = (): string => {
  const sequence = db.getMaxMaterialNumber() + 1;
  return sequence.toString().padStart(18, '0');
};

export const generatePRNumber = (): string => {
  const sequence = db.getMaxPRNumber() + 1;
  return sequence.toString().padStart(10, '0');
};

export const generatePRItemNumber = (BANFN: string): string => {
  const prs = db.filterPurchaseRequisitions((pr) => pr.BANFN === BANFN);
  const maxItem = prs.reduce((max, pr) => Math.max(max, parseInt(String(pr.BNFPO) || '0', 10)), 0);
  return ((maxItem || 0) + 10).toString().padStart(5, '0');
};

export const generatePRDocumentNumber = (): string => {
  return (db.getMaxPRNumber() + 5000000000).toString();
};

export const generateMBLNR = (year: string): string => {
  const sequence = db.getMaxGRNumber(year) + 1;
  return sequence.toString().padStart(10, '0');
};

export const generateGRItemNumber = (MBLNR: string, MJAHR: string): string => {
  const grs = db.filterGoodsReceipts((gr) => gr.MBLNR === MBLNR && gr.MJAHR === MJAHR);
  const maxItem = grs.reduce((max, gr) => Math.max(max, parseInt(String(gr.ZEILE) || '0', 10)), 0);
  return (maxItem + 1).toString().padStart(4, '0');
};

export const generateGRDocumentNumber = (): string => {
  return (db.getMaxGRDocNo() + 1).toString();
};

export const generateReservationNumber = (): string => {
  const sequence = db.getMaxReservationNumber() + 1;
  return sequence.toString().padStart(10, '0');
};

export const generateReservationItemNumber = (RSNUM: string): string => {
  const items = db.filterStockReservations((res) => res.RSNUM === RSNUM);
  const maxItem = items.reduce((max, res) => Math.max(max, parseInt(String(res.RSPOS) || '0', 10)), 0);
  return ((maxItem || 0) + 10).toString().padStart(4, '0');
};

export const generateReservationDocumentNumber = (): string => {
  return (db.getMaxReservationDocNo() + 1).toString();
};

// Initialize with mock data if database is empty
const initializeMockData = () => {
  const materials = db.getMaterials();
  if (materials.length > 0) {
    console.log(`[JsonDB] Database already has ${materials.length} materials`);
    return;
  }

  console.log('[JsonDB] Initializing database with mock data...');

  const now = new Date();
  const sapDate = toSAPDate(now);

  const mockMaterials = [
    { MATNR: '000000000010000001', MTART: 'ERSA', MATKL: 'BHS', MAKTX: 'BHS Conveyor Belt 600mm Reinforced', MEINS: 'M', WERKS: 'IST1', LGORT: 'WH01', DISMM: 'PD', DISLS: 'EX', EISBE: 100, MINBE: 200, PLIFZ: 14, BRGEW: 8.5, NTGEW: 8.0, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'V', STPRS: 285.00, WAERS: 'TRY', EKGRP: '001', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000001' },
    { MATNR: '000000000010000002', MTART: 'ERSA', MATKL: 'BHS', MAKTX: 'Baggage Scanner Replacement Sensor', MEINS: 'EA', WERKS: 'IST1', LGORT: 'WH01', DISMM: 'PD', DISLS: 'EX', EISBE: 15, MINBE: 25, PLIFZ: 21, BRGEW: 2.5, NTGEW: 2.3, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'S', STPRS: 4500.00, WAERS: 'TRY', EKGRP: '001', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000002' },
    { MATNR: '000000000010000003', MTART: 'ERSA', MATKL: 'RWY', MAKTX: 'Runway Edge Light LED Unit', MEINS: 'EA', WERKS: 'ISTR', LGORT: 'WH03', DISMM: 'PD', DISLS: 'FX', EISBE: 50, MINBE: 100, PLIFZ: 30, BRGEW: 4.2, NTGEW: 3.8, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'S', STPRS: 8500.00, WAERS: 'TRY', EKGRP: '002', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000003' },
    { MATNR: '000000000010000004', MTART: 'ROH', MATKL: 'RWY', MAKTX: 'Runway De-icing Fluid Type I', MEINS: 'L', WERKS: 'ISTR', LGORT: 'WH03', DISMM: 'VB', DISLS: 'EX', EISBE: 5000, MINBE: 10000, PLIFZ: 7, BRGEW: 1.1, NTGEW: 1.0, GEWEI: 'KG', BKLAS: '3001', VPRSV: 'V', STPRS: 45.00, WAERS: 'TRY', EKGRP: '003', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000004' },
    { MATNR: '000000000010000005', MTART: 'ERSA', MATKL: 'GSE', MAKTX: 'GPU Cable Assembly 28VDC 1500A', MEINS: 'EA', WERKS: 'ISTM', LGORT: 'WH05', DISMM: 'PD', DISLS: 'EX', EISBE: 8, MINBE: 15, PLIFZ: 45, BRGEW: 25.0, NTGEW: 23.5, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'S', STPRS: 12500.00, WAERS: 'TRY', EKGRP: '001', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000005' },
    { MATNR: '000000000010000006', MTART: 'ERSA', MATKL: 'GSE', MAKTX: 'Pushback Tractor Hydraulic Pump', MEINS: 'EA', WERKS: 'ISTM', LGORT: 'WH05', DISMM: 'PD', DISLS: 'EX', EISBE: 3, MINBE: 5, PLIFZ: 60, BRGEW: 45.0, NTGEW: 42.0, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'S', STPRS: 28000.00, WAERS: 'TRY', EKGRP: '001', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000006' },
    { MATNR: '000000000010000007', MTART: 'ERSA', MATKL: 'TRM', MAKTX: 'Passenger Boarding Bridge Motor', MEINS: 'EA', WERKS: 'IST1', LGORT: 'WH02', DISMM: 'PD', DISLS: 'EX', EISBE: 4, MINBE: 6, PLIFZ: 90, BRGEW: 120.0, NTGEW: 115.0, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'S', STPRS: 95000.00, WAERS: 'TRY', EKGRP: '001', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000007' },
    { MATNR: '000000000010000008', MTART: 'ERSA', MATKL: 'TRM', MAKTX: 'Automatic Door Sensor Kit', MEINS: 'EA', WERKS: 'IST1', LGORT: 'WH02', DISMM: 'PD', DISLS: 'FX', EISBE: 25, MINBE: 40, PLIFZ: 14, BRGEW: 1.8, NTGEW: 1.5, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'V', STPRS: 2200.00, WAERS: 'TRY', EKGRP: '002', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000008' },
    { MATNR: '000000000010000009', MTART: 'ERSA', MATKL: 'HVA', MAKTX: 'Terminal AHU Filter HEPA H13', MEINS: 'EA', WERKS: 'IST1', LGORT: 'WH01', DISMM: 'VB', DISLS: 'FX', EISBE: 200, MINBE: 350, PLIFZ: 21, BRGEW: 4.5, NTGEW: 4.0, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'V', STPRS: 850.00, WAERS: 'TRY', EKGRP: '003', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000009' },
    { MATNR: '000000000010000010', MTART: 'ERSA', MATKL: 'HVA', MAKTX: 'Chiller Compressor 500kW', MEINS: 'EA', WERKS: 'IST1', LGORT: 'WH01', DISMM: 'PD', DISLS: 'EX', EISBE: 2, MINBE: 3, PLIFZ: 120, BRGEW: 850.0, NTGEW: 820.0, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'S', STPRS: 450000.00, WAERS: 'TRY', EKGRP: '001', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000010' },
    { MATNR: '000000000010000011', MTART: 'ERSA', MATKL: 'SEC', MAKTX: 'X-Ray Scanner Belt Assembly', MEINS: 'EA', WERKS: 'IST1', LGORT: 'WH01', DISMM: 'PD', DISLS: 'EX', EISBE: 10, MINBE: 15, PLIFZ: 30, BRGEW: 12.0, NTGEW: 11.5, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'S', STPRS: 18500.00, WAERS: 'TRY', EKGRP: '002', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000011' },
    { MATNR: '000000000010000012', MTART: 'ERSA', MATKL: 'SEC', MAKTX: 'CCTV Camera PTZ Outdoor IP67', MEINS: 'EA', WERKS: 'IST1', LGORT: 'WH01', DISMM: 'PD', DISLS: 'FX', EISBE: 30, MINBE: 50, PLIFZ: 14, BRGEW: 3.2, NTGEW: 2.8, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'V', STPRS: 6500.00, WAERS: 'TRY', EKGRP: '002', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000012' },
    { MATNR: '000000000010000013', MTART: 'ERSA', MATKL: 'ELE', MAKTX: 'UPS Battery Pack 12V 200Ah', MEINS: 'EA', WERKS: 'IST1', LGORT: 'WH04', DISMM: 'PD', DISLS: 'EX', EISBE: 40, MINBE: 60, PLIFZ: 21, BRGEW: 58.0, NTGEW: 55.0, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'V', STPRS: 4200.00, WAERS: 'TRY', EKGRP: '001', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000013' },
    { MATNR: '000000000010000014', MTART: 'ERSA', MATKL: 'ELE', MAKTX: 'Emergency Generator Fuel Filter', MEINS: 'EA', WERKS: 'IST1', LGORT: 'WH04', DISMM: 'VB', DISLS: 'FX', EISBE: 20, MINBE: 30, PLIFZ: 7, BRGEW: 0.8, NTGEW: 0.7, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'V', STPRS: 650.00, WAERS: 'TRY', EKGRP: '003', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000014' },
    { MATNR: '000000000010000015', MTART: 'HAWA', MATKL: 'SAF', MAKTX: 'Aircraft Rescue Fire Suit', MEINS: 'EA', WERKS: 'ISTR', LGORT: 'WH04', DISMM: 'VB', DISLS: 'FX', EISBE: 20, MINBE: 30, PLIFZ: 45, BRGEW: 8.0, NTGEW: 7.5, GEWEI: 'KG', BKLAS: '3000', VPRSV: 'S', STPRS: 35000.00, WAERS: 'TRY', EKGRP: '004', DISPO: 'MRP', ZZSAP_DOC_NO: '4900000015' },
  ];

  for (const mat of mockMaterials) {
    db.saveMaterial({
      ...mat,
      MAKTG: mat.MAKTX.toUpperCase(),
      ERNAM: 'SAP_ADMIN',
      ERSDA: sapDate,
      LAEDA: sapDate,
      AENAM: 'SAP_ADMIN',
      LVORM: 0,
      ZZSYNC_STATUS: 'SYNCED',
    });
  }

  console.log(`[JsonDB] Initialized with ${mockMaterials.length} mock materials`);

  // Mock Purchase Requisitions
  const mockPRs = [
    { BANFN: '0010000001', BNFPO: '00010', BSART: 'NB', MATNR: '000000000010000001', TXZ01: 'BHS Conveyor Belt 600mm Reinforced', MENGE: 50, MEINS: 'M', WERKS: 'IST1', LGORT: 'WH01', EKGRP: '001', EKORG: 'P001', PREIS: 285.00, WAERS: 'TRY', STATU: 'A', AUFNR: 'WO-2026-001', ZZOXMAINT_WO_REF: 'WO-2026-001', ZZSAP_DOC_NO: '5000000001' },
    { BANFN: '0010000001', BNFPO: '00020', BSART: 'NB', MATNR: '000000000010000002', TXZ01: 'Baggage Scanner Replacement Sensor', MENGE: 5, MEINS: 'EA', WERKS: 'IST1', LGORT: 'WH01', EKGRP: '001', EKORG: 'P001', PREIS: 4500.00, WAERS: 'TRY', STATU: 'A', AUFNR: 'WO-2026-001', ZZOXMAINT_WO_REF: 'WO-2026-001', ZZSAP_DOC_NO: '5000000002' },
    { BANFN: '0010000002', BNFPO: '00010', BSART: 'NB', MATNR: '000000000010000003', TXZ01: 'Runway Edge Light LED Unit', MENGE: 20, MEINS: 'EA', WERKS: 'ISTR', LGORT: 'WH03', EKGRP: '002', EKORG: 'P001', PREIS: 8500.00, WAERS: 'TRY', STATU: 'N', AUFNR: 'WO-2026-002', ZZOXMAINT_WO_REF: 'WO-2026-002', ZZSAP_DOC_NO: '5000000003' },
    { BANFN: '0010000003', BNFPO: '00010', BSART: 'ZURG', MATNR: '000000000010000009', TXZ01: 'Terminal AHU Filter HEPA H13', MENGE: 100, MEINS: 'EA', WERKS: 'IST1', LGORT: 'WH01', EKGRP: '003', EKORG: 'P001', PREIS: 850.00, WAERS: 'TRY', STATU: 'A', AUFNR: 'WO-2026-003', ZZOXMAINT_WO_REF: 'WO-2026-003', ZZSAP_DOC_NO: '5000000004' },
    { BANFN: '0010000004', BNFPO: '00010', BSART: 'NB', MATNR: '000000000010000006', TXZ01: 'Pushback Tractor Hydraulic Pump', MENGE: 2, MEINS: 'EA', WERKS: 'ISTM', LGORT: 'WH05', EKGRP: '001', EKORG: 'P002', PREIS: 28000.00, WAERS: 'TRY', STATU: 'N', AUFNR: 'WO-2026-004', ZZOXMAINT_WO_REF: 'WO-2026-004', ZZSAP_DOC_NO: '5000000005' },
    { BANFN: '0010000005', BNFPO: '00010', BSART: 'ZSER', TXZ01: 'Annual HVAC Maintenance Service', MENGE: 1, MEINS: 'EA', WERKS: 'IST1', LGORT: '', EKGRP: '004', EKORG: 'P003', PREIS: 150000.00, WAERS: 'TRY', STATU: 'A', KNTTP: 'K', KOSTL: 'CC-HVAC-001', ZZSAP_DOC_NO: '5000000006' },
  ];

  const deliveryDate = toSAPDate(new Date(now.getTime() + (14 * 24 * 60 * 60 * 1000)));
  for (const pr of mockPRs) {
    db.savePurchaseRequisition({
      ...pr,
      BADAT: sapDate,
      ERNAM: 'SAP_ADMIN',
      ERDAT: sapDate,
      LFDAT: deliveryDate,
      PEINH: 1,
      KNTTP: pr.KNTTP || (pr.AUFNR ? 'F' : ''),
      LOEKZ: '',
      FRGKZ: '1',
      BANPR: '01',
      PSTYP: '0',
      ZZSYNC_STATUS: 'SYNCED',
    });
  }

  console.log(`[JsonDB] Initialized with ${mockPRs.length} mock purchase requisitions`);

  // Mock Goods Receipts/Issues
  const year = now.getFullYear().toString();
  const mockGRs = [
    // Goods Receipts (101 - GR for PO)
    { MBLNR: '4900000001', MJAHR: year, ZEILE: '0001', BWART: '101', MATNR: '000000000010000001', WERKS: 'IST1', LGORT: 'WH01', MENGE: 100, MEINS: 'M', EBELN: '4500000001', EBELP: '00010', DMBTR: 28500.00, WAERS: 'TRY', SHKZG: 'S', SGTXT: 'GR for PO - Conveyor Belt', ZZSAP_DOC_NO: '6000000001' },
    { MBLNR: '4900000002', MJAHR: year, ZEILE: '0001', BWART: '101', MATNR: '000000000010000002', WERKS: 'IST1', LGORT: 'WH01', MENGE: 10, MEINS: 'EA', EBELN: '4500000002', EBELP: '00010', DMBTR: 45000.00, WAERS: 'TRY', SHKZG: 'S', SGTXT: 'GR for PO - Scanner Sensors', ZZSAP_DOC_NO: '6000000002' },
    { MBLNR: '4900000003', MJAHR: year, ZEILE: '0001', BWART: '101', MATNR: '000000000010000009', WERKS: 'IST1', LGORT: 'WH01', MENGE: 200, MEINS: 'EA', EBELN: '4500000003', EBELP: '00010', DMBTR: 170000.00, WAERS: 'TRY', SHKZG: 'S', SGTXT: 'GR for PO - HEPA Filters', ZZSAP_DOC_NO: '6000000003' },
    // Goods Receipt for Maintenance Order (161)
    { MBLNR: '4900000004', MJAHR: year, ZEILE: '0001', BWART: '161', MATNR: '000000000010000003', WERKS: 'ISTR', LGORT: 'WH03', MENGE: 15, MEINS: 'EA', AUFNR: 'WO-2026-002', DMBTR: 127500.00, WAERS: 'TRY', SHKZG: 'S', SGTXT: 'GR for WO - Runway Lights', ZZOXMAINT_WO_REF: 'WO-2026-002', ZZSAP_DOC_NO: '6000000004' },
    { MBLNR: '4900000005', MJAHR: year, ZEILE: '0001', BWART: '161', MATNR: '000000000010000013', WERKS: 'IST1', LGORT: 'WH04', MENGE: 20, MEINS: 'EA', AUFNR: 'WO-2026-005', DMBTR: 84000.00, WAERS: 'TRY', SHKZG: 'S', SGTXT: 'GR for WO - UPS Batteries', ZZOXMAINT_WO_REF: 'WO-2026-005', ZZSAP_DOC_NO: '6000000005' },
    // Goods Issues for Order (261 - consumption)
    { MBLNR: '4900000006', MJAHR: year, ZEILE: '0001', BWART: '261', MATNR: '000000000010000001', WERKS: 'IST1', LGORT: 'WH01', MENGE: 25, MEINS: 'M', AUFNR: 'WO-2026-001', DMBTR: 7125.00, WAERS: 'TRY', SHKZG: 'H', SGTXT: 'GI for WO - Conveyor Belt Replacement', ZZOXMAINT_WO_REF: 'WO-2026-001', ZZSAP_DOC_NO: '6000000006' },
    { MBLNR: '4900000007', MJAHR: year, ZEILE: '0001', BWART: '261', MATNR: '000000000010000002', WERKS: 'IST1', LGORT: 'WH01', MENGE: 3, MEINS: 'EA', AUFNR: 'WO-2026-001', DMBTR: 13500.00, WAERS: 'TRY', SHKZG: 'H', SGTXT: 'GI for WO - Scanner Sensor Install', ZZOXMAINT_WO_REF: 'WO-2026-001', ZZSAP_DOC_NO: '6000000007' },
    { MBLNR: '4900000008', MJAHR: year, ZEILE: '0001', BWART: '261', MATNR: '000000000010000009', WERKS: 'IST1', LGORT: 'WH01', MENGE: 50, MEINS: 'EA', AUFNR: 'WO-2026-003', DMBTR: 42500.00, WAERS: 'TRY', SHKZG: 'H', SGTXT: 'GI for WO - Filter Replacement', ZZOXMAINT_WO_REF: 'WO-2026-003', ZZSAP_DOC_NO: '6000000008' },
    // Goods Issue for Cost Center (201)
    { MBLNR: '4900000009', MJAHR: year, ZEILE: '0001', BWART: '201', MATNR: '000000000010000014', WERKS: 'IST1', LGORT: 'WH04', MENGE: 5, MEINS: 'EA', KOSTL: 'CC-GEN-001', DMBTR: 3250.00, WAERS: 'TRY', SHKZG: 'H', SGTXT: 'GI for Cost Ctr - Generator Filters', ZZSAP_DOC_NO: '6000000009' },
    // Initial Stock Entry (561)
    { MBLNR: '4900000010', MJAHR: year, ZEILE: '0001', BWART: '561', MATNR: '000000000010000015', WERKS: 'ISTR', LGORT: 'WH04', MENGE: 30, MEINS: 'EA', DMBTR: 1050000.00, WAERS: 'TRY', SHKZG: 'S', SGTXT: 'Initial Stock - Fire Suits', ZZSAP_DOC_NO: '6000000010' },
  ];

  for (const gr of mockGRs) {
    db.saveGoodsReceipt({
      ...gr,
      BLDAT: sapDate,
      BUDAT: sapDate,
      USNAM: 'SAP_ADMIN',
      TCODE: 'MIGO',
      ERFMG: gr.MENGE,
      ERFME: gr.MEINS,
      KZZUG: gr.SHKZG === 'S' ? 'X' : '',
      CANCELLED: 0,
      ZZSYNC_STATUS: 'SYNCED',
    });
  }

  console.log(`[JsonDB] Initialized with ${mockGRs.length} mock goods receipts/issues`);
};

// Initialize on module load
initializeMockData();

// =====================================================
// MATERIAL STORE
// =====================================================

export const MaterialStore = {
  getAll: (filters?: { WERKS?: string; MTART?: string; MATKL?: string }): SAPMaterial[] => {
    let materials = db.getMaterials() as unknown as SAPMaterial[];
    if (filters?.WERKS) materials = materials.filter((m) => m.WERKS === filters.WERKS);
    if (filters?.MTART) materials = materials.filter((m) => m.MTART === filters.MTART);
    if (filters?.MATKL) materials = materials.filter((m) => m.MATKL === filters.MATKL);
    return materials;
  },

  getByNumber: (MATNR: string): SAPMaterial | undefined => {
    const paddedMatnr = MATNR.padStart(18, '0');
    return db.getMaterial(paddedMatnr) as SAPMaterial | undefined;
  },

  create: (request: MaterialCreateRequest, createdBy: string = 'OXMAINT_SYNC'): SAPMaterial => {
    const MATNR = request.MATNR ? request.MATNR.padStart(18, '0') : generateMaterialNumber();
    const now = new Date();
    const sapDate = toSAPDate(now);

    const material: SAPMaterial = {
      MATNR,
      MTART: request.MTART,
      MATKL: request.MATKL,
      MAKTX: request.MAKTX,
      MAKTG: request.MAKTX.toUpperCase(),
      MEINS: request.MEINS,
      WERKS: request.WERKS,
      LGORT: request.LGORT,
      DISMM: request.DISMM || 'PD',
      DISLS: request.DISLS || 'EX',
      MINBE: request.MINBE || 0,
      EISBE: request.EISBE || 0,
      PLIFZ: request.PLIFZ || 1,
      BRGEW: request.BRGEW,
      NTGEW: request.NTGEW,
      GEWEI: request.GEWEI || 'KG',
      BKLAS: request.BKLAS || '3000',
      VPRSV: request.VPRSV || 'V',
      STPRS: request.STPRS || 0,
      WAERS: request.WAERS || 'USD',
      EKGRP: request.EKGRP,
      DISPO: request.DISPO || 'MRP',
      ERNAM: createdBy,
      ERSDA: sapDate,
      LAEDA: sapDate,
      AENAM: createdBy,
      LVORM: false,
      ZZOXMAINT_REF: request.ZZOXMAINT_REF,
      ZZSYNC_STATUS: 'SYNCED',
      ZZSAP_DOC_NO: generateSAPDocumentNumber(),
    };

    db.saveMaterial(material as unknown as Record<string, unknown>);
    return material;
  },

  update: (MATNR: string, updates: Partial<MaterialCreateRequest>, modifiedBy: string = 'OXMAINT_SYNC'): SAPMaterial | null => {
    const existing = MaterialStore.getByNumber(MATNR);
    if (!existing) return null;

    const sapDate = toSAPDate(new Date());
    const updated: SAPMaterial = {
      ...existing,
      ...updates,
      MAKTG: updates.MAKTX ? updates.MAKTX.toUpperCase() : existing.MAKTG,
      LAEDA: sapDate,
      AENAM: modifiedBy,
    };

    db.saveMaterial(updated as unknown as Record<string, unknown>);
    return updated;
  },

  delete: (MATNR: string, deletedBy: string = 'OXMAINT_SYNC'): boolean => {
    const existing = MaterialStore.getByNumber(MATNR);
    if (!existing) return false;

    existing.LVORM = true;
    existing.LAEDA = toSAPDate(new Date());
    existing.AENAM = deletedBy;
    db.saveMaterial(existing as unknown as Record<string, unknown>);
    return true;
  },

  hardDelete: (MATNR: string): boolean => {
    const paddedMatnr = MATNR.padStart(18, '0');
    return db.deleteMaterial(paddedMatnr);
  },

  search: (query: string): SAPMaterial[] => {
    const q = query.toLowerCase();
    return db.filterMaterials((m) =>
      String(m.MATNR).toLowerCase().includes(q) ||
      String(m.MAKTX).toLowerCase().includes(q) ||
      String(m.MATKL).toLowerCase().includes(q)
    ) as unknown as SAPMaterial[];
  },

  count: (): number => {
    return db.countMaterials();
  },
};

// =====================================================
// PURCHASE REQUISITION STORE
// =====================================================

export const PurchaseRequisitionStore = {
  getAll: (filters?: { WERKS?: string; EKORG?: string; EKGRP?: string; STATU?: string; AUFNR?: string }): SAPPurchaseRequisition[] => {
    let prs = db.getPurchaseRequisitions() as unknown as SAPPurchaseRequisition[];
    if (filters?.WERKS) prs = prs.filter((pr) => pr.WERKS === filters.WERKS);
    if (filters?.EKORG) prs = prs.filter((pr) => pr.EKORG === filters.EKORG);
    if (filters?.EKGRP) prs = prs.filter((pr) => pr.EKGRP === filters.EKGRP);
    if (filters?.STATU) prs = prs.filter((pr) => pr.STATU === filters.STATU);
    if (filters?.AUFNR) prs = prs.filter((pr) => pr.AUFNR === filters.AUFNR);
    return prs;
  },

  getByNumber: (BANFN: string): SAPPurchaseRequisition[] => {
    const paddedBanfn = BANFN.padStart(10, '0');
    return db.filterPurchaseRequisitions((pr) => pr.BANFN === paddedBanfn || pr.BANFN === BANFN) as unknown as SAPPurchaseRequisition[];
  },

  getByNumberAndItem: (BANFN: string, BNFPO: string): SAPPurchaseRequisition | undefined => {
    const paddedBanfn = BANFN.padStart(10, '0');
    const paddedBnfpo = BNFPO.padStart(5, '0');
    const key = `${paddedBanfn}-${paddedBnfpo}`;
    return db.getPurchaseRequisition(key) as SAPPurchaseRequisition | undefined;
  },

  getByWorkOrder: (AUFNR: string): SAPPurchaseRequisition[] => {
    return db.filterPurchaseRequisitions((pr) => pr.AUFNR === AUFNR) as unknown as SAPPurchaseRequisition[];
  },

  getByOxmaintRef: (ref: string): SAPPurchaseRequisition[] => {
    return db.filterPurchaseRequisitions((pr) => pr.ZZOXMAINT_WO_REF === ref) as unknown as SAPPurchaseRequisition[];
  },

  create: (request: PurchaseRequisitionCreateRequest, createdBy: string = 'OXMAINT_SYNC'): SAPPurchaseRequisition => {
    const BANFN = request.BANFN ? request.BANFN.padStart(10, '0') : generatePRNumber();
    const BNFPO = request.BNFPO ? request.BNFPO.padStart(5, '0') : generatePRItemNumber(BANFN);
    const now = new Date();
    const sapDate = toSAPDate(now);
    const deliveryDate = request.LFDAT || toSAPDate(new Date(now.getTime() + (14 * 24 * 60 * 60 * 1000)));

    const pr: SAPPurchaseRequisition = {
      BANFN,
      BNFPO,
      BSART: request.BSART,
      BADAT: sapDate,
      ERNAM: createdBy,
      ERDAT: sapDate,
      MATNR: request.MATNR,
      TXZ01: request.TXZ01,
      MENGE: request.MENGE,
      MEINS: request.MEINS,
      LFDAT: deliveryDate,
      WERKS: request.WERKS,
      LGORT: request.LGORT,
      EKGRP: request.EKGRP,
      EKORG: request.EKORG,
      PREIS: request.PREIS || 0,
      PEINH: 1,
      WAERS: request.WAERS || 'USD',
      KNTTP: request.KNTTP || (request.AUFNR ? 'F' : ''),
      KOSTL: request.KOSTL,
      AUFNR: request.AUFNR,
      PS_PSP_PNR: request.PS_PSP_PNR,
      SAKTO: request.SAKTO,
      STATU: 'N',
      LOEKZ: '',
      FRGKZ: '1',
      BANPR: request.BANPR || '01',
      LIFNR: request.LIFNR,
      PSTYP: request.PSTYP || '0',
      ZZOXMAINT_WO_REF: request.ZZOXMAINT_WO_REF,
      ZZOXMAINT_WO_LINE: request.ZZOXMAINT_WO_LINE,
      ZZSYNC_STATUS: 'SYNCED',
      ZZSAP_DOC_NO: generatePRDocumentNumber(),
    };

    db.savePurchaseRequisition(pr as unknown as Record<string, unknown>);
    return pr;
  },

  createMultiple: (items: PurchaseRequisitionCreateRequest[], createdBy: string = 'OXMAINT_SYNC'): SAPPurchaseRequisition[] => {
    const results: SAPPurchaseRequisition[] = [];
    const BANFN = generatePRNumber();

    let itemNumber = 10;
    for (const item of items) {
      const BNFPO = itemNumber.toString().padStart(5, '0');
      const created = PurchaseRequisitionStore.create({ ...item, BANFN, BNFPO }, createdBy);
      results.push(created);
      itemNumber += 10;
    }

    return results;
  },

  update: (BANFN: string, BNFPO: string, updates: Partial<PurchaseRequisitionCreateRequest>, modifiedBy: string = 'OXMAINT_SYNC'): SAPPurchaseRequisition | null => {
    const existing = PurchaseRequisitionStore.getByNumberAndItem(BANFN, BNFPO);
    if (!existing) return null;

    const sapDate = toSAPDate(new Date());
    const updated: SAPPurchaseRequisition = {
      ...existing,
      ...updates,
      AENAM: modifiedBy,
      AEDAT: sapDate,
    };

    db.savePurchaseRequisition(updated as unknown as Record<string, unknown>);
    return updated;
  },

  delete: (BANFN: string, BNFPO: string, deletedBy: string = 'OXMAINT_SYNC'): boolean => {
    const existing = PurchaseRequisitionStore.getByNumberAndItem(BANFN, BNFPO);
    if (!existing) return false;

    existing.LOEKZ = 'X';
    existing.STATU = 'X';
    existing.AENAM = deletedBy;
    existing.AEDAT = toSAPDate(new Date());
    db.savePurchaseRequisition(existing as unknown as Record<string, unknown>);
    return true;
  },

  deleteByNumber: (BANFN: string, deletedBy: string = 'OXMAINT_SYNC'): boolean => {
    const prs = PurchaseRequisitionStore.getByNumber(BANFN);
    if (prs.length === 0) return false;

    for (const pr of prs) {
      PurchaseRequisitionStore.delete(pr.BANFN, pr.BNFPO, deletedBy);
    }
    return true;
  },

  // Update approval/release status (callback from SAP workflow)
  updateApprovalStatus: (
    BANFN: string,
    BNFPO: string,
    approvalData: {
      STATU?: string;
      FRGST?: string;
      FRGZU?: string;
      FRGKZ?: string;
      FRGDT?: string;
      FRGRL?: string;
      FRGGR?: string;
      FRGCO?: string;
      ZZAPPROVER_ID?: string;
      ZZAPPROVER_NAME?: string;
      ZZAPPROVAL_NOTES?: string;
      ZZAPPROVAL_LEVEL?: number;
    },
    modifiedBy: string = 'SAP_WORKFLOW'
  ): SAPPurchaseRequisition | null => {
    const existing = PurchaseRequisitionStore.getByNumberAndItem(BANFN, BNFPO);
    if (!existing) return null;

    const sapDate = toSAPDate(new Date());
    const updated: SAPPurchaseRequisition = {
      ...existing,
      STATU: approvalData.STATU || existing.STATU,
      FRGST: approvalData.FRGST ?? existing.FRGST,
      FRGZU: approvalData.FRGZU ?? existing.FRGZU,
      FRGKZ: approvalData.FRGKZ ?? existing.FRGKZ,
      FRGDT: approvalData.FRGDT ?? existing.FRGDT,
      FRGRL: approvalData.FRGRL ?? existing.FRGRL,
      FRGGR: approvalData.FRGGR ?? existing.FRGGR,
      FRGCO: approvalData.FRGCO ?? existing.FRGCO,
      ZZAPPROVER_ID: approvalData.ZZAPPROVER_ID ?? existing.ZZAPPROVER_ID,
      ZZAPPROVER_NAME: approvalData.ZZAPPROVER_NAME ?? existing.ZZAPPROVER_NAME,
      ZZAPPROVAL_NOTES: approvalData.ZZAPPROVAL_NOTES ?? existing.ZZAPPROVAL_NOTES,
      ZZAPPROVAL_LEVEL: approvalData.ZZAPPROVAL_LEVEL ?? existing.ZZAPPROVAL_LEVEL,
      AENAM: modifiedBy,
      AEDAT: sapDate,
    };

    db.savePurchaseRequisition(updated as unknown as Record<string, unknown>);
    return updated;
  },

  count: (): number => {
    return db.countPurchaseRequisitions();
  },
};

// =====================================================
// PURCHASE ORDER STORE (ME21N/ME23N)
// =====================================================

// PO Number generator
const generatePONumber = (): string => {
  const maxNum = db.getMaxPONumber();
  return (maxNum + 1).toString().padStart(10, '0');
};

// PO Item Number generator
const generatePOItemNumber = (EBELN: string): string => {
  const existingItems = db.filterPurchaseOrders((po) => po.EBELN === EBELN);
  if (existingItems.length === 0) return '00010';
  const maxItem = Math.max(...existingItems.map((po) => parseInt(String(po.EBELP) || '0', 10)));
  return (maxItem + 10).toString().padStart(5, '0');
};

// PO Document Number generator
const generatePODocumentNumber = (): string => {
  const maxNum = db.getMaxPONumber();
  return (7000000000 + (maxNum - 4500000000)).toString();
};

export const PurchaseOrderStore = {
  getAll: (filters?: { WERKS?: string; EKORG?: string; EKGRP?: string; LIFNR?: string; STATU?: string }): SAPPurchaseOrder[] => {
    let pos = db.getPurchaseOrders() as unknown as SAPPurchaseOrder[];
    if (filters?.WERKS) pos = pos.filter((po) => po.WERKS === filters.WERKS);
    if (filters?.EKORG) pos = pos.filter((po) => po.EKORG === filters.EKORG);
    if (filters?.EKGRP) pos = pos.filter((po) => po.EKGRP === filters.EKGRP);
    if (filters?.LIFNR) pos = pos.filter((po) => po.LIFNR === filters.LIFNR);
    if (filters?.STATU) pos = pos.filter((po) => po.STATU === filters.STATU);
    return pos;
  },

  getByNumber: (EBELN: string): SAPPurchaseOrder[] => {
    const paddedEbeln = EBELN.padStart(10, '0');
    return db.filterPurchaseOrders((po) => po.EBELN === paddedEbeln || po.EBELN === EBELN) as unknown as SAPPurchaseOrder[];
  },

  getByNumberAndItem: (EBELN: string, EBELP: string): SAPPurchaseOrder | undefined => {
    const paddedEbeln = EBELN.padStart(10, '0');
    const paddedEbelp = EBELP.padStart(5, '0');
    const key = `${paddedEbeln}-${paddedEbelp}`;
    return db.getPurchaseOrder(key) as SAPPurchaseOrder | undefined;
  },

  getByVendor: (LIFNR: string): SAPPurchaseOrder[] => {
    return db.filterPurchaseOrders((po) => po.LIFNR === LIFNR) as unknown as SAPPurchaseOrder[];
  },

  getByPR: (BANFN: string, BNFPO?: string): SAPPurchaseOrder[] => {
    const paddedBanfn = BANFN.padStart(10, '0');
    return db.filterPurchaseOrders((po) => {
      if (po.BANFN !== paddedBanfn && po.BANFN !== BANFN) return false;
      if (BNFPO) {
        const paddedBnfpo = BNFPO.padStart(5, '0');
        return po.BNFPO === paddedBnfpo || po.BNFPO === BNFPO;
      }
      return true;
    }) as unknown as SAPPurchaseOrder[];
  },

  getByOxmaintRef: (ref: string): SAPPurchaseOrder[] => {
    return db.filterPurchaseOrders((po) => po.ZZOXMAINT_WO_REF === ref) as unknown as SAPPurchaseOrder[];
  },

  create: (request: PurchaseOrderCreateRequest, createdBy: string = 'OXMAINT_SYNC'): SAPPurchaseOrder => {
    const EBELN = request.EBELN ? request.EBELN.padStart(10, '0') : generatePONumber();
    const EBELP = request.EBELP ? request.EBELP.padStart(5, '0') : generatePOItemNumber(EBELN);
    const now = new Date();
    const sapDate = toSAPDate(now);
    const deliveryDate = request.EINDT || request.LFDAT || toSAPDate(new Date(now.getTime() + (14 * 24 * 60 * 60 * 1000)));
    const netValue = request.NETPR * request.MENGE / (request.PEINH || 1);

    const po: SAPPurchaseOrder = {
      EBELN,
      EBELP,
      BSART: request.BSART || 'NB',
      BSTYP: 'F',
      LOEKZ: '',
      STATU: 'O',
      ERNAM: createdBy,
      ERDAT: sapDate,
      LIFNR: request.LIFNR,
      EKORG: request.EKORG,
      EKGRP: request.EKGRP,
      WAERS: request.WAERS || 'USD',
      BEDAT: request.BEDAT || sapDate,
      MATNR: request.MATNR,
      TXZ01: request.TXZ01,
      MENGE: request.MENGE,
      MEINS: request.MEINS,
      NETPR: request.NETPR,
      PEINH: request.PEINH || 1,
      NETWR: netValue,
      EINDT: deliveryDate,
      LFDAT: deliveryDate,
      WERKS: request.WERKS,
      LGORT: request.LGORT,
      MATKL: request.MATKL,
      PSTYP: request.PSTYP || '0',
      KNTTP: request.KNTTP || (request.AUFNR ? 'F' : ''),
      KOSTL: request.KOSTL,
      AUFNR: request.AUFNR,
      SAKTO: request.SAKTO,
      PS_PSP_PNR: request.PS_PSP_PNR,
      BANFN: request.BANFN,
      BNFPO: request.BNFPO,
      ELIKZ: '',
      EMLIF: 0,
      WEPOS: 'X',
      ZZOXMAINT_WO_REF: request.ZZOXMAINT_WO_REF,
      ZZOXMAINT_WO_LINE: request.ZZOXMAINT_WO_LINE,
      ZZSYNC_STATUS: 'SYNCED',
      ZZSAP_DOC_NO: generatePODocumentNumber(),
    };

    db.savePurchaseOrder(po as unknown as Record<string, unknown>);
    return po;
  },

  // Convert PR to PO (ME59N)
  createFromPR: (
    BANFN: string,
    BNFPO: string,
    LIFNR: string,
    additionalData?: Partial<PurchaseOrderCreateRequest>,
    createdBy: string = 'SAP_CONVERSION'
  ): { po: SAPPurchaseOrder; pr: SAPPurchaseRequisition } | null => {
    const pr = PurchaseRequisitionStore.getByNumberAndItem(BANFN, BNFPO);
    if (!pr) return null;

    // Check if PR is released/approved
    if (pr.FRGST !== 'R' && pr.STATU !== 'A') {
      throw new Error(`PR ${BANFN}/${BNFPO} is not released. Current status: ${pr.STATU}, Release status: ${pr.FRGST || 'Not Released'}`);
    }

    // Check if PR already has a PO
    const existingPO = PurchaseOrderStore.getByPR(BANFN, BNFPO);
    if (existingPO.length > 0) {
      throw new Error(`PR ${BANFN}/${BNFPO} already converted to PO ${existingPO[0].EBELN}`);
    }

    // Create PO from PR data
    const po = PurchaseOrderStore.create({
      LIFNR: LIFNR,
      EKORG: pr.EKORG,
      EKGRP: pr.EKGRP,
      WAERS: pr.WAERS,
      MATNR: pr.MATNR,
      TXZ01: pr.TXZ01,
      MENGE: pr.MENGE,
      MEINS: pr.MEINS,
      NETPR: pr.PREIS || 0,
      WERKS: pr.WERKS,
      LGORT: pr.LGORT,
      PSTYP: pr.PSTYP,
      KNTTP: pr.KNTTP,
      KOSTL: pr.KOSTL,
      AUFNR: pr.AUFNR,
      SAKTO: pr.SAKTO,
      PS_PSP_PNR: pr.PS_PSP_PNR,
      BANFN: pr.BANFN,
      BNFPO: pr.BNFPO,
      ZZOXMAINT_WO_REF: pr.ZZOXMAINT_WO_REF,
      ZZOXMAINT_WO_LINE: pr.ZZOXMAINT_WO_LINE,
      ...additionalData,
    }, createdBy);

    // Update PR status to indicate it has been converted
    const updatedPR = PurchaseRequisitionStore.update(
      pr.BANFN,
      pr.BNFPO,
      {},
      createdBy
    );
    if (updatedPR) {
      updatedPR.STATU = 'C'; // Completed/Converted
      updatedPR.FLIEF = LIFNR;
      db.savePurchaseRequisition(updatedPR as unknown as Record<string, unknown>);
    }

    return { po, pr: updatedPR || pr };
  },

  update: (EBELN: string, EBELP: string, updates: Partial<PurchaseOrderCreateRequest>, modifiedBy: string = 'OXMAINT_SYNC'): SAPPurchaseOrder | null => {
    const existing = PurchaseOrderStore.getByNumberAndItem(EBELN, EBELP);
    if (!existing) return null;

    const sapDate = toSAPDate(new Date());
    const updated: SAPPurchaseOrder = {
      ...existing,
      ...updates,
      NETWR: updates.NETPR && updates.MENGE ? (updates.NETPR * updates.MENGE / (updates.PEINH || existing.PEINH || 1)) : existing.NETWR,
      AEDAT: sapDate,
    };

    db.savePurchaseOrder(updated as unknown as Record<string, unknown>);
    return updated;
  },

  delete: (EBELN: string, EBELP: string, deletedBy: string = 'OXMAINT_SYNC'): boolean => {
    const existing = PurchaseOrderStore.getByNumberAndItem(EBELN, EBELP);
    if (!existing) return false;

    existing.LOEKZ = 'X';
    existing.STATU = 'X';
    existing.AEDAT = toSAPDate(new Date());
    db.savePurchaseOrder(existing as unknown as Record<string, unknown>);
    return true;
  },

  count: (): number => {
    return db.countPurchaseOrders();
  },
};

// =====================================================
// GOODS RECEIPT STORE
// =====================================================

export const GoodsReceiptStore = {
  getAll: (filters?: { WERKS?: string; LGORT?: string; BWART?: string; MATNR?: string; AUFNR?: string; EBELN?: string }): SAPGoodsReceipt[] => {
    let grs = db.getGoodsReceipts() as unknown as SAPGoodsReceipt[];
    if (filters?.WERKS) grs = grs.filter((gr) => gr.WERKS === filters.WERKS);
    if (filters?.LGORT) grs = grs.filter((gr) => gr.LGORT === filters.LGORT);
    if (filters?.BWART) grs = grs.filter((gr) => gr.BWART === filters.BWART);
    if (filters?.MATNR) grs = grs.filter((gr) => gr.MATNR === filters.MATNR || gr.MATNR === filters.MATNR?.padStart(18, '0'));
    if (filters?.AUFNR) grs = grs.filter((gr) => gr.AUFNR === filters.AUFNR);
    if (filters?.EBELN) grs = grs.filter((gr) => gr.EBELN === filters.EBELN);
    return grs;
  },

  getByDocument: (MBLNR: string, MJAHR: string): SAPGoodsReceipt[] => {
    const paddedMblnr = MBLNR.padStart(10, '0');
    return db.filterGoodsReceipts((gr) => (gr.MBLNR === paddedMblnr || gr.MBLNR === MBLNR) && gr.MJAHR === MJAHR) as unknown as SAPGoodsReceipt[];
  },

  getByDocumentAndItem: (MBLNR: string, MJAHR: string, ZEILE: string): SAPGoodsReceipt | undefined => {
    const paddedMblnr = MBLNR.padStart(10, '0');
    const paddedZeile = ZEILE.padStart(4, '0');
    const key = `${paddedMblnr}-${MJAHR}-${paddedZeile}`;
    return db.getGoodsReceipt(key) as SAPGoodsReceipt | undefined;
  },

  getByWorkOrder: (AUFNR: string): SAPGoodsReceipt[] => {
    return db.filterGoodsReceipts((gr) => gr.AUFNR === AUFNR) as unknown as SAPGoodsReceipt[];
  },

  getByOxmaintRef: (ref: string): SAPGoodsReceipt[] => {
    return db.filterGoodsReceipts((gr) => gr.ZZOXMAINT_WO_REF === ref) as unknown as SAPGoodsReceipt[];
  },

  getByMaterial: (MATNR: string): SAPGoodsReceipt[] => {
    const paddedMatnr = MATNR.padStart(18, '0');
    return db.filterGoodsReceipts((gr) => gr.MATNR === paddedMatnr || gr.MATNR === MATNR) as unknown as SAPGoodsReceipt[];
  },

  getByPO: (EBELN: string): SAPGoodsReceipt[] => {
    return db.filterGoodsReceipts((gr) => gr.EBELN === EBELN) as unknown as SAPGoodsReceipt[];
  },

  create: (request: GoodsReceiptCreateRequest, createdBy: string = 'OXMAINT_SYNC'): SAPGoodsReceipt => {
    const now = new Date();
    const sapDate = toSAPDate(now);
    const year = now.getFullYear().toString();

    const MJAHR = request.MJAHR || year;
    const MBLNR = request.MBLNR ? request.MBLNR.padStart(10, '0') : generateMBLNR(MJAHR);
    const ZEILE = request.ZEILE ? request.ZEILE.padStart(4, '0') : generateGRItemNumber(MBLNR, MJAHR);

    const receiptMovements = ['101', '103', '105', '161', '301', '311', '501', '561'];
    const SHKZG = receiptMovements.includes(request.BWART) ? 'S' : 'H';

    const gr: SAPGoodsReceipt = {
      MBLNR,
      MJAHR,
      ZEILE,
      BLDAT: request.BLDAT || sapDate,
      BUDAT: request.BUDAT || sapDate,
      USNAM: createdBy,
      TCODE: 'MIGO',
      BKTXT: request.BKTXT,
      BWART: request.BWART,
      MATNR: request.MATNR.padStart(18, '0'),
      WERKS: request.WERKS,
      LGORT: request.LGORT,
      MENGE: request.MENGE,
      MEINS: request.MEINS,
      ERFMG: request.MENGE,
      ERFME: request.MEINS,
      EBELN: request.EBELN,
      EBELP: request.EBELP,
      AUFNR: request.AUFNR,
      RSNUM: request.RSNUM,
      RSPOS: request.RSPOS,
      LIFNR: request.LIFNR,
      DMBTR: request.DMBTR || 0,
      WAERS: request.WAERS || 'USD',
      EXBWR: request.EXBWR,
      SHKZG,
      KZZUG: SHKZG === 'S' ? 'X' : '',
      UMWRK: request.UMWRK,
      UMLGO: request.UMLGO,
      CHARG: request.CHARG,
      VFDAT: request.VFDAT,
      SGTXT: request.SGTXT,
      GRUND: request.GRUND,
      KOSTL: request.KOSTL,
      CANCELLED: false,
      XBLNR: request.XBLNR,
      ZZOXMAINT_WO_REF: request.ZZOXMAINT_WO_REF,
      ZZOXMAINT_INV_REF: request.ZZOXMAINT_INV_REF,
      ZZSYNC_STATUS: 'SYNCED',
      ZZSAP_DOC_NO: generateGRDocumentNumber(),
    };

    db.saveGoodsReceipt(gr as unknown as Record<string, unknown>);
    return gr;
  },

  createMultiple: (items: GoodsReceiptCreateRequest[], createdBy: string = 'OXMAINT_SYNC'): SAPGoodsReceipt[] => {
    const results: SAPGoodsReceipt[] = [];
    const now = new Date();
    const year = now.getFullYear().toString();
    const MBLNR = generateMBLNR(year);

    let itemNumber = 1;
    for (const item of items) {
      const ZEILE = itemNumber.toString().padStart(4, '0');
      const created = GoodsReceiptStore.create({ ...item, MBLNR, MJAHR: year, ZEILE }, createdBy);
      results.push(created);
      itemNumber++;
    }

    return results;
  },

  cancel: (MBLNR: string, MJAHR: string, ZEILE: string): boolean => {
    const paddedMblnr = MBLNR.padStart(10, '0');
    const paddedZeile = ZEILE.padStart(4, '0');
    const key = `${paddedMblnr}-${MJAHR}-${paddedZeile}`;
    return db.cancelGoodsReceipt(key);
  },

  cancelByDocument: (MBLNR: string, MJAHR: string): boolean => {
    const grs = GoodsReceiptStore.getByDocument(MBLNR, MJAHR);
    if (grs.length === 0) return false;

    for (const gr of grs) {
      GoodsReceiptStore.cancel(gr.MBLNR, gr.MJAHR, gr.ZEILE);
    }
    return true;
  },

  count: (): number => {
    return db.countGoodsReceipts();
  },
};

// =====================================================
// STOCK RESERVATION STORE (MB21/MB22/MB23)
// =====================================================

export const StockReservationStore = {
  _normalizeRsnum: (value: string): string => (/^[0-9]+$/.test(value) ? value.padStart(10, '0') : value),

  getAll: (filters?: { WERKS?: string; LGORT?: string; AUFNR?: string; MATNR?: string; RSNUM?: string }): SAPStockReservation[] => {
    let reservations = db.getStockReservations() as unknown as SAPStockReservation[];
    if (filters?.WERKS) reservations = reservations.filter((res) => res.WERKS === filters.WERKS);
    if (filters?.LGORT) reservations = reservations.filter((res) => res.LGORT === filters.LGORT);
    if (filters?.AUFNR) reservations = reservations.filter((res) => res.AUFNR === filters.AUFNR);
    if (filters?.MATNR) reservations = reservations.filter((res) => res.MATNR === filters.MATNR || res.MATNR === filters.MATNR?.padStart(18, '0'));
    if (filters?.RSNUM) {
      const normalized = StockReservationStore._normalizeRsnum(filters.RSNUM);
      reservations = reservations.filter((res) => res.RSNUM === filters.RSNUM || res.RSNUM === normalized);
    }
    return reservations;
  },

  getByNumber: (RSNUM: string): SAPStockReservation[] => {
    const normalized = StockReservationStore._normalizeRsnum(RSNUM);
    return db.filterStockReservations((res) => res.RSNUM === RSNUM || res.RSNUM === normalized) as unknown as SAPStockReservation[];
  },

  getByNumberAndItem: (RSNUM: string, RSPOS: string): SAPStockReservation | undefined => {
    const paddedRsnum = StockReservationStore._normalizeRsnum(RSNUM);
    const paddedRspos = RSPOS.padStart(4, '0');
    const key = `${paddedRsnum}-${paddedRspos}`;
    return db.getStockReservation(key) as SAPStockReservation | undefined;
  },

  getByWorkOrder: (AUFNR: string): SAPStockReservation[] => {
    return db.filterStockReservations((res) => res.AUFNR === AUFNR) as unknown as SAPStockReservation[];
  },

  getByOxmaintRef: (ref: string): SAPStockReservation[] => {
    return db.filterStockReservations((res) => res.ZZOXMAINT_WO_REF === ref) as unknown as SAPStockReservation[];
  },

  create: (request: StockReservationCreateRequest, createdBy: string = 'OXMAINT_SYNC'): SAPStockReservation => {
    const RSNUM = request.RSNUM ? StockReservationStore._normalizeRsnum(request.RSNUM) : generateReservationNumber();
    const RSPOS = request.RSPOS ? request.RSPOS.padStart(4, '0') : generateReservationItemNumber(RSNUM);
    const now = new Date();
    const sapDate = toSAPDate(now);
    const reqDate = request.BDTER || toSAPDate(new Date(now.getTime() + (7 * 24 * 60 * 60 * 1000)));
    const WERKS = request.WERKS || 'IST1';
    const BDMNG = request.BDMNG === undefined || request.BDMNG === null ? 1 : request.BDMNG;
    const MEINS = request.MEINS || 'EA';

    const reservation: SAPStockReservation = {
      RSNUM,
      RSPOS,
      MATNR: request.MATNR ? request.MATNR.padStart(18, '0') : undefined,
      WERKS,
      LGORT: request.LGORT,
      BDMNG,
      MEINS,
      BDTER: reqDate,
      BWART: request.BWART || '261',
      AUFNR: request.AUFNR,
      KOSTL: request.KOSTL,
      SGTXT: request.SGTXT,
      ERNAM: createdBy,
      ERDAT: sapDate,
      ZZOXMAINT_WO_REF: request.ZZOXMAINT_WO_REF,
      ZZSYNC_STATUS: 'SYNCED',
      ZZSAP_DOC_NO: generateReservationDocumentNumber(),
    };

    db.saveStockReservation(reservation as unknown as Record<string, unknown>);
    return reservation;
  },

  createMultiple: (items: StockReservationCreateRequest[], createdBy: string = 'OXMAINT_SYNC'): SAPStockReservation[] => {
    const results: SAPStockReservation[] = [];
    const RSNUM = generateReservationNumber();
    let itemNumber = 10;

    for (const item of items) {
      const RSPOS = itemNumber.toString().padStart(4, '0');
      const created = StockReservationStore.create({ ...item, RSNUM, RSPOS }, createdBy);
      results.push(created);
      itemNumber += 10;
    }

    return results;
  },

  update: (RSNUM: string, RSPOS: string, updates: Partial<StockReservationCreateRequest>, modifiedBy: string = 'OXMAINT_SYNC'): SAPStockReservation | null => {
    const existing = StockReservationStore.getByNumberAndItem(RSNUM, RSPOS);
    if (!existing) return null;

    const sapDate = toSAPDate(new Date());
    const updated: SAPStockReservation = {
      ...existing,
      ...updates,
      MATNR: updates.MATNR ? updates.MATNR.padStart(18, '0') : existing.MATNR,
      AENAM: modifiedBy,
      AEDAT: sapDate,
    };

    db.saveStockReservation(updated as unknown as Record<string, unknown>);
    return updated;
  },

  delete: (RSNUM: string, RSPOS: string): boolean => {
    const paddedRsnum = StockReservationStore._normalizeRsnum(RSNUM);
    const paddedRspos = RSPOS.padStart(4, '0');
    const key = `${paddedRsnum}-${paddedRspos}`;
    return db.deleteStockReservation(key);
  },

  count: (): number => {
    return db.countStockReservations();
  },
};
