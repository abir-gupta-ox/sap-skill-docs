import fs from 'fs';
import path from 'path';

// Database file location - uses /tmp for Cloud Foundry compatibility
// In CF, only /tmp and /home/vcap/app are writable, but /tmp is more reliable
const getDataDir = (): string => {
  // Use environment variable if set, otherwise use /tmp for CF or local data folder
  if (process.env.DATA_DIR) {
    return process.env.DATA_DIR;
  }
  // Check if we're in Cloud Foundry (VCAP_APPLICATION is set)
  if (process.env.VCAP_APPLICATION) {
    return '/tmp/data';
  }
  return path.join(process.cwd(), 'data');
};

const DATA_DIR = getDataDir();
const DB_PATH = path.join(DATA_DIR, 'database.json');
const BUNDLED_DB_PATH = path.join(process.cwd(), 'data', 'database.json');

// Ensure data directory exists (called lazily)
let dirInitialized = false;
function ensureDataDir(): void {
  if (dirInitialized) return;
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    dirInitialized = true;
  } catch (error) {
    console.error('[JsonDB] Error creating data directory:', error);
  }
}

// Database structure
interface DatabaseSchema {
  materials: Record<string, Record<string, unknown>>;
  purchase_requisitions: Record<string, Record<string, unknown>>;
  purchase_orders: Record<string, Record<string, unknown>>;
  goods_receipts: Record<string, Record<string, unknown>>;
  stock_reservations: Record<string, Record<string, unknown>>;
}

// Load or initialize database
function loadDatabase(): DatabaseSchema {
  ensureDataDir();
  try {
    if (!fs.existsSync(DB_PATH) && fs.existsSync(BUNDLED_DB_PATH)) {
      try {
        fs.copyFileSync(BUNDLED_DB_PATH, DB_PATH);
      } catch (copyError) {
        console.error('[JsonDB] Error copying bundled database:', copyError);
      }
    }
    if (fs.existsSync(DB_PATH)) {
      const data = fs.readFileSync(DB_PATH, 'utf-8');
      const parsed = JSON.parse(data) as DatabaseSchema;
      const isEmpty =
        Object.keys(parsed.materials || {}).length === 0 &&
        Object.keys(parsed.purchase_requisitions || {}).length === 0 &&
        Object.keys(parsed.purchase_orders || {}).length === 0 &&
        Object.keys(parsed.goods_receipts || {}).length === 0 &&
        Object.keys(parsed.stock_reservations || {}).length === 0;
      if (isEmpty && fs.existsSync(BUNDLED_DB_PATH)) {
        const bundled = JSON.parse(fs.readFileSync(BUNDLED_DB_PATH, 'utf-8')) as DatabaseSchema;
        saveDatabase(bundled);
        return bundled;
      }
      return parsed;
    }
  } catch (error) {
    console.error('[JsonDB] Error loading database:', error);
  }
  return {
    materials: {},
    purchase_requisitions: {},
    purchase_orders: {},
    goods_receipts: {},
    stock_reservations: {},
  };
}

// Save database to file
function saveDatabase(data: DatabaseSchema): void {
  ensureDataDir();
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('[JsonDB] Error saving database:', error);
  }
}

// In-memory database with file persistence
class JsonDatabase {
  private data: DatabaseSchema;

  constructor() {
    this.data = loadDatabase();
    // Ensure purchase_orders exists for backward compatibility
    if (!this.data.purchase_orders) {
      this.data.purchase_orders = {};
    }
    if (!this.data.stock_reservations) {
      this.data.stock_reservations = {};
    }
    console.log(`[JsonDB] Loaded ${Object.keys(this.data.materials).length} materials`);
    console.log(`[JsonDB] Loaded ${Object.keys(this.data.purchase_requisitions).length} purchase requisitions`);
    console.log(`[JsonDB] Loaded ${Object.keys(this.data.purchase_orders).length} purchase orders`);
    console.log(`[JsonDB] Loaded ${Object.keys(this.data.goods_receipts).length} goods receipts`);
    console.log(`[JsonDB] Loaded ${Object.keys(this.data.stock_reservations).length} stock reservations`);
  }

  // Materials
  getMaterials(): Record<string, unknown>[] {
    return Object.values(this.data.materials).filter((m) => !m.LVORM);
  }

  getMaterial(MATNR: string): Record<string, unknown> | undefined {
    return this.data.materials[MATNR];
  }

  saveMaterial(material: Record<string, unknown>): void {
    this.data.materials[material.MATNR as string] = material;
    saveDatabase(this.data);
  }

  deleteMaterial(MATNR: string): boolean {
    if (this.data.materials[MATNR]) {
      this.data.materials[MATNR].LVORM = 1;
      saveDatabase(this.data);
      return true;
    }
    return false;
  }

  // Purchase Requisitions
  getPurchaseRequisitions(): Record<string, unknown>[] {
    return Object.values(this.data.purchase_requisitions);
  }

  getPurchaseRequisition(key: string): Record<string, unknown> | undefined {
    return this.data.purchase_requisitions[key];
  }

  savePurchaseRequisition(pr: Record<string, unknown>): void {
    const key = `${pr.BANFN}-${pr.BNFPO}`;
    this.data.purchase_requisitions[key] = pr;
    saveDatabase(this.data);
  }

  deletePurchaseRequisition(key: string): boolean {
    if (this.data.purchase_requisitions[key]) {
      delete this.data.purchase_requisitions[key];
      saveDatabase(this.data);
      return true;
    }
    return false;
  }

  // Purchase Orders
  getPurchaseOrders(): Record<string, unknown>[] {
    return Object.values(this.data.purchase_orders).filter((po) => !po.LOEKZ);
  }

  getPurchaseOrder(key: string): Record<string, unknown> | undefined {
    return this.data.purchase_orders[key];
  }

  savePurchaseOrder(po: Record<string, unknown>): void {
    const key = `${po.EBELN}-${po.EBELP}`;
    this.data.purchase_orders[key] = po;
    saveDatabase(this.data);
  }

  deletePurchaseOrder(key: string): boolean {
    if (this.data.purchase_orders[key]) {
      this.data.purchase_orders[key].LOEKZ = 'X';
      saveDatabase(this.data);
      return true;
    }
    return false;
  }

  filterPurchaseOrders(predicate: (po: Record<string, unknown>) => boolean): Record<string, unknown>[] {
    return this.getPurchaseOrders().filter(predicate);
  }

  countPurchaseOrders(): number {
    return this.getPurchaseOrders().length;
  }

  getMaxPONumber(): number {
    const pos = Object.values(this.data.purchase_orders);
    if (pos.length === 0) return 4500000000;
    const maxNum = Math.max(...pos.map((po) => parseInt(String(po.EBELN).replace(/^0+/, '') || '0', 10)));
    return maxNum;
  }

  // Goods Receipts
  getGoodsReceipts(): Record<string, unknown>[] {
    return Object.values(this.data.goods_receipts).filter((gr) => !gr.CANCELLED);
  }

  getGoodsReceipt(key: string): Record<string, unknown> | undefined {
    return this.data.goods_receipts[key];
  }

  saveGoodsReceipt(gr: Record<string, unknown>): void {
    const key = `${gr.MBLNR}-${gr.MJAHR}-${gr.ZEILE}`;
    this.data.goods_receipts[key] = gr;
    saveDatabase(this.data);
  }

  cancelGoodsReceipt(key: string): boolean {
    if (this.data.goods_receipts[key]) {
      this.data.goods_receipts[key].CANCELLED = 1;
      saveDatabase(this.data);
      return true;
    }
    return false;
  }

  // Stock Reservations
  getStockReservations(): Record<string, unknown>[] {
    return Object.values(this.data.stock_reservations);
  }

  getStockReservation(key: string): Record<string, unknown> | undefined {
    return this.data.stock_reservations[key];
  }

  saveStockReservation(res: Record<string, unknown>): void {
    const key = `${res.RSNUM}-${res.RSPOS}`;
    this.data.stock_reservations[key] = res;
    saveDatabase(this.data);
  }

  deleteStockReservation(key: string): boolean {
    if (this.data.stock_reservations[key]) {
      delete this.data.stock_reservations[key];
      saveDatabase(this.data);
      return true;
    }
    return false;
  }

  filterStockReservations(predicate: (res: Record<string, unknown>) => boolean): Record<string, unknown>[] {
    return this.getStockReservations().filter(predicate);
  }

  countStockReservations(): number {
    return this.getStockReservations().length;
  }

  // Query helpers
  filterMaterials(predicate: (m: Record<string, unknown>) => boolean): Record<string, unknown>[] {
    return this.getMaterials().filter(predicate);
  }

  filterPurchaseRequisitions(predicate: (pr: Record<string, unknown>) => boolean): Record<string, unknown>[] {
    return this.getPurchaseRequisitions().filter(predicate);
  }

  filterGoodsReceipts(predicate: (gr: Record<string, unknown>) => boolean): Record<string, unknown>[] {
    return this.getGoodsReceipts().filter(predicate);
  }

  // Count helpers
  countMaterials(): number {
    return this.getMaterials().length;
  }

  countPurchaseRequisitions(): number {
    return this.getPurchaseRequisitions().length;
  }

  countGoodsReceipts(): number {
    return this.getGoodsReceipts().length;
  }

  // Get max values for ID generation
  getMaxMaterialNumber(): number {
    const materials = this.getMaterials();
    if (materials.length === 0) return 10000000;
    const maxNum = Math.max(...materials.map((m) => parseInt(String(m.MATNR).replace(/^0+/, '') || '0', 10)));
    return maxNum;
  }

  getMaxPRNumber(): number {
    const prs = this.getPurchaseRequisitions();
    if (prs.length === 0) return 1000000000;
    const maxNum = Math.max(...prs.map((pr) => parseInt(String(pr.BANFN).replace(/^0+/, '') || '0', 10)));
    return maxNum;
  }

  getMaxGRNumber(year: string): number {
    const grs = this.getGoodsReceipts().filter((gr) => gr.MJAHR === year);
    if (grs.length === 0) return 4900000000;
    const maxNum = Math.max(...grs.map((gr) => parseInt(String(gr.MBLNR).replace(/^0+/, '') || '0', 10)));
    return maxNum;
  }

  getMaxGRDocNo(): number {
    const grs = Object.values(this.data.goods_receipts);
    if (grs.length === 0) return 6000000000;
    const maxNum = Math.max(...grs.map((gr) => parseInt(String(gr.ZZSAP_DOC_NO) || '0', 10)));
    return maxNum;
  }

  getMaxReservationNumber(): number {
    const reservations = this.getStockReservations();
    if (reservations.length === 0) return 2000000000;
    const nums = reservations
      .map((res) => parseInt(String(res.RSNUM).replace(/^0+/, '') || '0', 10))
      .filter((num) => !Number.isNaN(num));
    if (nums.length === 0) return 2000000000;
    return Math.max(...nums);
  }

  getMaxReservationDocNo(): number {
    const reservations = this.getStockReservations();
    if (reservations.length === 0) return 8000000000;
    const nums = reservations
      .map((res) => parseInt(String(res.ZZSAP_DOC_NO) || '0', 10))
      .filter((num) => !Number.isNaN(num));
    if (nums.length === 0) return 8000000000;
    return Math.max(...nums);
  }

  // Raw data access for complex queries
  getRawData(): DatabaseSchema {
    return this.data;
  }
}

// Singleton instance
const db = new JsonDatabase();

export default db;
export { DB_PATH, DATA_DIR };
