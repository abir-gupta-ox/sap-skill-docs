import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json(
    {
      status: 'healthy',
      service: 'SAP BTP Mock API',
      version: '1.0.0',
      timestamp: new Date().toISOString(),
      endpoints: {
        materials: '/api/sap/mm/material',
        health: '/api/health',
      },
    },
    {
      status: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
    }
  );
}
