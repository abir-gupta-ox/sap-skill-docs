import { NextRequest, NextResponse } from 'next/server';
import {
  PurchaseRequisitionStore,
  SAPResponse,
  SAPPurchaseRequisition,
  SAP_PR_STATUS,
} from '@/lib/materialStore';

// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PATCH, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-SAP-Client, X-Organization-Id, X-CSRF-Token, X-SAP-User',
};

// SAP Release/Approval Status Codes (FRGST - Release Status)
const SAP_RELEASE_STATUS: Record<string, string> = {
  '': 'Not Released',
  'R': 'Released',
  'X': 'Rejected',
  'P': 'Pending Approval',
  'C': 'Conditionally Released',
};

// SAP Release Indicator Codes (FRGKZ - Release Indicator)
const SAP_RELEASE_INDICATOR: Record<string, string> = {
  '1': 'Release Required',
  '2': 'Release Not Required',
  '3': 'Release Completed',
};

// SAP Approval Actions
const SAP_APPROVAL_ACTIONS: Record<string, string> = {
  'APPROVE': 'Approve Purchase Requisition',
  'REJECT': 'Reject Purchase Requisition',
  'RESET': 'Reset Approval Status',
  'BLOCK': 'Block Purchase Requisition',
  'UNBLOCK': 'Unblock Purchase Requisition',
};

// Approval Status Update Request Interface (SAP Field Names)
interface PRApprovalRequest {
  BANFN: string;              // Purchase Requisition Number
  BNFPO?: string;             // Item Number (optional - if not provided, update all items)
  FRGST: string;              // Release Status (R=Released, X=Rejected, P=Pending, ''=Not Released)
  FRGZU?: string;             // Release State (approval workflow state)
  FRGKZ?: string;             // Release Indicator (1=Required, 2=Not Required, 3=Completed)
  FRGGR?: string;             // Release Group
  FRGCO?: string;             // Release Code
  FRGDT?: string;             // Release Date (YYYYMMDD)
  FRGRL?: string;             // Release Has Occurred (X = yes)
  FRGOT?: string;             // Release Code Text
  BEDNR?: string;             // Requirement Tracking Number
  TXJCD?: string;             // Tax Jurisdiction Code
  ZZAPPROVER_ID?: string;     // Custom: Approver User ID
  ZZAPPROVER_NAME?: string;   // Custom: Approver Name
  ZZAPPROVAL_NOTES?: string;  // Custom: Approval Notes/Comments
  ZZAPPROVAL_LEVEL?: number;  // Custom: Approval Level (1, 2, 3, etc.)
  ZZOXMAINT_CALLBACK_REF?: string;  // Custom: OXmaint Callback Reference
}

// OPTIONS - Handle CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: corsHeaders,
  });
}

// GET /api/sap/mm/purchase-requisition/approval - Get approval status for PR(s)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const BANFN = searchParams.get('BANFN') || searchParams.get('pr_number');
    const BNFPO = searchParams.get('BNFPO') || searchParams.get('item_number');
    const FRGST = searchParams.get('FRGST') || searchParams.get('release_status');

    if (BANFN) {
      // Get specific PR
      if (BNFPO) {
        const prItem = PurchaseRequisitionStore.getByNumberAndItem(BANFN, BNFPO);
        if (!prItem) {
          const response: SAPResponse = {
            success: false,
            message: `Purchase requisition ${BANFN} item ${BNFPO} not found`,
            error: {
              code: 'ME/020',
              message: {
                lang: 'en',
                value: `Purchase requisition ${BANFN} item ${BNFPO} does not exist`,
              },
            },
            timestamp: new Date().toISOString(),
          };
          return NextResponse.json(response, { status: 404, headers: corsHeaders });
        }

        const approvalData = extractApprovalData(prItem);
        const response = {
          d: {
            results: approvalData,
            __metadata: {
              uri: `/sap/opu/odata/sap/API_PURCHASEREQ_PROCESS_SRV/A_PurchaseRequisitionItem(PurchaseRequisition='${prItem.BANFN}',PurchaseRequisitionItem='${prItem.BNFPO}')/ApprovalStatus`,
              type: 'API_PURCHASEREQ_PROCESS_SRV.ApprovalStatusType',
            },
          },
          success: true,
          message: 'Approval status retrieved successfully',
          data: approvalData,
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { headers: corsHeaders });
      }

      // Get all items for PR
      const prItems = PurchaseRequisitionStore.getByNumber(BANFN);
      if (prItems.length === 0) {
        const response: SAPResponse = {
          success: false,
          message: `Purchase requisition ${BANFN} not found`,
          error: {
            code: 'ME/021',
            message: {
              lang: 'en',
              value: `Purchase requisition ${BANFN} does not exist`,
            },
          },
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { status: 404, headers: corsHeaders });
      }

      const approvalDataList = prItems.map(extractApprovalData);
      const response = {
        d: {
          results: approvalDataList,
          __count: approvalDataList.length,
        },
        success: true,
        message: `Retrieved approval status for ${approvalDataList.length} items`,
        data: {
          BANFN: prItems[0].BANFN,
          items: approvalDataList,
          __count: approvalDataList.length,
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { headers: corsHeaders });
    }

    // Get all PRs with optional release status filter
    let prs = PurchaseRequisitionStore.getAll();
    if (FRGST) {
      prs = prs.filter((pr) => pr.FRGST === FRGST);
    }

    const approvalDataList = prs.map(extractApprovalData);
    const response = {
      d: {
        results: approvalDataList,
        __count: approvalDataList.length,
        __metadata: {
          SAP_RELEASE_STATUS,
          SAP_RELEASE_INDICATOR,
          SAP_PR_STATUS,
          SAP_APPROVAL_ACTIONS,
        },
      },
      success: true,
      message: `Retrieved approval status for ${approvalDataList.length} purchase requisition items`,
      data: {
        results: approvalDataList,
        __count: approvalDataList.length,
      },
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM PR Approval API] GET Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Internal server error',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}

// POST /api/sap/mm/purchase-requisition/approval - Update PR Approval Status (Callback from SAP)
// This endpoint receives approval status updates from SAP workflow or external approval systems
export async function POST(request: NextRequest) {
  try {
    const body: PRApprovalRequest = await request.json();

    // Validate required fields
    if (!body.BANFN) {
      const response: SAPResponse = {
        success: false,
        message: 'Purchase requisition number (BANFN) is required',
        error: {
          code: 'ME/022',
          message: {
            lang: 'en',
            value: 'Please provide BANFN in the request body',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    if (!body.FRGST) {
      const response: SAPResponse = {
        success: false,
        message: 'Release status (FRGST) is required',
        error: {
          code: 'ME/023',
          message: {
            lang: 'en',
            value: `Please provide FRGST. Valid values: ${Object.entries(SAP_RELEASE_STATUS)
              .map(([k, v]) => `'${k || '(empty)'}' (${v})`).join(', ')}`,
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    // Validate release status
    if (!Object.keys(SAP_RELEASE_STATUS).includes(body.FRGST)) {
      const response: SAPResponse = {
        success: false,
        message: 'Invalid release status (FRGST)',
        error: {
          code: 'ME/024',
          message: {
            lang: 'en',
            value: `Valid release status values: ${Object.entries(SAP_RELEASE_STATUS)
              .map(([k, v]) => `'${k || '(empty)'}' (${v})`).join(', ')}`,
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    // Get approver from headers or body
    const approver = body.ZZAPPROVER_ID || request.headers.get('X-SAP-User') || 'SAP_WORKFLOW';

    // Determine new status based on release status
    let newStatus: string;
    switch (body.FRGST) {
      case 'R': // Released/Approved
        newStatus = 'A';
        break;
      case 'X': // Rejected
        newStatus = 'B'; // Blocked
        break;
      case 'P': // Pending
        newStatus = 'N'; // New/Not Processed
        break;
      case '': // Not Released
        newStatus = 'N';
        break;
      default:
        newStatus = 'N';
    }

    // Set release date if approving
    const releaseDate = body.FRGDT || (body.FRGST === 'R' ? formatSAPDate(new Date()) : undefined);

    // Update PR item(s)
    const paddedBanfn = body.BANFN.padStart(10, '0');
    let updatedItems: SAPPurchaseRequisition[] = [];

    if (body.BNFPO) {
      // Update specific item
      const updated = PurchaseRequisitionStore.updateApprovalStatus(
        paddedBanfn,
        body.BNFPO.padStart(5, '0'),
        {
          STATU: newStatus,
          FRGST: body.FRGST,
          FRGZU: body.FRGZU,
          FRGKZ: body.FRGKZ || (body.FRGST === 'R' ? '3' : '1'),
          FRGDT: releaseDate,
          FRGRL: body.FRGST === 'R' ? 'X' : '',
          ZZAPPROVER_ID: approver,
          ZZAPPROVER_NAME: body.ZZAPPROVER_NAME,
          ZZAPPROVAL_NOTES: body.ZZAPPROVAL_NOTES,
          ZZAPPROVAL_LEVEL: body.ZZAPPROVAL_LEVEL,
        },
        approver
      );

      if (updated) {
        updatedItems.push(updated);
      }
    } else {
      // Update all items for this PR
      const prItems = PurchaseRequisitionStore.getByNumber(paddedBanfn);
      for (const item of prItems) {
        const updated = PurchaseRequisitionStore.updateApprovalStatus(
          item.BANFN,
          item.BNFPO,
          {
            STATU: newStatus,
            FRGST: body.FRGST,
            FRGZU: body.FRGZU,
            FRGKZ: body.FRGKZ || (body.FRGST === 'R' ? '3' : '1'),
            FRGDT: releaseDate,
            FRGRL: body.FRGST === 'R' ? 'X' : '',
            ZZAPPROVER_ID: approver,
            ZZAPPROVER_NAME: body.ZZAPPROVER_NAME,
            ZZAPPROVAL_NOTES: body.ZZAPPROVAL_NOTES,
            ZZAPPROVAL_LEVEL: body.ZZAPPROVAL_LEVEL,
          },
          approver
        );
        if (updated) {
          updatedItems.push(updated);
        }
      }
    }

    if (updatedItems.length === 0) {
      const response: SAPResponse = {
        success: false,
        message: `Purchase requisition ${body.BANFN} not found`,
        error: {
          code: 'ME/025',
          message: {
            lang: 'en',
            value: 'Cannot update approval status for non-existent purchase requisition',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 404, headers: corsHeaders });
    }

    const statusDescription = SAP_RELEASE_STATUS[body.FRGST] || 'Unknown';
    console.log(`[SAP MM PR Approval API] Updated PR ${paddedBanfn}: ${statusDescription} by ${approver}`);

    const response = {
      d: {
        results: updatedItems.length === 1 ? updatedItems[0] : updatedItems,
        __metadata: {
          uri: `/sap/opu/odata/sap/API_PURCHASEREQ_PROCESS_SRV/A_PurchaseRequisitionItem(PurchaseRequisition='${paddedBanfn}')/ApprovalStatus`,
          type: 'API_PURCHASEREQ_PROCESS_SRV.ApprovalStatusType',
        },
      },
      success: true,
      message: `Purchase requisition ${paddedBanfn} approval status updated to '${statusDescription}' for ${updatedItems.length} item(s)`,
      data: {
        BANFN: paddedBanfn,
        FRGST: body.FRGST,
        FRGST_TEXT: statusDescription,
        STATU: newStatus,
        STATU_TEXT: SAP_PR_STATUS[newStatus],
        ZZAPPROVER_ID: approver,
        FRGDT: releaseDate,
        items_updated: updatedItems.length,
        items: updatedItems.map(extractApprovalData),
      },
      ZZSAP_DOC_NO: updatedItems[0]?.ZZSAP_DOC_NO,
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM PR Approval API] POST Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Failed to update approval status',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}

// PATCH /api/sap/mm/purchase-requisition/approval - Partial update (same as POST)
export async function PATCH(request: NextRequest) {
  return POST(request);
}

// Helper function to extract approval-related data from PR
function extractApprovalData(pr: SAPPurchaseRequisition) {
  return {
    BANFN: pr.BANFN,
    BNFPO: pr.BNFPO,
    TXZ01: pr.TXZ01,
    STATU: pr.STATU,
    STATU_TEXT: SAP_PR_STATUS[pr.STATU] || 'Unknown',
    FRGST: pr.FRGST || '',
    FRGST_TEXT: SAP_RELEASE_STATUS[pr.FRGST || ''] || 'Not Released',
    FRGZU: pr.FRGZU || '',
    FRGKZ: pr.FRGKZ || '1',
    FRGKZ_TEXT: SAP_RELEASE_INDICATOR[pr.FRGKZ || '1'] || 'Release Required',
    FRGDT: pr.FRGDT || '',
    FRGRL: pr.FRGRL || '',
    ERNAM: pr.ERNAM,
    ERDAT: pr.ERDAT,
    AENAM: pr.AENAM,
    AEDAT: pr.AEDAT,
    ZZAPPROVER_ID: pr.ZZAPPROVER_ID || '',
    ZZAPPROVER_NAME: pr.ZZAPPROVER_NAME || '',
    ZZAPPROVAL_NOTES: pr.ZZAPPROVAL_NOTES || '',
    ZZAPPROVAL_LEVEL: pr.ZZAPPROVAL_LEVEL || 0,
    ZZOXMAINT_WO_REF: pr.ZZOXMAINT_WO_REF || '',
    ZZSAP_DOC_NO: pr.ZZSAP_DOC_NO,
  };
}

// Helper function to format date as SAP date (YYYYMMDD)
function formatSAPDate(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}${month}${day}`;
}
