import { NextRequest, NextResponse } from 'next/server';
import {
  PurchaseRequisitionStore,
  PurchaseRequisitionCreateRequest,
  SAPResponse,
  SAPPurchaseRequisition,
  SAP_PR_DOCUMENT_TYPES,
  SAP_PURCHASING_ORGS,
  SAP_PURCHASING_GROUPS,
  SAP_PLANTS,
  SAP_STORAGE_LOCATIONS,
  SAP_UNITS,
  SAP_ACCOUNT_ASSIGNMENT_CATEGORIES,
  SAP_PR_STATUS,
  SAP_PR_ITEM_CATEGORIES,
} from '@/lib/materialStore';

// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-SAP-Client, X-Organization-Id, X-CSRF-Token, X-SAP-User',
};

// OPTIONS - Handle CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: corsHeaders,
  });
}

// GET /api/sap/mm/purchase-requisition - Get all PRs or search
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);

    // Query parameters - SAP field names with aliases
    const BANFN = searchParams.get('BANFN') || searchParams.get('pr_number') || undefined;
    const BNFPO = searchParams.get('BNFPO') || searchParams.get('item_number') || undefined;
    const WERKS = searchParams.get('WERKS') || searchParams.get('plant') || undefined;
    const EKORG = searchParams.get('EKORG') || searchParams.get('purchasing_org') || undefined;
    const EKGRP = searchParams.get('EKGRP') || searchParams.get('purchasing_group') || undefined;
    const STATU = searchParams.get('STATU') || searchParams.get('status') || undefined;
    const AUFNR = searchParams.get('AUFNR') || searchParams.get('work_order') || undefined;
    const ZZOXMAINT_WO_REF = searchParams.get('ZZOXMAINT_WO_REF') || searchParams.get('oxmaint_ref') || undefined;

    // If specific PR number requested
    if (BANFN) {
      // If item number also provided, get specific item
      if (BNFPO) {
        const prItem = PurchaseRequisitionStore.getByNumberAndItem(BANFN, BNFPO);
        if (!prItem) {
          const response: SAPResponse = {
            success: false,
            message: `Purchase requisition ${BANFN} item ${BNFPO} not found`,
            error: {
              code: 'ME/001',
              message: {
                lang: 'en',
                value: `Purchase requisition ${BANFN} item ${BNFPO} does not exist`,
              },
            },
            timestamp: new Date().toISOString(),
          };
          return NextResponse.json(response, { status: 404, headers: corsHeaders });
        }

        const response: SAPResponse<SAPPurchaseRequisition> = {
          d: {
            results: prItem,
            __metadata: {
              uri: `/sap/opu/odata/sap/API_PURCHASEREQ_PROCESS_SRV/A_PurchaseRequisitionItem(PurchaseRequisition='${prItem.BANFN}',PurchaseRequisitionItem='${prItem.BNFPO}')`,
              type: 'API_PURCHASEREQ_PROCESS_SRV.A_PurchaseRequisitionItemType',
            },
          },
          success: true,
          message: 'Purchase requisition item retrieved successfully',
          data: prItem,
          ZZSAP_DOC_NO: prItem.ZZSAP_DOC_NO,
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { headers: corsHeaders });
      }

      // Get all items for this PR
      const prItems = PurchaseRequisitionStore.getByNumber(BANFN);
      if (prItems.length === 0) {
        const response: SAPResponse = {
          success: false,
          message: `Purchase requisition ${BANFN} not found`,
          error: {
            code: 'ME/002',
            message: {
              lang: 'en',
              value: `Purchase requisition ${BANFN} does not exist`,
            },
          },
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { status: 404, headers: corsHeaders });
      }

      const response = {
        d: {
          results: prItems,
          __count: prItems.length,
          __metadata: {
            uri: `/sap/opu/odata/sap/API_PURCHASEREQ_PROCESS_SRV/A_PurchaseRequisitionItem`,
            type: 'Collection(API_PURCHASEREQ_PROCESS_SRV.A_PurchaseRequisitionItemType)',
          },
        },
        success: true,
        message: `Retrieved ${prItems.length} items for purchase requisition ${BANFN}`,
        data: {
          BANFN: prItems[0].BANFN,
          items: prItems,
          __count: prItems.length,
        },
        ZZSAP_DOC_NO: prItems[0].ZZSAP_DOC_NO,
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { headers: corsHeaders });
    }

    // Get by OXmaint reference
    if (ZZOXMAINT_WO_REF) {
      const prItems = PurchaseRequisitionStore.getByOxmaintRef(ZZOXMAINT_WO_REF);
      const response = {
        d: {
          results: prItems,
          __count: prItems.length,
        },
        success: true,
        message: `Retrieved ${prItems.length} purchase requisition items for OXmaint reference ${ZZOXMAINT_WO_REF}`,
        data: {
          results: prItems,
          __count: prItems.length,
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { headers: corsHeaders });
    }

    // Get by Work Order
    if (AUFNR) {
      const prItems = PurchaseRequisitionStore.getByWorkOrder(AUFNR);
      const response = {
        d: {
          results: prItems,
          __count: prItems.length,
        },
        success: true,
        message: `Retrieved ${prItems.length} purchase requisition items for work order ${AUFNR}`,
        data: {
          results: prItems,
          __count: prItems.length,
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { headers: corsHeaders });
    }

    // Get all PRs with filters
    const purchaseRequisitions = PurchaseRequisitionStore.getAll({
      WERKS,
      EKORG,
      EKGRP,
      STATU,
      AUFNR,
    });

    const response = {
      d: {
        results: purchaseRequisitions,
        __count: purchaseRequisitions.length,
        __metadata: {
          uri: '/sap/opu/odata/sap/API_PURCHASEREQ_PROCESS_SRV/A_PurchaseRequisitionItem',
          type: 'Collection(API_PURCHASEREQ_PROCESS_SRV.A_PurchaseRequisitionItemType)',
        },
      },
      success: true,
      message: `Retrieved ${purchaseRequisitions.length} purchase requisition items`,
      data: {
        results: purchaseRequisitions,
        __count: purchaseRequisitions.length,
        __metadata: {
          SAP_PR_DOCUMENT_TYPES,
          SAP_PURCHASING_ORGS,
          SAP_PURCHASING_GROUPS,
          SAP_PLANTS,
          SAP_STORAGE_LOCATIONS,
          SAP_UNITS,
          SAP_ACCOUNT_ASSIGNMENT_CATEGORIES,
          SAP_PR_STATUS,
          SAP_PR_ITEM_CATEGORIES,
        },
      },
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM Purchase Requisition API] GET Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Internal server error',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}

// POST /api/sap/mm/purchase-requisition - Create Purchase Requisition (ME51N)
// Creates PR from Work Order in OXmaint
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Support both single item and multiple items
    const items: PurchaseRequisitionCreateRequest[] = Array.isArray(body.items) ? body.items : [body];

    // Validate each item
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const itemLabel = items.length > 1 ? ` (item ${i + 1})` : '';

      // Validate required fields (SAP field names)
      const requiredFields: (keyof PurchaseRequisitionCreateRequest)[] = [
        'BSART', 'TXZ01', 'MENGE', 'MEINS', 'WERKS', 'EKGRP', 'EKORG'
      ];
      const missingFields = requiredFields.filter((field) => {
        if (field === 'MENGE') return item[field] === undefined || item[field] === null;
        return !item[field];
      });

      if (missingFields.length > 0) {
        const response: SAPResponse = {
          success: false,
          message: `Validation failed: Missing required fields${itemLabel}`,
          error: {
            code: 'ME/003',
            message: {
              lang: 'en',
              value: `Missing required fields: ${missingFields.join(', ')}. ` +
                `Required: BSART (Document Type), TXZ01 (Description), MENGE (Quantity), ` +
                `MEINS (Unit), WERKS (Plant), EKGRP (Purchasing Group), EKORG (Purchasing Org)`,
            },
          },
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { status: 400, headers: corsHeaders });
      }

      // Validate document type
      if (!Object.keys(SAP_PR_DOCUMENT_TYPES).includes(item.BSART)) {
        const response: SAPResponse = {
          success: false,
          message: `Validation failed: Invalid document type (BSART)${itemLabel}`,
          error: {
            code: 'ME/004',
            message: {
              lang: 'en',
              value: `Valid document types (BSART): ${Object.entries(SAP_PR_DOCUMENT_TYPES)
                .map(([k, v]) => `${k} (${v})`).join(', ')}`,
            },
          },
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { status: 400, headers: corsHeaders });
      }

      // Validate plant
      if (!Object.keys(SAP_PLANTS).includes(item.WERKS)) {
        const response: SAPResponse = {
          success: false,
          message: `Validation failed: Invalid plant code (WERKS)${itemLabel}`,
          error: {
            code: 'ME/005',
            message: {
              lang: 'en',
              value: `Valid plant codes (WERKS): ${Object.entries(SAP_PLANTS)
                .map(([k, v]) => `${k} (${v})`).join(', ')}`,
            },
          },
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { status: 400, headers: corsHeaders });
      }

      // Validate purchasing organization
      if (!Object.keys(SAP_PURCHASING_ORGS).includes(item.EKORG)) {
        const response: SAPResponse = {
          success: false,
          message: `Validation failed: Invalid purchasing organization (EKORG)${itemLabel}`,
          error: {
            code: 'ME/006',
            message: {
              lang: 'en',
              value: `Valid purchasing organizations (EKORG): ${Object.entries(SAP_PURCHASING_ORGS)
                .map(([k, v]) => `${k} (${v})`).join(', ')}`,
            },
          },
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { status: 400, headers: corsHeaders });
      }

      // Validate purchasing group
      if (!Object.keys(SAP_PURCHASING_GROUPS).includes(item.EKGRP)) {
        const response: SAPResponse = {
          success: false,
          message: `Validation failed: Invalid purchasing group (EKGRP)${itemLabel}`,
          error: {
            code: 'ME/007',
            message: {
              lang: 'en',
              value: `Valid purchasing groups (EKGRP): ${Object.entries(SAP_PURCHASING_GROUPS)
                .map(([k, v]) => `${k} (${v})`).join(', ')}`,
            },
          },
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { status: 400, headers: corsHeaders });
      }

      // Validate quantity
      if (item.MENGE <= 0) {
        const response: SAPResponse = {
          success: false,
          message: `Validation failed: Quantity must be greater than 0${itemLabel}`,
          error: {
            code: 'ME/008',
            message: {
              lang: 'en',
              value: 'MENGE (Quantity) must be a positive number',
            },
          },
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { status: 400, headers: corsHeaders });
      }

      // Validate account assignment category if provided
      if (item.KNTTP && !Object.keys(SAP_ACCOUNT_ASSIGNMENT_CATEGORIES).includes(item.KNTTP)) {
        const response: SAPResponse = {
          success: false,
          message: `Validation failed: Invalid account assignment category (KNTTP)${itemLabel}`,
          error: {
            code: 'ME/009',
            message: {
              lang: 'en',
              value: `Valid account assignment categories (KNTTP): ${Object.entries(SAP_ACCOUNT_ASSIGNMENT_CATEGORIES)
                .map(([k, v]) => `${k || '(empty)'} (${v})`).join(', ')}`,
            },
          },
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { status: 400, headers: corsHeaders });
      }
    }

    // Get user from headers (in real SAP, this would be from authentication)
    const createdBy = request.headers.get('X-SAP-User') || 'OXMAINT_SYNC';

    // Create PR(s)
    let createdItems: SAPPurchaseRequisition[];
    if (items.length > 1) {
      // Multiple items - create with same PR number
      createdItems = PurchaseRequisitionStore.createMultiple(items, createdBy);
    } else {
      // Single item
      const newPR = PurchaseRequisitionStore.create(items[0], createdBy);
      createdItems = [newPR];
    }

    console.log(`[SAP MM Purchase Requisition API] Created PR: ${createdItems[0].BANFN} with ${createdItems.length} item(s)`);

    const response: SAPResponse<SAPPurchaseRequisition[]> = {
      d: {
        results: createdItems.length === 1 ? createdItems[0] as unknown as SAPPurchaseRequisition[] : createdItems,
        __metadata: {
          uri: `/sap/opu/odata/sap/API_PURCHASEREQ_PROCESS_SRV/A_PurchaseRequisitionItem(PurchaseRequisition='${createdItems[0].BANFN}',PurchaseRequisitionItem='${createdItems[0].BNFPO}')`,
          type: 'API_PURCHASEREQ_PROCESS_SRV.A_PurchaseRequisitionItemType',
        },
      },
      success: true,
      message: `Purchase requisition ${createdItems[0].BANFN} created successfully in SAP with ${createdItems.length} item(s)`,
      data: createdItems.length === 1 ? createdItems[0] as unknown as SAPPurchaseRequisition[] : createdItems,
      ZZSAP_DOC_NO: createdItems[0].ZZSAP_DOC_NO,
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { status: 201, headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM Purchase Requisition API] POST Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Failed to create purchase requisition in SAP',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}

// PUT /api/sap/mm/purchase-requisition - Update Purchase Requisition (ME52N)
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { BANFN, BNFPO, ...updates } = body;

    if (!BANFN) {
      const response: SAPResponse = {
        success: false,
        message: 'Purchase requisition number (BANFN) is required for update',
        error: {
          code: 'ME/010',
          message: {
            lang: 'en',
            value: 'Please provide BANFN in the request body',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    if (!BNFPO) {
      const response: SAPResponse = {
        success: false,
        message: 'Item number (BNFPO) is required for update',
        error: {
          code: 'ME/011',
          message: {
            lang: 'en',
            value: 'Please provide BNFPO (item number) in the request body',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    // Check if PR item exists
    const existing = PurchaseRequisitionStore.getByNumberAndItem(BANFN, BNFPO);
    if (!existing) {
      const response: SAPResponse = {
        success: false,
        message: `Purchase requisition ${BANFN} item ${BNFPO} not found`,
        error: {
          code: 'ME/012',
          message: {
            lang: 'en',
            value: 'Cannot update non-existent purchase requisition item',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 404, headers: corsHeaders });
    }

    // Check if PR is in a state that allows updates
    if (existing.STATU === 'A' || existing.STATU === 'L') {
      const response: SAPResponse = {
        success: false,
        message: `Purchase requisition ${BANFN} cannot be modified (status: ${SAP_PR_STATUS[existing.STATU]})`,
        error: {
          code: 'ME/013',
          message: {
            lang: 'en',
            value: 'Purchase requisition is released or locked and cannot be modified',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 409, headers: corsHeaders });
    }

    // Get user from headers
    const modifiedBy = request.headers.get('X-SAP-User') || 'OXMAINT_SYNC';

    // Update PR item
    const updatedPR = PurchaseRequisitionStore.update(BANFN, BNFPO, updates, modifiedBy);

    console.log(`[SAP MM Purchase Requisition API] Updated PR: ${BANFN} item ${BNFPO}`);

    const response: SAPResponse<SAPPurchaseRequisition> = {
      d: {
        results: updatedPR!,
        __metadata: {
          uri: `/sap/opu/odata/sap/API_PURCHASEREQ_PROCESS_SRV/A_PurchaseRequisitionItem(PurchaseRequisition='${updatedPR!.BANFN}',PurchaseRequisitionItem='${updatedPR!.BNFPO}')`,
          type: 'API_PURCHASEREQ_PROCESS_SRV.A_PurchaseRequisitionItemType',
        },
      },
      success: true,
      message: `Purchase requisition ${BANFN} item ${BNFPO} updated successfully in SAP`,
      data: updatedPR!,
      ZZSAP_DOC_NO: updatedPR!.ZZSAP_DOC_NO,
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM Purchase Requisition API] PUT Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Failed to update purchase requisition in SAP',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}

// DELETE /api/sap/mm/purchase-requisition - Delete Purchase Requisition
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const BANFN = searchParams.get('BANFN') || searchParams.get('pr_number');
    const BNFPO = searchParams.get('BNFPO') || searchParams.get('item_number');

    if (!BANFN) {
      const response: SAPResponse = {
        success: false,
        message: 'Purchase requisition number (BANFN) is required',
        error: {
          code: 'ME/014',
          message: {
            lang: 'en',
            value: 'Please provide BANFN as query parameter',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    const deletedBy = request.headers.get('X-SAP-User') || 'OXMAINT_SYNC';
    let deleted: boolean;
    let message: string;

    if (BNFPO) {
      // Delete specific item
      deleted = PurchaseRequisitionStore.delete(BANFN, BNFPO, deletedBy);
      message = `Purchase requisition ${BANFN} item ${BNFPO}`;
    } else {
      // Delete all items for this PR
      deleted = PurchaseRequisitionStore.deleteByNumber(BANFN, deletedBy);
      message = `Purchase requisition ${BANFN} (all items)`;
    }

    if (!deleted) {
      const response: SAPResponse = {
        success: false,
        message: `${message} not found`,
        error: {
          code: 'ME/015',
          message: {
            lang: 'en',
            value: 'Cannot delete non-existent purchase requisition',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 404, headers: corsHeaders });
    }

    console.log(`[SAP MM Purchase Requisition API] Deleted: ${message}`);

    const response: SAPResponse = {
      success: true,
      message: `${message} marked for deletion in SAP`,
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM Purchase Requisition API] DELETE Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Failed to delete purchase requisition from SAP',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}
