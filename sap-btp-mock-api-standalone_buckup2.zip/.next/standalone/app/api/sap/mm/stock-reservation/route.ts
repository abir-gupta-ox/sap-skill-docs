import { NextRequest, NextResponse } from 'next/server';
import {
  MaterialStore,
  SAP_MOVEMENT_TYPES,
  SAP_PLANTS,
  SAP_STORAGE_LOCATIONS,
  SAP_UNITS,
  SAPResponse,
  SAPStockReservation,
  StockReservationCreateRequest,
  StockReservationStore,
} from '@/lib/materialStore';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-SAP-Client, X-Organization-Id, X-CSRF-Token, X-SAP-User',
};

interface SAPODataResponse {
  d?: {
    results?: SAPStockReservation | SAPStockReservation[];
    __count?: number;
    __metadata?: {
      uri: string;
      type: string;
    };
  };
  success: boolean;
  message: string;
  data?: {
    results: SAPStockReservation[];
    __count: number;
  } | SAPStockReservation;
  RSNUM?: string;
  RSPOS?: string;
  ZZSAP_DOC_NO?: string;
  error?: {
    code: string;
    message: {
      lang: string;
      value: string;
    };
  };
  timestamp: string;
}

const unwrapODataPayload = (payload: unknown): Record<string, unknown> | Record<string, unknown>[] => {
  if (!payload || typeof payload !== 'object') return {};
  if (Array.isArray(payload)) return payload as Record<string, unknown>[];
  const maybe = payload as Record<string, unknown>;
  if (Array.isArray(maybe.items)) {
    return maybe.items as Record<string, unknown>[];
  }
  if (maybe.d && typeof maybe.d === 'object') {
    const d = maybe.d as Record<string, unknown>;
    if (Array.isArray((d as Record<string, unknown>).items)) {
      return (d as Record<string, unknown>).items as Record<string, unknown>[];
    }
    if (d.results && (typeof d.results === 'object' || Array.isArray(d.results))) {
      return d.results as Record<string, unknown> | Record<string, unknown>[];
    }
    return d;
  }
  if (Array.isArray(maybe.value) && maybe.value.length > 0 && typeof maybe.value[0] === 'object') {
    return maybe.value as Record<string, unknown>[];
  }
  return maybe;
};

const normalizeReservationPayload = (item: Record<string, unknown>): StockReservationCreateRequest => {
  const BDMNG = (item.BDMNG ?? item.MENGE ?? item.quantity) as number | undefined;
  const MEINS = (item.MEINS ?? item.unit) as string | undefined;

  return {
    RSNUM: (item.RSNUM ?? item.stock_reservation_number ?? item.reservation_number) as string | undefined,
    RSPOS: (item.RSPOS ?? item.reservation_item) as string | undefined,
    MATNR: (item.MATNR ?? item.material_number ?? item.sap_material_number) as string | undefined,
    WERKS: (item.WERKS ?? item.plant ?? item.sap_plant) as string | undefined,
    LGORT: (item.LGORT ?? item.storage_location) as string | undefined,
    BDMNG: typeof BDMNG === 'number' ? BDMNG : BDMNG === undefined ? undefined : Number(BDMNG),
    MEINS: MEINS,
    BDTER: (item.BDTER ?? item.requirement_date) as string | undefined,
    BWART: (item.BWART ?? item.movement_type) as string | undefined,
    AUFNR: (item.AUFNR ?? item.work_order) as string | undefined,
    KOSTL: (item.KOSTL ?? item.cost_center) as string | undefined,
    SGTXT: (item.SGTXT ?? item.item_text) as string | undefined,
    ZZOXMAINT_WO_REF: (item.ZZOXMAINT_WO_REF ?? item.oxmaint_work_order_ref) as string | undefined,
  };
};

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: corsHeaders,
  });
}

// GET /api/sap/mm/stock-reservation - Retrieve Stock Reservations
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const timestamp = new Date().toISOString();

  try {
    const RSNUM = searchParams.get('RSNUM') || searchParams.get('stock_reservation_number') || undefined;
    const RSPOS = searchParams.get('RSPOS') || searchParams.get('reservation_item') || undefined;

    if (RSNUM && RSPOS) {
      const item = StockReservationStore.getByNumberAndItem(RSNUM, RSPOS);
      if (!item) {
        const response: SAPODataResponse = {
          success: false,
          message: `Stock reservation ${RSNUM}/${RSPOS} not found`,
          error: {
            code: 'SR_NOT_FOUND',
            message: { lang: 'en', value: `Reservation ${RSNUM} item ${RSPOS} does not exist` },
          },
          timestamp,
        };
        return NextResponse.json(response, { status: 404, headers: corsHeaders });
      }

      const response: SAPODataResponse = {
        d: {
          results: item,
          __metadata: {
            uri: `/api/sap/mm/stock-reservation('${item.RSNUM}/${item.RSPOS}')`,
            type: 'SAP.StockReservation',
          },
        },
        success: true,
        message: 'Stock reservation item retrieved successfully',
        data: item,
        RSNUM: item.RSNUM,
        RSPOS: item.RSPOS,
        ZZSAP_DOC_NO: item.ZZSAP_DOC_NO,
        timestamp,
      };
      return NextResponse.json(response, { headers: corsHeaders });
    }

    if (RSNUM) {
      const items = StockReservationStore.getByNumber(RSNUM);
      if (items.length === 0) {
        const response: SAPODataResponse = {
          success: false,
          message: `Stock reservation ${RSNUM} not found`,
          error: {
            code: 'SR_NOT_FOUND',
            message: { lang: 'en', value: `Reservation ${RSNUM} does not exist` },
          },
          timestamp,
        };
        return NextResponse.json(response, { status: 404, headers: corsHeaders });
      }

      const response: SAPODataResponse = {
        d: {
          results: items,
          __count: items.length,
        },
        success: true,
        message: `Retrieved ${items.length} items for reservation ${RSNUM}`,
        data: { results: items, __count: items.length },
        RSNUM: items[0].RSNUM,
        ZZSAP_DOC_NO: items[0].ZZSAP_DOC_NO,
        timestamp,
      };
      return NextResponse.json(response, { headers: corsHeaders });
    }

    const filters = {
      WERKS: searchParams.get('WERKS') || searchParams.get('plant') || undefined,
      LGORT: searchParams.get('LGORT') || searchParams.get('storage_location') || undefined,
      AUFNR: searchParams.get('AUFNR') || searchParams.get('work_order') || undefined,
      MATNR: searchParams.get('MATNR') || searchParams.get('material_number') || undefined,
      RSNUM: searchParams.get('RSNUM') || searchParams.get('stock_reservation_number') || undefined,
    };

    const oxmaintRef = searchParams.get('ZZOXMAINT_WO_REF') || searchParams.get('oxmaint_ref');
    if (oxmaintRef) {
      const results = StockReservationStore.getByOxmaintRef(oxmaintRef);
      const response: SAPODataResponse = {
        d: { results, __count: results.length },
        success: true,
        message: `Retrieved ${results.length} reservations for OXmaint reference ${oxmaintRef}`,
        data: { results, __count: results.length },
        timestamp,
      };
      return NextResponse.json(response, { headers: corsHeaders });
    }

    const results = StockReservationStore.getAll(filters);
    const response: SAPODataResponse = {
      d: { results, __count: results.length },
      success: true,
      message: `Retrieved ${results.length} stock reservations`,
      data: { results, __count: results.length },
      timestamp,
    };
    return NextResponse.json(response, { headers: corsHeaders });
  } catch (error) {
    const response: SAPODataResponse = {
      success: false,
      message: 'Failed to retrieve stock reservations',
      error: {
        code: 'SR_READ_ERROR',
        message: { lang: 'en', value: error instanceof Error ? error.message : 'Unknown error' },
      },
      timestamp,
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}

// POST /api/sap/mm/stock-reservation - Create Stock Reservation (MB21)
export async function POST(request: NextRequest) {
  const timestamp = new Date().toISOString();

  try {
    const rawBody = await request.json();
    const payload = unwrapODataPayload(rawBody);
    const createdBy = request.headers.get('X-SAP-User') || 'OXMAINT_SYNC';

    const rawItems = Array.isArray(payload)
      ? (payload as Record<string, unknown>[])
      : ([payload] as Record<string, unknown>[]);
    const items = rawItems.map(normalizeReservationPayload);

    const errors: string[] = [];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const prefix = items.length > 1 ? `Item ${i + 1}: ` : '';

      if (!item.RSNUM) errors.push(`${prefix}stock_reservation_number (RSNUM) is required`);
      if (!item.MATNR) errors.push(`${prefix}MATNR (Material Number) is required`);
      if (!item.ZZOXMAINT_WO_REF) errors.push(`${prefix}ZZOXMAINT_WO_REF (OXmaint UUID) is required`);

      if (item.WERKS && !SAP_PLANTS[item.WERKS]) {
        errors.push(`${prefix}Invalid Plant: ${item.WERKS}. Valid plants: ${Object.keys(SAP_PLANTS).join(', ')}`);
      }
      if (item.LGORT && !SAP_STORAGE_LOCATIONS[item.LGORT]) {
        errors.push(`${prefix}Invalid Storage Location: ${item.LGORT}. Valid locations: ${Object.keys(SAP_STORAGE_LOCATIONS).join(', ')}`);
      }
      if (item.MEINS && !SAP_UNITS[item.MEINS]) {
        errors.push(`${prefix}Invalid Unit of Measure: ${item.MEINS}. Valid units: ${Object.keys(SAP_UNITS).join(', ')}`);
      }
      if (item.BWART && !SAP_MOVEMENT_TYPES[item.BWART]) {
        errors.push(`${prefix}Invalid Movement Type: ${item.BWART}. Valid types: ${Object.keys(SAP_MOVEMENT_TYPES).join(', ')}`);
      }
      if (item.BDMNG !== undefined && item.BDMNG <= 0) {
        errors.push(`${prefix}BDMNG must be greater than 0`);
      }

      if (item.MATNR) {
        const material = MaterialStore.getByNumber(item.MATNR);
        if (!material) {
          errors.push(`${prefix}Material ${item.MATNR} not found in SAP`);
        }
      }
    }

    if (errors.length > 0) {
      const response: SAPResponse = {
        success: false,
        message: 'Validation failed',
        error: {
          code: 'SR_VALIDATION_ERROR',
          message: { lang: 'en', value: errors.join('; ') },
        },
        timestamp,
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    let results: SAPStockReservation[];
    if (items.length > 1) {
      results = StockReservationStore.createMultiple(items, createdBy);
    } else {
      const created = StockReservationStore.create(items[0], createdBy);
      results = [created];
    }

    const first = results[0];
    const response: SAPODataResponse = {
      d: {
        results: results.length === 1 ? first : results,
        __metadata: {
          uri: `/api/sap/mm/stock-reservation('${first.RSNUM}')`,
          type: 'SAP.StockReservation',
        },
      },
      success: true,
      message: `Stock reservation ${first.RSNUM} created successfully with ${results.length} item(s)`,
      data: results.length === 1 ? first : { results, __count: results.length },
      RSNUM: first.RSNUM,
      RSPOS: first.RSPOS,
      ZZSAP_DOC_NO: first.ZZSAP_DOC_NO,
      timestamp,
    };

    return NextResponse.json(response, { status: 201, headers: corsHeaders });
  } catch (error) {
    const response: SAPResponse = {
      success: false,
      message: 'Failed to create stock reservation',
      error: {
        code: 'SR_CREATE_ERROR',
        message: { lang: 'en', value: error instanceof Error ? error.message : 'Unknown error' },
      },
      timestamp,
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}
