import { NextRequest, NextResponse } from 'next/server';
import {
  GoodsReceiptStore,
  MaterialStore,
  SAPResponse,
  SAP_MOVEMENT_TYPES,
  SAP_PLANTS,
  SAP_STORAGE_LOCATIONS,
  SAP_UNITS,
} from '@/lib/materialStore';

// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-SAP-Client, X-Organization-Id, X-CSRF-Token, X-SAP-User',
};

const unwrapODataPayload = (payload: unknown): Record<string, unknown> => {
  if (!payload || typeof payload !== 'object') return {};
  const maybe = payload as Record<string, unknown>;
  if (maybe.d && typeof maybe.d === 'object') {
    const d = maybe.d as Record<string, unknown>;
    if (d.results && typeof d.results === 'object') {
      return d.results as Record<string, unknown>;
    }
    return d;
  }
  if (Array.isArray(maybe.value) && maybe.value.length > 0 && typeof maybe.value[0] === 'object') {
    return maybe.value[0] as Record<string, unknown>;
  }
  return maybe;
};

// OPTIONS - Handle CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: corsHeaders,
  });
}

// POST /api/sap/mm/stock-transfer - Stock Transfer Between Locations (MM-010)
export async function POST(request: NextRequest) {
  try {
    const rawBody = await request.json();
    const body = unwrapODataPayload(rawBody);
    const createdBy = request.headers.get('X-SAP-User') || 'OXMAINT_SYNC';

    const MATNRRaw = body.MATNR ?? body.material_number ?? body.sap_material_number;
    const MATNR = typeof MATNRRaw === 'string' ? MATNRRaw : undefined;
    const WERKS = (body.WERKS ?? body.plant ?? body.sap_plant) as string | undefined;
    const LGORT = (body.LGORT ?? body.storage_location ?? body.from_storage_location) as string | undefined;
    const UMWRK = (body.UMWRK ?? body.to_plant) as string | undefined;
    const UMLGO = (body.UMLGO ?? body.to_storage_location ?? body.destination_storage_location) as string | undefined;
    const MENGE = (body.MENGE ?? body.quantity) as number | undefined;
    const MEINS = (body.MEINS ?? body.unit) as string | undefined;
    const BWART = (body.BWART ?? '311') as string;
    const CHARG = body.CHARG as string | undefined;
    const SGTXT = body.SGTXT as string | undefined;
    const XBLNR = body.XBLNR as string | undefined;
    const ZZOXMAINT_INV_REF = (body.ZZOXMAINT_INV_REF ?? body.oxmaint_inventory_ref) as string | undefined;

    const errors: string[] = [];
    if (!MATNR) errors.push('MATNR (Material Number) is required');
    if (!WERKS) errors.push('WERKS (Plant) is required');
    if (!LGORT) errors.push('LGORT (Source Storage Location) is required');
    if (!UMLGO) errors.push('UMLGO (Destination Storage Location) is required');
    if (MENGE === undefined || MENGE === null) errors.push('MENGE (Quantity) is required');
    if (!MEINS) errors.push('MEINS (Unit of Measure) is required');

    if (BWART && !SAP_MOVEMENT_TYPES[BWART]) {
      errors.push(`Invalid Movement Type: ${BWART}. Valid types: ${Object.keys(SAP_MOVEMENT_TYPES).join(', ')}`);
    }
    if (WERKS && !SAP_PLANTS[WERKS]) {
      errors.push(`Invalid Plant: ${WERKS}. Valid plants: ${Object.keys(SAP_PLANTS).join(', ')}`);
    }
    if (UMWRK && !SAP_PLANTS[UMWRK]) {
      errors.push(`Invalid Destination Plant: ${UMWRK}. Valid plants: ${Object.keys(SAP_PLANTS).join(', ')}`);
    }
    if (LGORT && !SAP_STORAGE_LOCATIONS[LGORT]) {
      errors.push(`Invalid Source Storage Location: ${LGORT}. Valid locations: ${Object.keys(SAP_STORAGE_LOCATIONS).join(', ')}`);
    }
    if (UMLGO && !SAP_STORAGE_LOCATIONS[UMLGO]) {
      errors.push(`Invalid Destination Storage Location: ${UMLGO}. Valid locations: ${Object.keys(SAP_STORAGE_LOCATIONS).join(', ')}`);
    }
    if (MEINS && !SAP_UNITS[MEINS]) {
      errors.push(`Invalid Unit of Measure: ${MEINS}. Valid units: ${Object.keys(SAP_UNITS).join(', ')}`);
    }
    if (MENGE !== undefined && MENGE <= 0) {
      errors.push('MENGE must be greater than 0');
    }

    if (errors.length > 0) {
      const response: SAPResponse = {
        success: false,
        message: 'Validation failed',
        error: {
          code: 'MM/010',
          message: {
            lang: 'en',
            value: errors.join('; '),
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    if (!MATNR || !WERKS || !LGORT || !UMLGO || !MEINS || MENGE === undefined || MENGE === null) {
      const response: SAPResponse = {
        success: false,
        message: 'Required fields are missing',
        error: {
          code: 'MM/010',
          message: {
            lang: 'en',
            value: 'Required fields are missing',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    const existing = MaterialStore.getByNumber(MATNR);
    if (!existing) {
      const response: SAPResponse = {
        success: false,
        message: `Material ${MATNR} not found`,
        error: {
          code: 'MM/011',
          message: {
            lang: 'en',
            value: `Material ${MATNR} does not exist`,
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 404, headers: corsHeaders });
    }

    const movement = GoodsReceiptStore.create(
      {
        BWART,
        MATNR,
        WERKS,
        LGORT,
        UMWRK,
        UMLGO,
        MENGE: MENGE as number,
        MEINS: MEINS as string,
        CHARG,
        SGTXT: SGTXT || `Stock transfer to ${UMLGO}`,
        XBLNR,
        ZZOXMAINT_INV_REF,
      },
      createdBy
    );

    const destPlant = UMWRK || WERKS;
    const updatedMaterial = MaterialStore.update(MATNR, { WERKS: destPlant, LGORT: UMLGO }, createdBy);

    const response = {
      d: {
        results: {
          ...movement,
          destination: {
            WERKS: destPlant,
            LGORT: UMLGO,
          },
        },
        __metadata: {
          uri: `/sap/opu/odata/sap/API_GOODSMVT_SRV/A_GoodsMovement('${movement.MBLNR}/${movement.MJAHR}')`,
          type: 'API_GOODSMVT_SRV.A_GoodsMovementType',
        },
      },
      success: true,
      message: `Stock transfer posted for material ${movement.MATNR} from ${movement.LGORT} to ${UMLGO}`,
      data: {
        movement,
        material: updatedMaterial,
      },
      MBLNR: movement.MBLNR,
      MJAHR: movement.MJAHR,
      ZZSAP_DOC_NO: movement.ZZSAP_DOC_NO,
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { status: 201, headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM Stock Transfer API] POST Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Failed to post stock transfer',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}
