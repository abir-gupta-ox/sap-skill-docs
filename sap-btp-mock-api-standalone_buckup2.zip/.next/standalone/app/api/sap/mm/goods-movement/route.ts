// SAP Goods Movement API (MIGO - Movement Types for Receipt/Issue)
// Simulates posting goods movements for inventory management
// OXmaint -> SAP Integration: Inventory receipts and issues from Work Orders

import { NextRequest, NextResponse } from 'next/server';
import {
  GoodsReceiptStore,
  GoodsReceiptCreateRequest,
  SAPGoodsReceipt,
  SAP_MOVEMENT_TYPES,
  MaterialStore,
  SAP_PLANTS,
  SAP_STORAGE_LOCATIONS,
  SAP_UNITS,
} from '@/lib/materialStore';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-SAP-Client, X-Organization-Id, X-CSRF-Token, X-SAP-User',
};

interface SAPODataResponse {
  d?: {
    results?: SAPGoodsReceipt | SAPGoodsReceipt[];
    __count?: number;
    __metadata?: {
      uri: string;
      type: string;
    };
  };
  success: boolean;
  message: string;
  data?: {
    results: SAPGoodsReceipt[];
    __count: number;
  } | SAPGoodsReceipt;
  MBLNR?: string;
  MJAHR?: string;
  ZZSAP_DOC_NO?: string;
  error?: {
    code: string;
    message: {
      lang: string;
      value: string;
    };
  };
  timestamp: string;
}

const unwrapODataPayload = (payload: unknown): Record<string, unknown> | Record<string, unknown>[] => {
  if (!payload || typeof payload !== 'object') return {};
  if (Array.isArray(payload)) return payload as Record<string, unknown>[];
  const maybe = payload as Record<string, unknown>;
  if (maybe.d && typeof maybe.d === 'object') {
    const d = maybe.d as Record<string, unknown>;
    if (d.results && (typeof d.results === 'object' || Array.isArray(d.results))) {
      return d.results as Record<string, unknown> | Record<string, unknown>[];
    }
    return d;
  }
  if (Array.isArray(maybe.value) && maybe.value.length > 0 && typeof maybe.value[0] === 'object') {
    return maybe.value as Record<string, unknown>[];
  }
  return maybe;
};

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: corsHeaders,
  });
}

// GET - Retrieve Goods Receipts
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const timestamp = new Date().toISOString();

  try {
    // Single document lookup
    const MBLNR = searchParams.get('MBLNR');
    const MJAHR = searchParams.get('MJAHR') || new Date().getFullYear().toString();
    const ZEILE = searchParams.get('ZEILE');

    if (MBLNR && ZEILE) {
      // Get specific item
      const gr = GoodsReceiptStore.getByDocumentAndItem(MBLNR, MJAHR, ZEILE);
      if (!gr) {
        const response: SAPODataResponse = {
          success: false,
          message: `Goods Receipt ${MBLNR}/${MJAHR}/${ZEILE} not found`,
          error: {
            code: 'GR_NOT_FOUND',
            message: { lang: 'en', value: `Material document ${MBLNR} item ${ZEILE} not found` }
          },
          timestamp
        };
        return NextResponse.json(response, { status: 404 });
      }

      const response: SAPODataResponse = {
        d: {
          results: gr,
          __metadata: {
            uri: `/api/sap/mm/goods-movement('${MBLNR}/${MJAHR}/${ZEILE}')`,
            type: 'SAP.GoodsReceipt'
          }
        },
        success: true,
        message: 'Goods Receipt retrieved successfully',
        data: gr,
        timestamp
      };
      return NextResponse.json(response);
    }

    if (MBLNR) {
      // Get all items for a document
      const items = GoodsReceiptStore.getByDocument(MBLNR, MJAHR);
      if (items.length === 0) {
        const response: SAPODataResponse = {
          success: false,
          message: `Material Document ${MBLNR}/${MJAHR} not found`,
          error: {
            code: 'GR_NOT_FOUND',
            message: { lang: 'en', value: `Material document ${MBLNR} not found for year ${MJAHR}` }
          },
          timestamp
        };
        return NextResponse.json(response, { status: 404 });
      }

      const response: SAPODataResponse = {
        d: {
          results: items,
          __count: items.length
        },
        success: true,
        message: `Retrieved ${items.length} items for document ${MBLNR}`,
        data: { results: items, __count: items.length },
        timestamp
      };
      return NextResponse.json(response);
    }

    // Filter parameters
    const filters = {
      WERKS: searchParams.get('WERKS') || undefined,
      LGORT: searchParams.get('LGORT') || undefined,
      BWART: searchParams.get('BWART') || undefined,
      MATNR: searchParams.get('MATNR') || undefined,
      AUFNR: searchParams.get('AUFNR') || undefined,
      EBELN: searchParams.get('EBELN') || undefined,
    };

    // Special lookups
    const ZZOXMAINT_WO_REF = searchParams.get('ZZOXMAINT_WO_REF');
    if (ZZOXMAINT_WO_REF) {
      const results = GoodsReceiptStore.getByOxmaintRef(ZZOXMAINT_WO_REF);
      const response: SAPODataResponse = {
        d: { results, __count: results.length },
        success: true,
        message: `Retrieved ${results.length} goods receipts for OXmaint reference ${ZZOXMAINT_WO_REF}`,
        data: { results, __count: results.length },
        timestamp
      };
      return NextResponse.json(response);
    }

    const results = GoodsReceiptStore.getAll(filters);

    const response: SAPODataResponse = {
      d: { results, __count: results.length },
      success: true,
      message: `Retrieved ${results.length} goods receipts`,
      data: { results, __count: results.length },
      timestamp
    };
    return NextResponse.json(response);
  } catch (error) {
    const response: SAPODataResponse = {
      success: false,
      message: 'Failed to retrieve goods receipts',
      error: {
        code: 'GR_READ_ERROR',
        message: { lang: 'en', value: error instanceof Error ? error.message : 'Unknown error' }
      },
      timestamp
    };
    return NextResponse.json(response, { status: 500 });
  }
}

// POST - Create Goods Receipt (MIGO)
export async function POST(request: NextRequest) {
  const timestamp = new Date().toISOString();

  try {
    const rawBody = await request.json();
    const payload = unwrapODataPayload(rawBody);
    const createdBy = request.headers.get('X-SAP-User') || 'OXMAINT_SYNC';

    // Handle single or multiple items
    const items: GoodsReceiptCreateRequest[] = Array.isArray(payload)
      ? (payload as unknown as GoodsReceiptCreateRequest[])
      : ([payload] as unknown as GoodsReceiptCreateRequest[]);

    // Validate required fields for each item
    const errors: string[] = [];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const prefix = items.length > 1 ? `Item ${i + 1}: ` : '';

      if (!item.BWART) errors.push(`${prefix}BWART (Movement Type) is required`);
      if (!item.MATNR) errors.push(`${prefix}MATNR (Material Number) is required`);
      if (!item.WERKS) errors.push(`${prefix}WERKS (Plant) is required`);
      if (!item.LGORT) errors.push(`${prefix}LGORT (Storage Location) is required`);
      if (item.MENGE === undefined || item.MENGE === null) errors.push(`${prefix}MENGE (Quantity) is required`);
      if (!item.MEINS) errors.push(`${prefix}MEINS (Unit of Measure) is required`);

      // Validate movement type
      if (item.BWART && !SAP_MOVEMENT_TYPES[item.BWART]) {
        errors.push(`${prefix}Invalid Movement Type: ${item.BWART}. Valid types: ${Object.keys(SAP_MOVEMENT_TYPES).join(', ')}`);
      }

      // Validate plant
      if (item.WERKS && !SAP_PLANTS[item.WERKS]) {
        errors.push(`${prefix}Invalid Plant: ${item.WERKS}. Valid plants: ${Object.keys(SAP_PLANTS).join(', ')}`);
      }

      // Validate storage location
      if (item.LGORT && !SAP_STORAGE_LOCATIONS[item.LGORT]) {
        errors.push(`${prefix}Invalid Storage Location: ${item.LGORT}. Valid locations: ${Object.keys(SAP_STORAGE_LOCATIONS).join(', ')}`);
      }

      // Validate unit of measure
      if (item.MEINS && !SAP_UNITS[item.MEINS]) {
        errors.push(`${prefix}Invalid Unit of Measure: ${item.MEINS}. Valid units: ${Object.keys(SAP_UNITS).join(', ')}`);
      }

      // Validate quantity is positive
      if (item.MENGE !== undefined && item.MENGE <= 0) {
        errors.push(`${prefix}MENGE must be greater than 0`);
      }

      if ((item.BWART === '301' || item.BWART === '311') && !item.UMLGO) {
        errors.push(`${prefix}UMLGO (Destination Storage Location) is required for transfer`);
      }
      if (item.BWART === '301' && !item.UMWRK) {
        errors.push(`${prefix}UMWRK (Destination Plant) is required for plant transfer`);
      }
    }

    if (errors.length > 0) {
      const response: SAPODataResponse = {
        success: false,
        message: 'Validation failed',
        error: {
          code: 'GR_VALIDATION_ERROR',
          message: { lang: 'en', value: errors.join('; ') }
        },
        timestamp
      };
      return NextResponse.json(response, { status: 400 });
    }

    // Create goods receipt(s)
    let results: SAPGoodsReceipt[];
    if (items.length > 1) {
      results = GoodsReceiptStore.createMultiple(items, createdBy);
    } else {
      const created = GoodsReceiptStore.create(items[0], createdBy);
      results = [created];
    }

    // Apply stock transfer updates (MM-010) when destination is provided
    results.forEach((result, index) => {
      const source = items[index];
      if (source?.UMLGO || source?.UMWRK || result.BWART === '301' || result.BWART === '311') {
        const destPlant = source?.UMWRK || result.WERKS;
        const destSloc = source?.UMLGO;
        if (destSloc) {
          MaterialStore.update(result.MATNR, { WERKS: destPlant, LGORT: destSloc }, createdBy);
        }
      }
    });

    const firstResult = results[0];
    const response: SAPODataResponse = {
      d: {
        results: results.length === 1 ? firstResult : results,
        __metadata: {
          uri: `/api/sap/mm/goods-movement('${firstResult.MBLNR}/${firstResult.MJAHR}')`,
          type: 'SAP.GoodsReceipt'
        }
      },
      success: true,
      message: `Goods Receipt ${firstResult.MBLNR} posted successfully with ${results.length} item(s)`,
      data: results.length === 1 ? firstResult : { results, __count: results.length },
      MBLNR: firstResult.MBLNR,
      MJAHR: firstResult.MJAHR,
      ZZSAP_DOC_NO: firstResult.ZZSAP_DOC_NO,
      timestamp
    };

    return NextResponse.json(response, { status: 201 });
  } catch (error) {
    const response: SAPODataResponse = {
      success: false,
      message: 'Failed to create goods receipt',
      error: {
        code: 'GR_CREATE_ERROR',
        message: { lang: 'en', value: error instanceof Error ? error.message : 'Unknown error' }
      },
      timestamp
    };
    return NextResponse.json(response, { status: 500 });
  }
}
