import { NextRequest, NextResponse } from 'next/server';
import {
  MaterialStore,
  SAPResponse,
  SAP_PLANTS,
  SAP_STORAGE_LOCATIONS,
} from '@/lib/materialStore';

// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, PUT, PATCH, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-SAP-Client, X-Organization-Id, X-CSRF-Token',
};

const unwrapODataPayload = (payload: unknown): Record<string, unknown> => {
  if (!payload || typeof payload !== 'object') return {};
  const maybe = payload as Record<string, unknown>;
  if (maybe.d && typeof maybe.d === 'object') {
    const d = maybe.d as Record<string, unknown>;
    if (d.results && typeof d.results === 'object') {
      return d.results as Record<string, unknown>;
    }
    return d;
  }
  if (Array.isArray(maybe.value) && maybe.value.length > 0 && typeof maybe.value[0] === 'object') {
    return maybe.value[0] as Record<string, unknown>;
  }
  return maybe;
};

// Stock & MRP view fields (MARC/MARD table equivalent)
interface MaterialStockView {
  MATNR: string;           // Material Number
  WERKS: string;           // Plant
  LGORT: string;           // Storage Location
  DISMM?: string;          // MRP Type
  DISLS?: string;          // Lot Size
  DISPO?: string;          // MRP Controller
  EISBE?: number;          // Safety Stock
  MINBE?: number;          // Reorder Point
  MABST?: number;          // Maximum Stock Level
  PLIFZ?: number;          // Planned Delivery Time (days)
  WEBAZ?: number;          // Goods Receipt Processing Time
  STPRS?: number;          // Standard Price
  VPRSV?: string;          // Price Control (S=Standard, V=Moving Avg)
  BKLAS?: string;          // Valuation Class
}

// OPTIONS - Handle CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: corsHeaders,
  });
}

// GET /api/sap/mm/material-stock - Get plant/MRP data for material(s)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const MATNR = searchParams.get('MATNR') || searchParams.get('material_number');
    const WERKS = searchParams.get('WERKS') || searchParams.get('plant');

    if (MATNR) {
      // Get specific material
      const material = MaterialStore.getByNumber(MATNR);
      if (!material) {
        const response: SAPResponse = {
          success: false,
          message: `Material ${MATNR} not found`,
          error: {
            code: 'MARC/001',
            message: {
              lang: 'en',
              value: `Material ${MATNR} does not exist`,
            },
          },
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { status: 404, headers: corsHeaders });
      }

      // Return only plant/MRP relevant fields
      const plantView: MaterialStockView = {
        MATNR: material.MATNR,
        WERKS: material.WERKS,
        LGORT: material.LGORT,
        DISMM: material.DISMM,
        DISLS: material.DISLS,
        DISPO: material.DISPO,
        EISBE: material.EISBE,
        MINBE: material.MINBE,
        PLIFZ: material.PLIFZ,
        STPRS: material.STPRS,
        VPRSV: material.VPRSV,
        BKLAS: material.BKLAS,
      };

      const response = {
        d: {
          results: plantView,
          __metadata: {
            uri: `/sap/opu/odata/sap/API_PRODUCT_SRV/A_ProductPlant(Product='${material.MATNR}',Plant='${material.WERKS}')`,
            type: 'API_PRODUCT_SRV.A_ProductPlantType',
          },
        },
        success: true,
        message: 'Material stock data retrieved successfully',
        data: plantView,
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { headers: corsHeaders });
    }

    // Get all materials, optionally filtered by plant
    let materials = MaterialStore.getAll({ WERKS: WERKS || undefined });

    // Map to plant view
    const plantViews: MaterialStockView[] = materials.map(mat => ({
      MATNR: mat.MATNR,
      WERKS: mat.WERKS,
      LGORT: mat.LGORT,
      DISMM: mat.DISMM,
      DISLS: mat.DISLS,
      DISPO: mat.DISPO,
      EISBE: mat.EISBE,
      MINBE: mat.MINBE,
      PLIFZ: mat.PLIFZ,
      STPRS: mat.STPRS,
      VPRSV: mat.VPRSV,
      BKLAS: mat.BKLAS,
    }));

    const response = {
      d: {
        results: plantViews,
        __count: plantViews.length,
        __metadata: {
          uri: '/sap/opu/odata/sap/API_PRODUCT_SRV/A_ProductPlant',
          type: 'Collection(API_PRODUCT_SRV.A_ProductPlantType)',
        },
      },
      success: true,
      message: `Retrieved ${plantViews.length} material stock records`,
      data: {
        results: plantViews,
        __count: plantViews.length,
        __metadata: {
          SAP_PLANTS,
          SAP_STORAGE_LOCATIONS,
          MRP_TYPES: {
            'PD': 'MRP',
            'VB': 'Manual Reorder Point',
            'ND': 'No Planning',
            'VV': 'Forecast-based Planning',
          },
          LOT_SIZES: {
            'EX': 'Lot-for-Lot',
            'FX': 'Fixed Lot Size',
            'WB': 'Weekly Lot Size',
            'MB': 'Monthly Lot Size',
          },
        },
      },
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM Material-Stock API] GET Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Internal server error',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}

// PUT/PATCH /api/sap/mm/material-stock - Update MRP & Storage Location settings
export async function PUT(request: NextRequest) {
  try {
    const rawBody = await request.json();
    const body = unwrapODataPayload(rawBody);
    const { MATNR: MATNRRaw, ...updates } = body as Record<string, unknown>;
    const MATNR = typeof MATNRRaw === 'string' ? MATNRRaw : '';

    if (!MATNR) {
      const response: SAPResponse = {
        success: false,
        message: 'Material number (MATNR) is required',
        error: {
          code: 'MARC/002',
          message: {
            lang: 'en',
            value: 'Please provide MATNR in the request body',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    // Check if material exists
    const existing = MaterialStore.getByNumber(MATNR);
    if (!existing) {
      const response: SAPResponse = {
        success: false,
        message: `Material ${MATNR} not found`,
        error: {
          code: 'MARC/003',
          message: {
            lang: 'en',
            value: 'Cannot update plant data for non-existent material',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 404, headers: corsHeaders });
    }

    const WERKS = typeof updates.WERKS === 'string' ? updates.WERKS : undefined;
    const LGORT = typeof updates.LGORT === 'string' ? updates.LGORT : undefined;

    // Validate plant if provided
    if (WERKS && !Object.keys(SAP_PLANTS).includes(WERKS)) {
      const response: SAPResponse = {
        success: false,
        message: 'Invalid plant code (WERKS)',
        error: {
          code: 'MARC/004',
          message: {
            lang: 'en',
            value: `Valid plant codes: ${Object.keys(SAP_PLANTS).join(', ')}`,
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    // Validate storage location if provided
    if (LGORT && !Object.keys(SAP_STORAGE_LOCATIONS).includes(LGORT)) {
      const response: SAPResponse = {
        success: false,
        message: 'Invalid storage location (LGORT)',
        error: {
          code: 'MARC/005',
          message: {
            lang: 'en',
            value: `Valid storage locations: ${Object.keys(SAP_STORAGE_LOCATIONS).join(', ')}`,
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    // Filter to only allow plant/MRP fields
    const allowedFields = ['WERKS', 'LGORT', 'DISMM', 'DISLS', 'DISPO', 'EISBE', 'MINBE', 'MABST', 'PLIFZ', 'WEBAZ', 'STPRS', 'VPRSV', 'BKLAS'];
    const filteredUpdates: Record<string, unknown> = {};
    for (const key of allowedFields) {
      if (updates[key] !== undefined) {
        filteredUpdates[key] = updates[key];
      }
    }

    if (Object.keys(filteredUpdates).length === 0) {
      const response: SAPResponse = {
        success: false,
        message: 'No valid fields to update',
        error: {
          code: 'MARC/006',
          message: {
            lang: 'en',
            value: `Allowed fields: ${allowedFields.join(', ')}`,
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    // Get user from headers
    const modifiedBy = request.headers.get('X-SAP-User') || 'OXMAINT_SYNC';

    // Update material
    const updatedMaterial = MaterialStore.update(MATNR, filteredUpdates, modifiedBy);

    console.log(`[SAP MM Material-Stock API] Updated MRP/Plant data for: ${MATNR}`);

    // Return only plant/MRP fields
    const plantView: MaterialStockView = {
      MATNR: updatedMaterial!.MATNR,
      WERKS: updatedMaterial!.WERKS,
      LGORT: updatedMaterial!.LGORT,
      DISMM: updatedMaterial!.DISMM,
      DISLS: updatedMaterial!.DISLS,
      DISPO: updatedMaterial!.DISPO,
      EISBE: updatedMaterial!.EISBE,
      MINBE: updatedMaterial!.MINBE,
      PLIFZ: updatedMaterial!.PLIFZ,
      STPRS: updatedMaterial!.STPRS,
      VPRSV: updatedMaterial!.VPRSV,
      BKLAS: updatedMaterial!.BKLAS,
    };

    const response = {
      d: {
        results: plantView,
        __metadata: {
          uri: `/sap/opu/odata/sap/API_PRODUCT_SRV/A_ProductPlant(Product='${updatedMaterial!.MATNR}',Plant='${updatedMaterial!.WERKS}')`,
          type: 'API_PRODUCT_SRV.A_ProductPlantType',
        },
      },
      success: true,
      message: `Material ${MATNR} plant/MRP data updated successfully`,
      data: plantView,
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM Material-Stock API] PUT Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Failed to update material plant data',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}

// PATCH is alias for PUT
export { PUT as PATCH };
