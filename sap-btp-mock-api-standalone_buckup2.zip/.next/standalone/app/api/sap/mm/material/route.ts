import { NextRequest, NextResponse } from 'next/server';
import {
  MaterialStore,
  MaterialCreateRequest,
  SAPResponse,
  SAPMaterial,
  SAP_MATERIAL_TYPES,
  SAP_MATERIAL_GROUPS,
  SAP_PLANTS,
  SAP_STORAGE_LOCATIONS,
  SAP_UNITS,
} from '@/lib/materialStore';

// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-SAP-Client, X-Organization-Id, X-CSRF-Token',
};

type NormalizeMode = 'create' | 'update';

const MATERIAL_TYPE_LABELS: Record<string, string> = {
  'spare part': 'ERSA',
  'spare parts': 'ERSA',
  'raw material': 'ROH',
  'finished product': 'FERT',
  'semi-finished product': 'HALB',
  'trading goods': 'HAWA',
  'non-stock material': 'NLAG',
  'packaging material': 'VERP',
  'services': 'DIEN',
  'service': 'DIEN',
};

const DEFAULT_BTP_FIELDS = {
  MTART: 'ERSA',
  MATKL: 'BHS',
  MEINS: 'EA',
  LGORT: 'WH01',
};

const unwrapODataPayload = (payload: unknown): Record<string, unknown> => {
  if (!payload || typeof payload !== 'object') return {};
  const maybe = payload as Record<string, unknown>;
  if (maybe.d && typeof maybe.d === 'object') {
    const d = maybe.d as Record<string, unknown>;
    if (d.results && typeof d.results === 'object') {
      return d.results as Record<string, unknown>;
    }
    return d;
  }
  if (Array.isArray(maybe.value) && maybe.value.length > 0 && typeof maybe.value[0] === 'object') {
    return maybe.value[0] as Record<string, unknown>;
  }
  return maybe;
};

const stripUndefined = <T extends Record<string, unknown>>(value: T): Partial<T> =>
  Object.fromEntries(Object.entries(value).filter(([, entry]) => entry !== undefined)) as Partial<T>;

const mapMaterialType = (input?: unknown): string | undefined => {
  if (!input) return undefined;
  const value = String(input).trim();
  if (!value) return undefined;
  if (SAP_MATERIAL_TYPES[value]) return value;
  const key = value.toLowerCase();
  return MATERIAL_TYPE_LABELS[key];
};

const mapMaterialGroup = (input?: unknown): string | undefined => {
  if (!input) return undefined;
  const value = String(input).trim();
  if (!value) return undefined;
  if (SAP_MATERIAL_GROUPS[value]) return value;
  const match = Object.entries(SAP_MATERIAL_GROUPS).find(([, label]) => label.toLowerCase() === value.toLowerCase());
  return match?.[0];
};

const normalizeMaterialPayload = (payload: unknown, mode: NormalizeMode): { request: MaterialCreateRequest; isBtp: boolean } => {
  const raw = unwrapODataPayload(payload);
  const isBtp = 'material_id' in raw || 'material_name' in raw || 'sap_material_number' in raw || 'sap_plant' in raw;

  const MTART = mapMaterialType(raw.MTART ?? raw.material_type ?? raw.mtart);
  const MATKL = mapMaterialGroup(raw.MATKL ?? raw.category_id ?? raw.material_group ?? raw.matkl);
  const MAKTX = (raw.MAKTX ?? raw.material_name ?? raw.description ?? raw.maktx ?? raw.material_description) as string | undefined;
  const MEINS = (raw.MEINS ?? raw.unit ?? raw.meins ?? raw.uom) as string | undefined;
  const WERKS = (raw.WERKS ?? raw.sap_plant ?? raw.werks ?? raw.plant) as string | undefined;
  const LGORT = (raw.LGORT ?? raw.sap_storage_location ?? raw.storage_location ?? raw.lgort ?? raw.sloc) as string | undefined;
  const MATNR = (raw.MATNR ?? raw.sap_material_number ?? raw.material_number ?? raw.matnr) as string | undefined;

  const request: Partial<MaterialCreateRequest> = {
    MATNR,
    MTART,
    MATKL,
    MAKTX,
    MEINS,
    WERKS,
    LGORT,
    PLIFZ: raw.PLIFZ as number | undefined,
    BRGEW: raw.BRGEW as number | undefined,
    NTGEW: raw.NTGEW as number | undefined,
    GEWEI: raw.GEWEI as string | undefined,
    STPRS: raw.STPRS as number | undefined,
    ZZOXMAINT_REF: (raw.ZZOXMAINT_REF ?? raw.oxmaint_ref ?? raw.material_id) as string | undefined,
    DISMM: raw.DISMM as string | undefined,
    DISLS: raw.DISLS as string | undefined,
    EISBE: raw.EISBE as number | undefined,
    MINBE: raw.MINBE as number | undefined,
    BKLAS: raw.BKLAS as string | undefined,
    VPRSV: raw.VPRSV as string | undefined,
    WAERS: raw.WAERS as string | undefined,
    EKGRP: raw.EKGRP as string | undefined,
    DISPO: raw.DISPO as string | undefined,
  };

  if (isBtp && mode === 'create') {
    request.MTART = request.MTART || DEFAULT_BTP_FIELDS.MTART;
    request.MATKL = request.MATKL || DEFAULT_BTP_FIELDS.MATKL;
    request.MEINS = request.MEINS || DEFAULT_BTP_FIELDS.MEINS;
    request.LGORT = request.LGORT || DEFAULT_BTP_FIELDS.LGORT;
  }

  return { request: request as MaterialCreateRequest, isBtp };
};

// OPTIONS - Handle CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: corsHeaders,
  });
}

// GET /api/sap/mm/material - Get all materials or search
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const WERKS = searchParams.get('WERKS') || searchParams.get('plant') || undefined;
    const MTART = searchParams.get('MTART') || searchParams.get('material_type') || undefined;
    const MATKL = searchParams.get('MATKL') || searchParams.get('material_group') || undefined;
    const search = searchParams.get('search') || searchParams.get('$search') || undefined;
    const MATNR = searchParams.get('MATNR') || searchParams.get('material_number') || undefined;

    // If specific material number requested
    if (MATNR) {
      const material = MaterialStore.getByNumber(MATNR);
      if (!material) {
        const response: SAPResponse = {
          success: false,
          message: `Material ${MATNR} not found`,
          error: {
            code: 'SY/530',
            message: {
              lang: 'en',
              value: `Material ${MATNR} does not exist`,
            },
          },
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { status: 404, headers: corsHeaders });
      }

      const response: SAPResponse<SAPMaterial> = {
        d: {
          results: material,
          __metadata: {
            uri: `/sap/opu/odata/sap/API_MATERIAL_STOCK_SRV/A_Material('${material.MATNR}')`,
            type: 'API_MATERIAL_STOCK_SRV.A_MaterialType',
          },
        },
        success: true,
        message: 'Material retrieved successfully',
        data: material,
        ZZSAP_DOC_NO: material.ZZSAP_DOC_NO,
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { headers: corsHeaders });
    }

    // Search or filter materials
    let materials: SAPMaterial[];
    if (search) {
      materials = MaterialStore.search(search);
    } else {
      materials = MaterialStore.getAll({
        WERKS,
        MTART,
        MATKL,
      });
    }

    const response = {
      d: {
        results: materials,
        __count: materials.length,
        __metadata: {
          uri: '/sap/opu/odata/sap/API_MATERIAL_STOCK_SRV/A_Material',
          type: 'Collection(API_MATERIAL_STOCK_SRV.A_MaterialType)',
        },
      },
      success: true,
      message: `Retrieved ${materials.length} materials`,
      data: {
        results: materials,
        __count: materials.length,
        __metadata: {
          SAP_MATERIAL_TYPES,
          SAP_MATERIAL_GROUPS,
          SAP_PLANTS,
          SAP_STORAGE_LOCATIONS,
          SAP_UNITS,
        },
      },
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM Material API] GET Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Internal server error',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}

// POST /api/sap/mm/material - Create new material (MM-001)
export async function POST(request: NextRequest) {
  try {
    const rawBody = await request.json();
    const { request: body } = normalizeMaterialPayload(rawBody, 'create');

    // Validate required fields (SAP field names)
    const requiredFields: (keyof MaterialCreateRequest)[] = ['MTART', 'MATKL', 'MAKTX', 'MEINS', 'WERKS', 'LGORT'];
    const missingFields = requiredFields.filter((field) => !body[field]);

    if (missingFields.length > 0) {
      const response: SAPResponse = {
        success: false,
        message: 'Validation failed: Missing required fields',
        error: {
          code: 'MM/001',
          message: {
            lang: 'en',
            value: `Missing required fields: ${missingFields.join(', ')}`,
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    // Validate material type
    if (!Object.keys(SAP_MATERIAL_TYPES).includes(body.MTART)) {
      const response: SAPResponse = {
        success: false,
        message: 'Validation failed: Invalid material type (MTART)',
        error: {
          code: 'MM/002',
          message: {
            lang: 'en',
            value: `Valid material types (MTART): ${Object.keys(SAP_MATERIAL_TYPES).join(', ')}`,
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    // Validate plant
    if (!Object.keys(SAP_PLANTS).includes(body.WERKS)) {
      const response: SAPResponse = {
        success: false,
        message: 'Validation failed: Invalid plant code (WERKS)',
        error: {
          code: 'MM/003',
          message: {
            lang: 'en',
            value: `Valid plant codes (WERKS): ${Object.keys(SAP_PLANTS).join(', ')}`,
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    // Check if material number already exists
    if (body.MATNR && MaterialStore.getByNumber(body.MATNR)) {
      const response: SAPResponse = {
        success: false,
        message: 'Material number already exists',
        error: {
          code: 'MM/004',
          message: {
            lang: 'en',
            value: `Material ${body.MATNR} already exists in SAP`,
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 409, headers: corsHeaders });
    }

    // Get user from headers (in real SAP, this would be from authentication)
    const createdBy = request.headers.get('X-SAP-User') || 'OXMAINT_SYNC';

    // Create material
    const newMaterial = MaterialStore.create(body, createdBy);

    console.log(`[SAP MM Material API] Created material: ${newMaterial.MATNR}`);

    const response: SAPResponse<SAPMaterial> = {
      d: {
        results: newMaterial,
        __metadata: {
          uri: `/sap/opu/odata/sap/API_MATERIAL_STOCK_SRV/A_Material('${newMaterial.MATNR}')`,
          type: 'API_MATERIAL_STOCK_SRV.A_MaterialType',
        },
      },
      success: true,
      message: `Material ${newMaterial.MATNR} created successfully in SAP`,
      data: newMaterial,
      ZZSAP_DOC_NO: newMaterial.ZZSAP_DOC_NO,
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { status: 201, headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM Material API] POST Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Failed to create material in SAP',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}

// PUT /api/sap/mm/material - Update material (MM-002)
export async function PUT(request: NextRequest) {
  try {
    const rawBody = await request.json();
    const { request: normalized } = normalizeMaterialPayload(rawBody, 'update');
    const { MATNR, ...updates } = normalized;
    const cleanedUpdates = stripUndefined(updates);

    if (!MATNR) {
      const response: SAPResponse = {
        success: false,
        message: 'Material number (MATNR) is required for update',
        error: {
          code: 'MM/005',
          message: {
            lang: 'en',
            value: 'Please provide MATNR in the request body',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    // Check if material exists
    const existing = MaterialStore.getByNumber(MATNR);
    if (!existing) {
      const response: SAPResponse = {
        success: false,
        message: `Material ${MATNR} not found`,
        error: {
          code: 'MM/006',
          message: {
            lang: 'en',
            value: 'Cannot update non-existent material',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 404, headers: corsHeaders });
    }

    // Get user from headers
    const modifiedBy = request.headers.get('X-SAP-User') || 'OXMAINT_SYNC';

    // Update material
    const updatedMaterial = MaterialStore.update(MATNR, cleanedUpdates, modifiedBy);

    console.log(`[SAP MM Material API] Updated material: ${MATNR}`);

    const response: SAPResponse<SAPMaterial> = {
      d: {
        results: updatedMaterial!,
        __metadata: {
          uri: `/sap/opu/odata/sap/API_MATERIAL_STOCK_SRV/A_Material('${updatedMaterial!.MATNR}')`,
          type: 'API_MATERIAL_STOCK_SRV.A_MaterialType',
        },
      },
      success: true,
      message: `Material ${MATNR} updated successfully in SAP`,
      data: updatedMaterial!,
      ZZSAP_DOC_NO: updatedMaterial!.ZZSAP_DOC_NO,
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM Material API] PUT Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Failed to update material in SAP',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}

// DELETE /api/sap/mm/material - Delete materials
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const MATNR = searchParams.get('MATNR') || searchParams.get('material_number');

    if (!MATNR) {
      const response: SAPResponse = {
        success: false,
        message: 'Material number (MATNR) is required',
        error: {
          code: 'MM/007',
          message: {
            lang: 'en',
            value: 'Please provide MATNR as query parameter',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    const deleted = MaterialStore.delete(MATNR);

    if (!deleted) {
      const response: SAPResponse = {
        success: false,
        message: `Material ${MATNR} not found`,
        error: {
          code: 'MM/008',
          message: {
            lang: 'en',
            value: 'Cannot delete non-existent material',
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 404, headers: corsHeaders });
    }

    console.log(`[SAP MM Material API] Deleted material: ${MATNR}`);

    const response: SAPResponse = {
      success: true,
      message: `Material ${MATNR} marked for deletion in SAP`,
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM Material API] DELETE Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Failed to delete material from SAP',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}
