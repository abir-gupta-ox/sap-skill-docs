import { NextRequest, NextResponse } from 'next/server';
import {
  PurchaseOrderStore,
  SAPResponse,
  PurchaseOrderCreateRequest,
  SAP_PO_DOC_TYPES,
  SAP_PO_STATUS,
} from '@/lib/materialStore';

// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-SAP-Client, X-Organization-Id, X-CSRF-Token, X-SAP-User',
};

const unwrapODataPayload = (payload: unknown): Record<string, unknown> => {
  if (!payload || typeof payload !== 'object') return {};
  const maybe = payload as Record<string, unknown>;
  if (maybe.d && typeof maybe.d === 'object') {
    const d = maybe.d as Record<string, unknown>;
    if (d.results && typeof d.results === 'object') {
      return d.results as Record<string, unknown>;
    }
    return d;
  }
  if (Array.isArray(maybe.value) && maybe.value.length > 0 && typeof maybe.value[0] === 'object') {
    return maybe.value[0] as Record<string, unknown>;
  }
  return maybe;
};

// OPTIONS - Handle CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: corsHeaders,
  });
}

// GET /api/sap/mm/purchase-order - Get all Purchase Orders (ME23N)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const WERKS = searchParams.get('WERKS') || searchParams.get('plant');
    const EKORG = searchParams.get('EKORG') || searchParams.get('purch_org');
    const EKGRP = searchParams.get('EKGRP') || searchParams.get('purch_group');
    const LIFNR = searchParams.get('LIFNR') || searchParams.get('vendor');
    const STATU = searchParams.get('STATU') || searchParams.get('status');

    // Get all with filters
    const filters: { WERKS?: string; EKORG?: string; EKGRP?: string; LIFNR?: string; STATU?: string } = {};
    if (WERKS) filters.WERKS = WERKS;
    if (EKORG) filters.EKORG = EKORG;
    if (EKGRP) filters.EKGRP = EKGRP;
    if (LIFNR) filters.LIFNR = LIFNR;
    if (STATU) filters.STATU = STATU;

    const pos = PurchaseOrderStore.getAll(filters);
    const response = {
      d: {
        results: pos,
        __count: pos.length,
        __metadata: {
          SAP_PO_DOC_TYPES,
          SAP_PO_STATUS,
        },
      },
      success: true,
      message: `Retrieved ${pos.length} purchase orders`,
      data: {
        results: pos,
        __count: pos.length,
      },
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM PO API] GET Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Internal server error',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}

// POST /api/sap/mm/purchase-order - Convert PR to PO (ME59N)
export async function POST(request: NextRequest) {
  try {
    const rawBody = await request.json();
    const body = unwrapODataPayload(rawBody);
    const createdBy = request.headers.get('X-SAP-User') || 'OXMAINT_SYNC';

    // Check if this is a PR to PO conversion request
    if (body.BANFN && body.LIFNR && !body.TXZ01) {
      // PR to PO Conversion (ME59N)
      const BANFN = typeof body.BANFN === 'string' ? body.BANFN : '';
      const BNFPO = typeof body.BNFPO === 'string' ? body.BNFPO : '00010';
      const LIFNR = typeof body.LIFNR === 'string' ? body.LIFNR : '';

      try {
        const result = PurchaseOrderStore.createFromPR(BANFN, BNFPO, LIFNR, body, createdBy);

        if (!result) {
          const response: SAPResponse = {
            success: false,
            message: `Purchase requisition ${BANFN}/${BNFPO} not found`,
            error: {
              code: 'ME/503',
              message: {
                lang: 'en',
                value: 'Cannot convert non-existent purchase requisition to purchase order',
              },
            },
            timestamp: new Date().toISOString(),
          };
          return NextResponse.json(response, { status: 404, headers: corsHeaders });
        }

        console.log(`[SAP MM PO API] Converted PR ${BANFN}/${BNFPO} to PO ${result.po.EBELN}/${result.po.EBELP}`);

        const response = {
          d: {
            results: result.po,
            __metadata: {
              uri: `/sap/opu/odata/sap/API_PURCHASEORDER_PROCESS_SRV/A_PurchaseOrder('${result.po.EBELN}')`,
              type: 'API_PURCHASEORDER_PROCESS_SRV.A_PurchaseOrderType',
            },
          },
          success: true,
          message: `Purchase requisition ${BANFN}/${BNFPO} successfully converted to purchase order ${result.po.EBELN}/${result.po.EBELP}`,
          data: {
            PO: result.po,
            PR: result.pr,
            EBELN: result.po.EBELN,
            EBELP: result.po.EBELP,
            BANFN: BANFN,
            BNFPO: BNFPO,
            LIFNR: LIFNR,
          },
          EBELN: result.po.EBELN,
          ZZSAP_DOC_NO: result.po.ZZSAP_DOC_NO,
          timestamp: new Date().toISOString(),
        };

        return NextResponse.json(response, { status: 201, headers: corsHeaders });
      } catch (conversionError) {
        const response: SAPResponse = {
          success: false,
          message: 'PR to PO conversion failed',
          error: {
            code: 'ME/504',
            message: {
              lang: 'en',
              value: conversionError instanceof Error ? conversionError.message : 'Conversion failed',
            },
          },
          timestamp: new Date().toISOString(),
        };
        return NextResponse.json(response, { status: 400, headers: corsHeaders });
      }
    }

    // Direct PO Creation (ME21N)
    // Validate required fields
    const requiredFields = ['TXZ01', 'MENGE', 'MEINS', 'WERKS', 'EKGRP', 'EKORG', 'NETPR'];
    const missingFields = requiredFields.filter((field) => !body[field]);

    if (missingFields.length > 0) {
      const response: SAPResponse = {
        success: false,
        message: 'Missing required fields',
        error: {
          code: 'ME/505',
          message: {
            lang: 'en',
            value: `Required fields missing: ${missingFields.join(', ')}`,
          },
        },
        timestamp: new Date().toISOString(),
      };
      return NextResponse.json(response, { status: 400, headers: corsHeaders });
    }

    const po = PurchaseOrderStore.create(body as unknown as PurchaseOrderCreateRequest, createdBy);
    console.log(`[SAP MM PO API] Created PO ${po.EBELN}/${po.EBELP}`);

    const response = {
      d: {
        results: po,
        __metadata: {
          uri: `/sap/opu/odata/sap/API_PURCHASEORDER_PROCESS_SRV/A_PurchaseOrder('${po.EBELN}')`,
          type: 'API_PURCHASEORDER_PROCESS_SRV.A_PurchaseOrderType',
        },
      },
      success: true,
      message: `Purchase order ${po.EBELN}/${po.EBELP} created successfully`,
      data: po,
      EBELN: po.EBELN,
      EBELP: po.EBELP,
      ZZSAP_DOC_NO: po.ZZSAP_DOC_NO,
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(response, { status: 201, headers: corsHeaders });
  } catch (error) {
    console.error('[SAP MM PO API] POST Error:', error);
    const response: SAPResponse = {
      success: false,
      message: 'Failed to create purchase order',
      error: {
        code: 'SY/530',
        message: {
          lang: 'en',
          value: error instanceof Error ? error.message : 'Unknown error',
        },
      },
      timestamp: new Date().toISOString(),
    };
    return NextResponse.json(response, { status: 500, headers: corsHeaders });
  }
}
