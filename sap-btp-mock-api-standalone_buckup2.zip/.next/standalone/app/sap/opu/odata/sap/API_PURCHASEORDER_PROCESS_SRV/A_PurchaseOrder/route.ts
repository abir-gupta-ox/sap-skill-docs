import type { NextRequest } from 'next/server';
import * as purchaseOrderRoute from '@/app/api/sap/mm/purchase-order/route';

export async function OPTIONS() {
  return purchaseOrderRoute.OPTIONS();
}

export async function GET(request: NextRequest) {
  return purchaseOrderRoute.GET(request);
}

export async function POST(request: NextRequest) {
  return purchaseOrderRoute.POST(request);
}
