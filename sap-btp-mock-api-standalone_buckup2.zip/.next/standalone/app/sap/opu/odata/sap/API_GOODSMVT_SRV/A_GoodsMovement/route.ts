import type { NextRequest } from 'next/server';
import * as goodsMovementRoute from '@/app/api/sap/mm/goods-movement/route';

export async function OPTIONS() {
  return goodsMovementRoute.OPTIONS();
}

export async function GET(request: NextRequest) {
  return goodsMovementRoute.GET(request);
}

export async function POST(request: NextRequest) {
  return goodsMovementRoute.POST(request);
}
