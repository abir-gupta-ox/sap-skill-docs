import type { NextRequest } from 'next/server';
import * as materialRoute from '@/app/api/sap/mm/material/route';

export async function OPTIONS() {
  return materialRoute.OPTIONS();
}

export async function GET(request: NextRequest) {
  return materialRoute.GET(request);
}

export async function POST(request: NextRequest) {
  return materialRoute.POST(request);
}

export async function PUT(request: NextRequest) {
  return materialRoute.PUT(request);
}

export async function DELETE(request: NextRequest) {
  return materialRoute.DELETE(request);
}
