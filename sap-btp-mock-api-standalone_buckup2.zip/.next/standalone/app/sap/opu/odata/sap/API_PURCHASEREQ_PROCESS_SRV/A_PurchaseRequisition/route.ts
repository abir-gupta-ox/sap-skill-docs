import type { NextRequest } from 'next/server';
import * as purchaseRequisitionRoute from '@/app/api/sap/mm/purchase-requisition/route';
import * as purchaseRequisitionApprovalRoute from '@/app/api/sap/mm/purchase-requisition/approval/route';

export async function OPTIONS() {
  return purchaseRequisitionRoute.OPTIONS();
}

export async function GET(request: NextRequest) {
  return purchaseRequisitionRoute.GET(request);
}

export async function POST(request: NextRequest) {
  const body = await request.clone().json().catch(() => null);
  const payload = (body && typeof body === 'object' && 'd' in body && body.d) ? body.d : body;
  const approvalLike =
    payload &&
    typeof payload === 'object' &&
    'BANFN' in payload &&
    ('FRGST' in payload || 'STATU' in payload || 'ZZAPPROVER_ID' in payload || 'ZZAPPROVAL_NOTES' in payload);

  if (approvalLike) {
    return purchaseRequisitionApprovalRoute.POST(request);
  }

  return purchaseRequisitionRoute.POST(request);
}

export async function PATCH(request: NextRequest) {
  return purchaseRequisitionApprovalRoute.PATCH(request);
}

export async function PUT(request: NextRequest) {
  return purchaseRequisitionRoute.PUT(request);
}

export async function DELETE(request: NextRequest) {
  return purchaseRequisitionRoute.DELETE(request);
}
