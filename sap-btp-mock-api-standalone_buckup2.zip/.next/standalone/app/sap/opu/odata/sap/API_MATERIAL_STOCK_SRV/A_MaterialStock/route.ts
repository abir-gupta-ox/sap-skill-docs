import type { NextRequest } from 'next/server';
import * as materialStockRoute from '@/app/api/sap/mm/material-stock/route';

export async function OPTIONS() {
  return materialStockRoute.OPTIONS();
}

export async function GET(request: NextRequest) {
  return materialStockRoute.GET(request);
}

export async function PUT(request: NextRequest) {
  return materialStockRoute.PUT(request);
}
