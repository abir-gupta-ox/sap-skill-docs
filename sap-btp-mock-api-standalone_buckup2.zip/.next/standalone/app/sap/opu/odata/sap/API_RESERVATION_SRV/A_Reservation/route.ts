import type { NextRequest } from 'next/server';
import * as stockReservationRoute from '@/app/api/sap/mm/stock-reservation/route';

export async function OPTIONS() {
  return stockReservationRoute.OPTIONS();
}

export async function GET(request: NextRequest) {
  return stockReservationRoute.GET(request);
}

export async function POST(request: NextRequest) {
  return stockReservationRoute.POST(request);
}
