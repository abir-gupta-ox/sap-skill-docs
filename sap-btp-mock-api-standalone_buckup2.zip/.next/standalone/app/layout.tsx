export const metadata = {
  title: 'SAP BTP Mock API',
  description: 'Mock SAP BTP API for OXmaint Integration',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
