'use client';

import { useState, useEffect } from 'react';
import {
  Sidebar,
  Header,
  MaterialsTable,
  ApiEndpoints,
  SampleRequests,
  FieldReference,
  ModuleComingSoon,
  TabNavigation,
  TabComingSoon,
  PurchaseRequisitionsTable,
  PRApiEndpoints,
  PRSampleRequests,
  PRFieldReference,
  GoodsReceiptTable,
  GRApiEndpoints,
  GRSampleRequests,
  GRFieldReference,
  PurchaseOrdersTable,
  POApiEndpoints,
  POSampleRequests,
  POFieldReference,
  StockReservationsTable,
  SRApiEndpoints,
  SRSampleRequests,
  SRFieldReference
} from '@/components';
import { ModuleKey, MMTabKey, SAPMaterial, SAPPurchaseRequisition, SAPGoodsReceipt, SAPPurchaseOrder, SAPStockReservation, SAP_MODULES, MM_TABS } from '@/types/sap';

export default function Home() {
  const [activeModule, setActiveModule] = useState<ModuleKey>('MM');
  const [activeTab, setActiveTab] = useState<MMTabKey>('material');
  const [materials, setMaterials] = useState<SAPMaterial[]>([]);
  const [materialCount, setMaterialCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [purchaseRequisitions, setPurchaseRequisitions] = useState<SAPPurchaseRequisition[]>([]);
  const [prCount, setPrCount] = useState(0);
  const [prLoading, setPrLoading] = useState(true);
  const [goodsReceipts, setGoodsReceipts] = useState<SAPGoodsReceipt[]>([]);
  const [grCount, setGrCount] = useState(0);
  const [grLoading, setGrLoading] = useState(true);
  const [purchaseOrders, setPurchaseOrders] = useState<SAPPurchaseOrder[]>([]);
  const [poCount, setPoCount] = useState(0);
  const [poLoading, setPoLoading] = useState(true);
  const [stockReservations, setStockReservations] = useState<SAPStockReservation[]>([]);
  const [srCount, setSrCount] = useState(0);
  const [srLoading, setSrLoading] = useState(true);

  // Fetch materials from API
  useEffect(() => {
    const fetchMaterials = async () => {
      try {
        const res = await fetch('/api/sap/mm/material');
        const data = await res.json();
        if (data.success && data.data?.results) {
          setMaterials(data.data.results);
          setMaterialCount(data.data.__count || data.data.results.length);
        }
      } catch (error) {
        console.error('Failed to fetch materials:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchMaterials();
  }, []);

  // Fetch purchase requisitions from API
  useEffect(() => {
    const fetchPurchaseRequisitions = async () => {
      try {
        const res = await fetch('/api/sap/mm/purchase-requisition');
        const data = await res.json();
        if (data.success && data.data?.results) {
          setPurchaseRequisitions(data.data.results);
          setPrCount(data.data.__count || data.data.results.length);
        }
      } catch (error) {
        console.error('Failed to fetch purchase requisitions:', error);
      } finally {
        setPrLoading(false);
      }
    };
    fetchPurchaseRequisitions();
  }, []);

  // Fetch goods movements from API
  useEffect(() => {
    const fetchGoodsMovements = async () => {
      try {
        const res = await fetch('/api/sap/mm/goods-movement');
        const data = await res.json();
        if (data.success && data.data?.results) {
          setGoodsReceipts(data.data.results);
          setGrCount(data.data.__count || data.data.results.length);
        }
      } catch (error) {
        console.error('Failed to fetch goods receipts:', error);
      } finally {
        setGrLoading(false);
      }
    };
    fetchGoodsMovements();
  }, []);

  // Fetch purchase orders from API
  useEffect(() => {
    const fetchPurchaseOrders = async () => {
      try {
        const res = await fetch('/api/sap/mm/purchase-order');
        const data = await res.json();
        if (data.success && data.data?.results) {
          setPurchaseOrders(data.data.results);
          setPoCount(data.data.__count || data.data.results.length);
        }
      } catch (error) {
        console.error('Failed to fetch purchase orders:', error);
      } finally {
        setPoLoading(false);
      }
    };
    fetchPurchaseOrders();
  }, []);

  // Fetch stock reservations from API
  useEffect(() => {
    const fetchStockReservations = async () => {
      try {
        const res = await fetch('/api/sap/mm/stock-reservation');
        const data = await res.json();
        if (data.success && data.data?.results) {
          setStockReservations(data.data.results);
          setSrCount(data.data.__count || data.data.results.length);
        }
      } catch (error) {
        console.error('Failed to fetch stock reservations:', error);
      } finally {
        setSrLoading(false);
      }
    };
    fetchStockReservations();
  }, []);

  // Update MM count (number of APIs: 4 tabs = 4 API groups)
  const modules = { ...SAP_MODULES };
  const mmApiCount = 5; // Material, PR, GR, PO, Stock Reservation APIs
  modules.MM = { ...modules.MM, count: mmApiCount };

  // Get current tab
  const currentTab = MM_TABS.find(t => t.key === activeTab) || MM_TABS[0];

  return (
    <div style={{ display: 'flex', minHeight: '100vh', fontFamily: 'system-ui, sans-serif', background: '#f9fafb' }}>
      <Sidebar
        modules={modules}
        activeModule={activeModule}
        onModuleChange={setActiveModule}
      />

      <main style={{ flex: 1, background: '#f7fafc', overflow: 'auto' }}>
        <Header module={modules[activeModule]} moduleKey={activeModule} />

        <div style={{ padding: '30px' }}>
          {activeModule === 'MM' ? (
            <>
              <TabNavigation
                tabs={MM_TABS}
                activeTab={activeTab}
                onTabChange={setActiveTab}
              />

              {activeTab === 'material' ? (
                <>
                  <MaterialsTable
                    materials={materials}
                    loading={loading}
                    materialCount={materialCount}
                  />
                  <ApiEndpoints />
                  <SampleRequests />
                  <FieldReference />
                </>
              ) : activeTab === 'purchase-requisition' ? (
                <>
                  <PurchaseRequisitionsTable
                    purchaseRequisitions={purchaseRequisitions}
                    loading={prLoading}
                    prCount={prCount}
                  />
                  <PRApiEndpoints />
                  <PRSampleRequests />
                  <PRFieldReference />
                </>
              ) : activeTab === 'goods-movement' ? (
                <>
                  <GoodsReceiptTable
                    goodsReceipts={goodsReceipts}
                    loading={grLoading}
                    grCount={grCount}
                  />
                  <GRApiEndpoints />
                  <GRSampleRequests />
                  <GRFieldReference />
                </>
              ) : activeTab === 'purchase-order' ? (
                <>
                  <PurchaseOrdersTable
                    purchaseOrders={purchaseOrders}
                    loading={poLoading}
                    poCount={poCount}
                  />
                  <POApiEndpoints />
                  <POSampleRequests />
                  <POFieldReference />
                </>
              ) : activeTab === 'stock-reservation' ? (
                <>
                  <StockReservationsTable
                    stockReservations={stockReservations}
                    loading={srLoading}
                    srCount={srCount}
                  />
                  <SRApiEndpoints />
                  <SRSampleRequests />
                  <SRFieldReference />
                </>
              ) : (
                <TabComingSoon
                  tab={currentTab}
                  onGoToMaterial={() => setActiveTab('material')}
                />
              )}
            </>
          ) : (
            <ModuleComingSoon
              module={modules[activeModule]}
              onGoToMM={() => setActiveModule('MM')}
            />
          )}
        </div>
      </main>
    </div>
  );
}
