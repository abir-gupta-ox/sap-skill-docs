'use client';

import { ModuleKey, SAPModule } from '@/types/sap';

interface ModuleComingSoonProps {
  module: SAPModule;
  onGoToMM: () => void;
}

export default function ModuleComingSoon({ module, onGoToMM }: ModuleComingSoonProps) {
  return (
    <div style={{
      background: '#fff',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
      padding: '60px',
      textAlign: 'center'
    }}>
      <div style={{ fontSize: '48px', marginBottom: '20px' }}>{module.icon}</div>
      <h3 style={{ margin: '0 0 10px', color: '#2d3748' }}>{module.name}</h3>
      <p style={{ color: '#718096', margin: '0 0 20px' }}>
        This module is coming soon. Currently only Materials Management (MM) is available.
      </p>
      <button
        onClick={onGoToMM}
        style={{
          padding: '10px 24px',
          background: '#4299e1',
          color: '#fff',
          border: 'none',
          borderRadius: '6px',
          cursor: 'pointer',
          fontSize: '14px',
          fontWeight: '500'
        }}
      >
        Go to Materials Management
      </button>
    </div>
  );
}
