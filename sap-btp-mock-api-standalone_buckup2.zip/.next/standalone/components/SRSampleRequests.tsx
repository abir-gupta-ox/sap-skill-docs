'use client';

interface SampleRequest {
  title: string;
  color: { bg: string; text: string };
  code: string;
}

const sampleRequests: SampleRequest[] = [
  {
    title: 'POST - Create Stock Reservation (MB21)',
    color: { bg: '#fefcbf', text: '#975a16' },
    code: `curl -X POST http://localhost:3001/api/sap/mm/stock-reservation \\
  -H "Content-Type: application/json" \\
  -H "X-SAP-User: OXMAINT_SYNC" \\
  -d '{
    "stock_reservation_number": "RES02111018",
    "MATNR": "000000000010000001",
    "quantity": 10,
    "ZZOXMAINT_WO_REF": "OXMAINT-WO-12345"
  }'`
  },
  {
    title: 'GET - Reservation by Number',
    color: { bg: '#c6f6d5', text: '#22543d' },
    code: `curl "http://localhost:3001/api/sap/mm/stock-reservation?RSNUM=RES02111018"`
  },
  {
    title: 'GET - Filter by Work Order',
    color: { bg: '#bee3f8', text: '#2b6cb0' },
    code: `curl "http://localhost:3001/api/sap/mm/stock-reservation?AUFNR=WO-2026-001"`
  },
];

export default function SRSampleRequests() {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(450px, 1fr))', gap: '20px' }}>
      {sampleRequests.map((request, index) => (
        <div key={index} style={{
          background: '#fff',
          borderRadius: '8px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          overflow: 'hidden'
        }}>
          <div style={{ padding: '15px 20px', borderBottom: '1px solid #e2e8f0', background: request.color.bg }}>
            <h4 style={{ margin: 0, fontSize: '14px', color: request.color.text }}>{request.title}</h4>
          </div>
          <pre style={{
            margin: 0,
            padding: '15px 20px',
            background: '#1a202c',
            color: '#e2e8f0',
            fontSize: '11px',
            overflow: 'auto',
            maxHeight: '300px'
          }}>
            {request.code}
          </pre>
        </div>
      ))}
    </div>
  );
}
