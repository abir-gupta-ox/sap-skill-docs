'use client';

interface Endpoint {
  method: string;
  path: string;
  description: string;
  color: { bg: string; text: string };
}

const endpoints: Endpoint[] = [
  { method: 'GET', path: '/api/sap/mm/material', description: 'Get all materials', color: { bg: '#c6f6d5', text: '#276749' } },
  { method: 'GET', path: '/api/sap/mm/material?MATNR=xxx', description: 'Get material by number', color: { bg: '#c6f6d5', text: '#276749' } },
  { method: 'POST', path: '/api/sap/mm/material', description: 'Create material (MM-001)', color: { bg: '#fefcbf', text: '#975a16' } },
  { method: 'PUT', path: '/api/sap/mm/material', description: 'Update material (MM-002)', color: { bg: '#bee3f8', text: '#2b6cb0' } },
];

export default function ApiEndpoints() {
  return (
    <div style={{
      background: '#fff',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
      overflow: 'hidden',
      marginBottom: '30px'
    }}>
      <div style={{ padding: '15px 20px', borderBottom: '1px solid #e2e8f0' }}>
        <h3 style={{ margin: 0, fontSize: '16px', color: '#2d3748' }}>API Endpoints</h3>
      </div>
      <div style={{ padding: '20px' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
          <thead>
            <tr>
              <th style={{ padding: '10px', textAlign: 'left', borderBottom: '1px solid #e2e8f0' }}>Method</th>
              <th style={{ padding: '10px', textAlign: 'left', borderBottom: '1px solid #e2e8f0' }}>Endpoint</th>
              <th style={{ padding: '10px', textAlign: 'left', borderBottom: '1px solid #e2e8f0' }}>Description</th>
            </tr>
          </thead>
          <tbody>
            {endpoints.map((endpoint, index) => (
              <tr key={index}>
                <td style={{ padding: '10px' }}>
                  <span style={{
                    background: endpoint.color.bg,
                    color: endpoint.color.text,
                    padding: '2px 8px',
                    borderRadius: '4px',
                    fontSize: '12px',
                    fontWeight: '600'
                  }}>
                    {endpoint.method}
                  </span>
                </td>
                <td style={{ padding: '10px' }}>
                  <code style={{ background: '#f7fafc', padding: '4px 8px', borderRadius: '4px' }}>
                    {endpoint.path}
                  </code>
                </td>
                <td style={{ padding: '10px', color: '#718096' }}>{endpoint.description}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
