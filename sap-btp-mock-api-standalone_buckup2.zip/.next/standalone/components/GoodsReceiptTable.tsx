'use client';

import { SAPGoodsReceipt } from '@/types/sap';

interface GoodsReceiptTableProps {
  goodsReceipts: SAPGoodsReceipt[];
  loading: boolean;
  grCount: number;
}

// SAP Movement Types
const SAP_MOVEMENT_TYPES: Record<string, { label: string; bg: string; text: string }> = {
  // Goods Receipt (Stock IN)
  '101': { label: 'GR for PO', bg: '#c6f6d5', text: '#276749' },
  '103': { label: 'GR for Prod', bg: '#bee3f8', text: '#2b6cb0' },
  '105': { label: 'GR Free', bg: '#e9d8fd', text: '#553c9a' },
  '161': { label: 'GR for WO', bg: '#fefcbf', text: '#975a16' },
  '301': { label: 'Plant Transfer In', bg: '#c6f6d5', text: '#276749' },
  '311': { label: 'SLoc Transfer In', bg: '#c6f6d5', text: '#276749' },
  '501': { label: 'Receipt w/o PO', bg: '#e9d8fd', text: '#553c9a' },
  '561': { label: 'Initial Stock', bg: '#e2e8f0', text: '#4a5568' },
  // Goods Issue (Stock OUT)
  '122': { label: 'Return to Vendor', bg: '#fed7d7', text: '#c53030' },
  '201': { label: 'GI for Cost Ctr', bg: '#fed7d7', text: '#c53030' },
  '221': { label: 'GI for Project', bg: '#fed7d7', text: '#c53030' },
  '261': { label: 'GI for Order', bg: '#fed7d7', text: '#c53030' },
};

// Istanbul Airport Plants
const SAP_PLANTS: Record<string, string> = {
  'IST1': 'Terminal 1',
  'IST2': 'Terminal 2',
  'ISTC': 'Cargo Terminal',
  'ISTM': 'Maintenance',
  'ISTR': 'Runway Ops',
};

// Format SAP date (YYYYMMDD) to readable format
const formatSAPDate = (sapDate?: string): string => {
  if (!sapDate || sapDate.length !== 8) return '-';
  const year = sapDate.substring(0, 4);
  const month = sapDate.substring(4, 6);
  const day = sapDate.substring(6, 8);
  return `${day}/${month}/${year}`;
};

export default function GoodsReceiptTable({
  goodsReceipts,
  loading,
  grCount
}: GoodsReceiptTableProps) {
  return (
    <div style={{
      background: '#fff',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
      overflow: 'hidden',
      marginBottom: '30px'
    }}>
      <div style={{
        padding: '15px 20px',
        borderBottom: '1px solid #e2e8f0',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <h3 style={{ margin: 0, fontSize: '16px', color: '#2d3748' }}>Goods Movements in Database</h3>
        <span style={{
          background: '#c6f6d5',
          color: '#276749',
          padding: '4px 12px',
          borderRadius: '20px',
          fontSize: '13px',
          fontWeight: '500'
        }}>
          {grCount} records
        </span>
      </div>

      {loading ? (
        <div style={{ padding: '40px', textAlign: 'center', color: '#718096' }}>
          Loading goods receipts...
        </div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
            <thead>
              <tr style={{ background: '#f7fafc' }}>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Issue Id</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Material Number</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Mvt Type</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Plant / SLoc</th>
                <th style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Quantity</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Posting Date</th>
              </tr>
            </thead>
            <tbody>
              {goodsReceipts.length === 0 ? (
                <tr>
                  <td colSpan={6} style={{ padding: '30px', textAlign: 'center', color: '#718096' }}>
                    No goods movements found. Create one using the API!
                  </td>
                </tr>
              ) : (
                goodsReceipts.map((gr) => {
                  const mvtType = SAP_MOVEMENT_TYPES[gr.BWART] || { label: gr.BWART, bg: '#e2e8f0', text: '#4a5568' };
                  return (
                    <tr key={`${gr.MBLNR}-${gr.MJAHR}-${gr.ZEILE}`} style={{ borderBottom: '1px solid #e2e8f0' }}>
                      <td style={{ padding: '12px 16px' }}>
                        <div style={{ fontFamily: 'monospace', fontSize: '12px', color: '#4a5568' }}>
                          {gr.MBLNR}
                        </div>
                        <div style={{ fontSize: '11px', color: '#a0aec0' }}>
                          {gr.MJAHR} / Item {gr.ZEILE}
                        </div>
                      </td>
                      <td style={{ padding: '12px 16px', color: '#2d3748' }}>
                        <div style={{ fontFamily: 'monospace', fontSize: '12px' }}>
                          {gr.MATNR}
                        </div>
                        {gr.SGTXT && (
                          <div style={{ fontSize: '11px', color: '#a0aec0', maxWidth: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                            {gr.SGTXT}
                          </div>
                        )}
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        <span style={{
                          background: mvtType.bg,
                          padding: '3px 10px',
                          borderRadius: '4px',
                          fontSize: '12px',
                          fontWeight: '500',
                          color: mvtType.text
                        }}>
                          {gr.BWART}
                        </span>
                        <div style={{ color: '#718096', fontSize: '11px', marginTop: '2px' }}>
                          {mvtType.label}
                        </div>
                      </td>
                      <td style={{ padding: '12px 16px', color: '#4a5568' }}>
                        <div>{gr.WERKS}</div>
                        <div style={{ fontSize: '11px', color: '#a0aec0' }}>
                          {SAP_PLANTS[gr.WERKS]} / {gr.LGORT}
                        </div>
                      </td>
                      <td style={{ padding: '12px 16px', textAlign: 'right', fontFamily: 'monospace', color: '#4a5568' }}>
                        <div>{gr.MENGE} {gr.MEINS}</div>
                        {gr.DMBTR !== undefined && gr.DMBTR !== null && gr.DMBTR > 0 && (
                          <div style={{ fontSize: '11px', color: '#a0aec0' }}>
                            {gr.WAERS || 'USD'} {gr.DMBTR.toFixed(2)}
                          </div>
                        )}
                      </td>
                      <td style={{ padding: '12px 16px', color: '#4a5568', fontSize: '13px' }}>
                        {formatSAPDate(gr.BUDAT)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
