'use client';

import { SAPPurchaseRequisition } from '@/types/sap';

interface PurchaseRequisitionsTableProps {
  purchaseRequisitions: SAPPurchaseRequisition[];
  loading: boolean;
  prCount: number;
}

// SAP PR Document Types
const SAP_PR_DOCUMENT_TYPES: Record<string, string> = {
  'NB': 'Standard PR',
  'ZNB': 'Custom PR',
  'ZSER': 'Service PR',
  'ZSTO': 'Stock Transport',
  'ZURG': 'Urgent PR',
};

// SAP PR Status
const SAP_PR_STATUS: Record<string, { label: string; bg: string; text: string }> = {
  'N': { label: 'New', bg: '#bee3f8', text: '#2b6cb0' },
  'B': { label: 'Blocked', bg: '#fed7d7', text: '#c53030' },
  'A': { label: 'Released', bg: '#c6f6d5', text: '#276749' },
  'L': { label: 'Locked', bg: '#fefcbf', text: '#975a16' },
  'X': { label: 'Deleted', bg: '#e2e8f0', text: '#718096' },
};

// Istanbul Airport Plants
const SAP_PLANTS: Record<string, string> = {
  'IST1': 'Terminal 1',
  'IST2': 'Terminal 2',
  'ISTC': 'Cargo Terminal',
  'ISTM': 'Maintenance',
  'ISTR': 'Runway Ops',
};

// Purchasing Groups
const SAP_PURCHASING_GROUPS: Record<string, string> = {
  '001': 'Spare Parts',
  '002': 'Equipment',
  '003': 'Consumables',
  '004': 'Services',
  '005': 'Emergency',
};

// Format SAP date (YYYYMMDD) to readable format
const formatSAPDate = (sapDate?: string): string => {
  if (!sapDate || sapDate.length !== 8) return '-';
  const year = sapDate.substring(0, 4);
  const month = sapDate.substring(4, 6);
  const day = sapDate.substring(6, 8);
  return `${day}/${month}/${year}`;
};

export default function PurchaseRequisitionsTable({
  purchaseRequisitions,
  loading,
  prCount
}: PurchaseRequisitionsTableProps) {
  return (
    <div style={{
      background: '#fff',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
      overflow: 'hidden',
      marginBottom: '30px'
    }}>
      <div style={{
        padding: '15px 20px',
        borderBottom: '1px solid #e2e8f0',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <h3 style={{ margin: 0, fontSize: '16px', color: '#2d3748' }}>Purchase Requisitions in Database</h3>
        <span style={{
          background: '#e9d8fd',
          color: '#553c9a',
          padding: '4px 12px',
          borderRadius: '20px',
          fontSize: '13px',
          fontWeight: '500'
        }}>
          {prCount} records
        </span>
      </div>

      {loading ? (
        <div style={{ padding: '40px', textAlign: 'center', color: '#718096' }}>
          Loading purchase requisitions...
        </div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
            <thead>
              <tr style={{ background: '#f7fafc' }}>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>BANFN / Item</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Description</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Type</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Plant</th>
                <th style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Quantity</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Delivery</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Work Order</th>
                <th style={{ padding: '12px 16px', textAlign: 'center', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {purchaseRequisitions.length === 0 ? (
                <tr>
                  <td colSpan={8} style={{ padding: '30px', textAlign: 'center', color: '#718096' }}>
                    No purchase requisitions found. Create one using the API!
                  </td>
                </tr>
              ) : (
                purchaseRequisitions.map((pr) => {
                  const status = SAP_PR_STATUS[pr.STATU] || SAP_PR_STATUS['N'];
                  return (
                    <tr key={`${pr.BANFN}-${pr.BNFPO}`} style={{ borderBottom: '1px solid #e2e8f0' }}>
                      <td style={{ padding: '12px 16px' }}>
                        <div style={{ fontFamily: 'monospace', fontSize: '12px', color: '#4a5568' }}>
                          {pr.BANFN}
                        </div>
                        <div style={{ fontSize: '11px', color: '#a0aec0' }}>
                          Item: {pr.BNFPO}
                        </div>
                      </td>
                      <td style={{ padding: '12px 16px', color: '#2d3748', maxWidth: '200px' }}>
                        <div style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                          {pr.TXZ01}
                        </div>
                        {pr.MATNR && (
                          <div style={{ fontSize: '11px', color: '#a0aec0', fontFamily: 'monospace' }}>
                            Mat: {pr.MATNR}
                          </div>
                        )}
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        <span style={{
                          background: '#e9d8fd',
                          padding: '3px 10px',
                          borderRadius: '4px',
                          fontSize: '12px',
                          fontWeight: '500',
                          color: '#553c9a'
                        }}>
                          {pr.BSART}
                        </span>
                        <span style={{ color: '#718096', fontSize: '11px', marginLeft: '6px' }}>
                          {SAP_PR_DOCUMENT_TYPES[pr.BSART]}
                        </span>
                      </td>
                      <td style={{ padding: '12px 16px', color: '#4a5568' }}>
                        <div>{pr.WERKS}</div>
                        <div style={{ fontSize: '11px', color: '#a0aec0' }}>
                          {SAP_PLANTS[pr.WERKS]}
                        </div>
                      </td>
                      <td style={{ padding: '12px 16px', textAlign: 'right', fontFamily: 'monospace', color: '#4a5568' }}>
                        <div>{pr.MENGE} {pr.MEINS}</div>
                        {pr.PREIS !== undefined && pr.PREIS !== null && pr.PREIS > 0 && (
                          <div style={{ fontSize: '11px', color: '#a0aec0' }}>
                            {pr.WAERS || 'USD'} {pr.PREIS.toFixed(2)}
                          </div>
                        )}
                      </td>
                      <td style={{ padding: '12px 16px', color: '#4a5568', fontSize: '13px' }}>
                        {formatSAPDate(pr.LFDAT)}
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        {pr.AUFNR ? (
                          <span style={{
                            background: '#fefcbf',
                            padding: '3px 8px',
                            borderRadius: '4px',
                            fontSize: '11px',
                            fontWeight: '500',
                            color: '#975a16'
                          }}>
                            {pr.AUFNR}
                          </span>
                        ) : pr.ZZOXMAINT_WO_REF ? (
                          <span style={{
                            background: '#e6fffa',
                            padding: '3px 8px',
                            borderRadius: '4px',
                            fontSize: '11px',
                            fontWeight: '500',
                            color: '#285e61'
                          }}>
                            {pr.ZZOXMAINT_WO_REF}
                          </span>
                        ) : (
                          <span style={{ color: '#a0aec0', fontSize: '12px' }}>-</span>
                        )}
                      </td>
                      <td style={{ padding: '12px 16px', textAlign: 'center' }}>
                        <span style={{
                          background: status.bg,
                          color: status.text,
                          padding: '3px 10px',
                          borderRadius: '20px',
                          fontSize: '11px',
                          fontWeight: '600'
                        }}>
                          {status.label}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
