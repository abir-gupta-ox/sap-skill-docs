'use client';

import { SAPMaterial } from '@/types/sap';

interface MaterialsTableProps {
  materials: SAPMaterial[];
  loading: boolean;
  materialCount: number;
}

const SAP_MATERIAL_TYPES: Record<string, string> = {
  HAWA: 'Trading Goods',
  FERT: 'Finished Product',
  HALB: 'Semi-Finished Product',
  ROH: 'Raw Material',
  ERSA: 'Spare Parts',
  NLAG: 'Non-Stock Material',
  VERP: 'Packaging Material',
  DIEN: 'Services',
};

// Istanbul Airport Plants
const SAP_PLANTS: Record<string, string> = {
  'IST1': 'Terminal 1 - International',
  'IST2': 'Terminal 2 - Domestic',
  'ISTC': 'Cargo Terminal',
  'ISTM': 'Maintenance Hangar',
  'ISTR': 'Runway Operations',
};

export default function MaterialsTable({ materials, loading, materialCount }: MaterialsTableProps) {
  return (
    <div style={{
      background: '#fff',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
      overflow: 'hidden',
      marginBottom: '30px'
    }}>
      <div style={{
        padding: '15px 20px',
        borderBottom: '1px solid #e2e8f0',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <h3 style={{ margin: 0, fontSize: '16px', color: '#2d3748' }}>Materials in Database</h3>
        <span style={{
          background: '#ebf8ff',
          color: '#3182ce',
          padding: '4px 12px',
          borderRadius: '20px',
          fontSize: '13px',
          fontWeight: '500'
        }}>
          {materialCount} records
        </span>
      </div>

      {loading ? (
        <div style={{ padding: '40px', textAlign: 'center', color: '#718096' }}>
          Loading materials...
        </div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
            <thead>
              <tr style={{ background: '#f7fafc' }}>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>MATNR</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Description</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Type</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Plant</th>
                <th style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Stock</th>
                <th style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Price</th>
                <th style={{ padding: '12px 16px', textAlign: 'center', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {materials.length === 0 ? (
                <tr>
                  <td colSpan={7} style={{ padding: '30px', textAlign: 'center', color: '#718096' }}>
                    No materials found
                  </td>
                </tr>
              ) : (
                materials.map((mat) => (
                  <tr key={mat.MATNR} style={{ borderBottom: '1px solid #e2e8f0' }}>
                    <td style={{ padding: '12px 16px', fontFamily: 'monospace', fontSize: '12px', color: '#4a5568' }}>
                      {mat.MATNR}
                    </td>
                    <td style={{ padding: '12px 16px', color: '#2d3748' }}>{mat.MAKTX}</td>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{
                        background: '#e2e8f0',
                        padding: '3px 10px',
                        borderRadius: '4px',
                        fontSize: '12px',
                        fontWeight: '500'
                      }}>
                        {mat.MTART}
                      </span>
                      <span style={{ color: '#718096', fontSize: '12px', marginLeft: '8px' }}>
                        {SAP_MATERIAL_TYPES[mat.MTART]}
                      </span>
                    </td>
                    <td style={{ padding: '12px 16px', color: '#4a5568' }}>
                      {mat.WERKS}
                      <span style={{ color: '#a0aec0', fontSize: '12px', marginLeft: '6px' }}>
                        ({SAP_PLANTS[mat.WERKS]})
                      </span>
                    </td>
                    <td style={{ padding: '12px 16px', textAlign: 'right', fontFamily: 'monospace', color: '#4a5568' }}>
                      {mat.EISBE} {mat.MEINS}
                    </td>
                    <td style={{ padding: '12px 16px', textAlign: 'right', fontFamily: 'monospace', color: '#2d3748', fontWeight: '500' }}>
                      {mat.WAERS} {mat.STPRS?.toFixed(2)}
                    </td>
                    <td style={{ padding: '12px 16px', textAlign: 'center' }}>
                      <span style={{
                        background: mat.ZZSYNC_STATUS === 'SYNCED' ? '#c6f6d5' : mat.ZZSYNC_STATUS === 'PENDING' ? '#fefcbf' : '#fed7d7',
                        color: mat.ZZSYNC_STATUS === 'SYNCED' ? '#276749' : mat.ZZSYNC_STATUS === 'PENDING' ? '#975a16' : '#c53030',
                        padding: '3px 10px',
                        borderRadius: '20px',
                        fontSize: '11px',
                        fontWeight: '600'
                      }}>
                        {mat.ZZSYNC_STATUS}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
