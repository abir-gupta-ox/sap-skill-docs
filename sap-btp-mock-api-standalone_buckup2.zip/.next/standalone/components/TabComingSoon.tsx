'use client';

import { MMTab, MMTabKey } from '@/types/sap';

interface TabComingSoonProps {
  tab: MMTab;
  onGoToMaterial: () => void;
}

export default function TabComingSoon({ tab, onGoToMaterial }: TabComingSoonProps) {
  return (
    <div style={{
      background: '#fff',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
      padding: '60px',
      textAlign: 'center'
    }}>
      <div style={{ fontSize: '48px', marginBottom: '20px' }}>{tab.icon}</div>
      <h3 style={{ margin: '0 0 10px', color: '#2d3748' }}>{tab.label}</h3>
      <p style={{ color: '#718096', margin: '0 0 10px' }}>
        This feature is coming soon.
      </p>
      <p style={{ color: '#a0aec0', margin: '0 0 20px', fontSize: '13px' }}>
        Endpoint: <code style={{ background: '#f7fafc', padding: '2px 6px', borderRadius: '4px' }}>{tab.endpoint}</code>
      </p>
      <button
        onClick={onGoToMaterial}
        style={{
          padding: '10px 24px',
          background: '#4299e1',
          color: '#fff',
          border: 'none',
          borderRadius: '6px',
          cursor: 'pointer',
          fontSize: '14px',
          fontWeight: '500'
        }}
      >
        Go to Material
      </button>
    </div>
  );
}
