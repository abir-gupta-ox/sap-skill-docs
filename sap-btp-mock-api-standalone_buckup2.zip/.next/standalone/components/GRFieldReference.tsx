'use client';

const fields = [
  { field: 'MBLNR', desc: 'Material Doc Number' },
  { field: 'MJAHR', desc: 'Document Year' },
  { field: 'ZEILE', desc: 'Item Number' },
  { field: 'BWART', desc: 'Movement Type' },
  { field: 'MATNR', desc: 'Material Number' },
  { field: 'WERKS', desc: 'Plant' },
  { field: 'LGORT', desc: 'Storage Location' },
  { field: 'MENGE', desc: 'Quantity' },
  { field: 'MEINS', desc: 'Unit of Measure' },
  { field: 'BUDAT', desc: 'Posting Date' },
  { field: 'AUFNR', desc: 'Work Order' },
  { field: 'EBELN', desc: 'Purchase Order' },
  { field: 'DMBTR', desc: 'Amount' },
  { field: 'WAERS', desc: 'Currency' },
  { field: 'ZZOXMAINT_WO_REF', desc: 'OXmaint WO Ref' },
];

export default function GRFieldReference() {
  return (
    <div style={{
      background: '#fff',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
      overflow: 'hidden',
      marginTop: '30px'
    }}>
      <div style={{ padding: '15px 20px', borderBottom: '1px solid #e2e8f0' }}>
        <h3 style={{ margin: 0, fontSize: '16px', color: '#2d3748' }}>SAP Field Reference</h3>
      </div>
      <div style={{ padding: '20px', display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '10px' }}>
        {fields.map((item) => (
          <div key={item.field} style={{
            background: '#f7fafc',
            padding: '10px 12px',
            borderRadius: '6px',
            display: 'flex',
            alignItems: 'center',
            gap: '10px'
          }}>
            <code style={{ fontWeight: 'bold', color: '#3182ce', fontSize: '13px' }}>{item.field}</code>
            <span style={{ color: '#718096', fontSize: '12px' }}>{item.desc}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
