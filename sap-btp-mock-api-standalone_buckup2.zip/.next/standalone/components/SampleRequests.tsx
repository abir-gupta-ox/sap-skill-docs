'use client';

interface SampleRequest {
  title: string;
  color: { bg: string; text: string };
  code: string;
}

// Istanbul Airport Sample Requests
const sampleRequests: SampleRequest[] = [
  {
    title: 'POST - Create Material',
    color: { bg: '#fefcbf', text: '#975a16' },
    code: `curl -X POST http://localhost:3001/api/sap/mm/material \\
  -H "Content-Type: application/json" \\
  -d '{
    "MATNR": "0000000000100000010",
    "MTART": "ERSA",
    "MATKL": "BHS",
    "MAKTX": "BHS Conveyor Belt 600mm Reinforced",
    "MEINS": "M",
    "BRGEW": 8.5,
    "GEWEI": "KG",
    "WERKS": "IST1",
    "LGORT": "WH01",
    "PLIFZ": 14,
    "MINBE": 200,
    "STPRS": 285.00,
    "WAERS": "TRY"
  }'`
  },
  {
    title: 'PUT - Update Material',
    color: { bg: '#bee3f8', text: '#2b6cb0' },
    code: `curl -X PUT http://localhost:3001/api/sap/mm/material \\
  -H "Content-Type: application/json" \\
  -d '{
    "MATNR": "000000000010000001",
    "MAKTX": "BHS Conveyor Belt 600mm Heavy Duty",
    "STPRS": 320.00
  }'`
  },
  {
    title: 'PUT - Update Stock & MRP',
    color: { bg: '#e9d8fd', text: '#553c9a' },
    code: `curl -X PUT http://localhost:3001/api/sap/mm/material-stock \\
  -H "Content-Type: application/json" \\
  -d '{
    "MATNR": "000000000010000001",
    "WERKS": "IST1",
    "LGORT": "WH02",
    "EISBE": 150,
    "MINBE": 300,
    "PLIFZ": 21,
    "STPRS": 295.00
  }'`
  }
];

export default function SampleRequests() {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '20px' }}>
      {sampleRequests.map((request, index) => (
        <div key={index} style={{
          background: '#fff',
          borderRadius: '8px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          overflow: 'hidden'
        }}>
          <div style={{ padding: '15px 20px', borderBottom: '1px solid #e2e8f0', background: request.color.bg }}>
            <h4 style={{ margin: 0, fontSize: '14px', color: request.color.text }}>{request.title}</h4>
          </div>
          <pre style={{
            margin: 0,
            padding: '15px 20px',
            background: '#1a202c',
            color: '#e2e8f0',
            fontSize: '12px',
            overflow: 'auto'
          }}>
            {request.code}
          </pre>
        </div>
      ))}
    </div>
  );
}
