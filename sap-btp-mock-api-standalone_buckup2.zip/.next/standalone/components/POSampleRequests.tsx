'use client';

interface SampleRequest {
  title: string;
  color: { bg: string; text: string };
  code: string;
}

const sampleRequests: SampleRequest[] = [
  {
    title: 'GET - Get All Purchase Orders',
    color: { bg: '#c6f6d5', text: '#22543d' },
    code: `# Get all purchase orders
curl "http://localhost:3001/api/sap/mm/purchase-order"

# Filter by plant
curl "http://localhost:3001/api/sap/mm/purchase-order?WERKS=IST1"

# Filter by vendor
curl "http://localhost:3001/api/sap/mm/purchase-order?LIFNR=VENDOR001"

# Filter by status (O=Open, P=Partial, C=Completed)
curl "http://localhost:3001/api/sap/mm/purchase-order?STATU=O"`
  },
  {
    title: 'POST - Convert PR to PO (ME59N)',
    color: { bg: '#e9d8fd', text: '#553c9a' },
    code: `curl -X POST http://localhost:3001/api/sap/mm/purchase-order \\
  -H "Content-Type: application/json" \\
  -d '{
    "BANFN": "0010000001",
    "BNFPO": "00010",
    "LIFNR": "VENDOR001"
  }'

# Response includes:
# - EBELN: Generated PO Number
# - EBELP: PO Item Number
# - ZZSAP_DOC_NO: SAP Document Reference
# - PR status updated to "C" (Converted)`
  },
];

export default function POSampleRequests() {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(450px, 1fr))', gap: '20px', marginBottom: '30px' }}>
      {sampleRequests.map((request, index) => (
        <div key={index} style={{
          background: '#fff',
          borderRadius: '8px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          overflow: 'hidden'
        }}>
          <div style={{ padding: '15px 20px', borderBottom: '1px solid #e2e8f0', background: request.color.bg }}>
            <h4 style={{ margin: 0, fontSize: '14px', color: request.color.text }}>{request.title}</h4>
          </div>
          <pre style={{
            margin: 0,
            padding: '15px 20px',
            background: '#1a202c',
            color: '#e2e8f0',
            fontSize: '11px',
            overflow: 'auto',
            maxHeight: '300px'
          }}>
            {request.code}
          </pre>
        </div>
      ))}
    </div>
  );
}
