'use client';

import { ModuleKey, SAPModule } from '@/types/sap';

interface SidebarProps {
  modules: Record<ModuleKey, SAPModule>;
  activeModule: ModuleKey;
  onModuleChange: (key: ModuleKey) => void;
}

export default function Sidebar({ modules, activeModule, onModuleChange }: SidebarProps) {
  return (
    <aside style={{
      width: '280px',
      background: '#fff',
      padding: '20px 0',
      flexShrink: 0,
      borderRight: '1px solid #e5e7eb',
      display: 'flex',
      flexDirection: 'column',
      height: '100vh',
      position: 'sticky',
      top: 0
    }}>
      {/* Logo */}
      <div style={{ padding: '0 20px 15px', borderBottom: '1px solid #e5e7eb' }}>
        <h1 style={{ margin: 0, fontSize: '18px', fontWeight: '600', color: '#111827' }}>
          Istanbul Airport (IST)
        </h1>
        <p style={{ margin: '5px 0 0', fontSize: '12px', color: '#6b7280' }}>
          SAP Mock API - OXmaint
        </p>
        {/* Database Status */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          marginTop: '10px',
          padding: '6px 10px',
          background: '#f0fdf4',
          borderRadius: '4px',
          fontSize: '11px',
          color: '#166534'
        }}>
          <span style={{
            width: '6px',
            height: '6px',
            borderRadius: '50%',
            background: '#22c55e',
            display: 'inline-block'
          }}></span>
          <span>JSON DB Connected</span>
        </div>
      </div>

      {/* Module Navigation */}
      <nav style={{ marginTop: '16px', flex: 1, overflowY: 'auto' }}>
        <div style={{ padding: '0 20px 8px', fontSize: '11px', color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.5px', fontWeight: '500' }}>
          SAP Modules
        </div>
        {(Object.keys(modules) as ModuleKey[]).map((key) => {
          const module = modules[key];
          const isActive = activeModule === key;
          return (
            <button
              key={key}
              onClick={() => module.available && onModuleChange(key)}
              disabled={!module.available}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                padding: '10px 20px',
                border: 'none',
                background: isActive ? '#f3f4f6' : 'transparent',
                color: module.available ? '#374151' : '#9ca3af',
                cursor: module.available ? 'pointer' : 'not-allowed',
                textAlign: 'left',
                fontSize: '14px',
                borderLeft: isActive ? '2px solid #374151' : '2px solid transparent',
                transition: 'all 0.15s',
                opacity: module.available ? 1 : 0.6,
              }}
              onMouseEnter={(e) => {
                if (module.available && !isActive) {
                  e.currentTarget.style.background = '#f9fafb';
                }
              }}
              onMouseLeave={(e) => {
                if (!isActive) {
                  e.currentTarget.style.background = 'transparent';
                }
              }}
            >
              <span style={{ fontSize: '18px', marginRight: '12px' }}>{module.icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: isActive ? '500' : '400', color: isActive ? '#111827' : '#374151' }}>{module.code}</div>
                <div style={{ fontSize: '11px', color: '#6b7280' }}>{module.name}</div>
              </div>
              {module.available ? (
                <span style={{
                  background: isActive ? '#e5e7eb' : '#f3f4f6',
                  color: '#374151',
                  padding: '2px 8px',
                  borderRadius: '4px',
                  fontSize: '11px',
                  fontWeight: '500'
                }}>
                  {module.count}
                </span>
              ) : (
                <span style={{
                  background: '#f3f4f6',
                  color: '#9ca3af',
                  padding: '2px 8px',
                  borderRadius: '4px',
                  fontSize: '10px',
                }}>
                  -
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </aside>
  );
}
