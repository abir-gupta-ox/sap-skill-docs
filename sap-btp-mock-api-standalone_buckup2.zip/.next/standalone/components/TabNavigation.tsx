'use client';

import { MMTab, MMTabKey } from '@/types/sap';

interface TabNavigationProps {
  tabs: MMTab[];
  activeTab: MMTabKey;
  onTabChange: (key: MMTabKey) => void;
}

export default function TabNavigation({ tabs, activeTab, onTabChange }: TabNavigationProps) {
  return (
    <div style={{
      display: 'flex',
      gap: '8px',
      marginBottom: '24px',
      borderBottom: '1px solid #e2e8f0',
      paddingBottom: '0'
    }}>
      {tabs.map((tab) => {
        const isActive = activeTab === tab.key;
        return (
          <button
            key={tab.key}
            type="button"
            onClick={() => tab.available && onTabChange(tab.key)}
            disabled={!tab.available}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '12px 20px',
              border: 'none',
              background: 'transparent',
              color: isActive ? '#3182ce' : tab.available ? '#4a5568' : '#a0aec0',
              cursor: tab.available ? 'pointer' : 'not-allowed',
              fontSize: '14px',
              fontWeight: isActive ? '600' : '500',
              borderBottom: isActive ? '2px solid #3182ce' : '2px solid transparent',
              marginBottom: '-1px',
              transition: 'all 0.15s',
              opacity: tab.available ? 1 : 0.6,
            }}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
            {!tab.available && (
              <span style={{
                background: '#f3f4f6',
                color: '#9ca3af',
                padding: '2px 6px',
                borderRadius: '4px',
                fontSize: '10px',
                marginLeft: '4px'
              }}>
                Soon
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
