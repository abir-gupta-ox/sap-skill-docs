'use client';

import { SAPModule } from '@/types/sap';

interface HeaderProps {
  module: SAPModule;
  moduleKey: string;
}

export default function Header({ module, moduleKey }: HeaderProps) {
  return (
    <header style={{
      background: '#fff',
      padding: '20px 30px',
      borderBottom: '1px solid #e2e8f0',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }}>
      <div>
        <h2 style={{ margin: 0, color: '#2d3748', display: 'flex', alignItems: 'center', gap: '10px' }}>
          <span style={{ fontSize: '28px' }}>{module.icon}</span>
          {module.name}
        </h2>
        <p style={{ margin: '5px 0 0', color: '#718096', fontSize: '14px' }}>
          Module: {moduleKey} | Records: {module.count}
        </p>
      </div>
      <div style={{ display: 'flex', gap: '10px' }}>
        <a
          href="/api/sap/mm/material"
          target="_blank"
          style={{
            padding: '10px 20px',
            background: '#4299e1',
            color: '#fff',
            borderRadius: '6px',
            textDecoration: 'none',
            fontSize: '14px',
            fontWeight: '500'
          }}
        >
          View API →
        </a>
        <a
          href="/api/health"
          target="_blank"
          style={{
            padding: '10px 20px',
            background: '#48bb78',
            color: '#fff',
            borderRadius: '6px',
            textDecoration: 'none',
            fontSize: '14px',
            fontWeight: '500'
          }}
        >
          Health Check
        </a>
      </div>
    </header>
  );
}
