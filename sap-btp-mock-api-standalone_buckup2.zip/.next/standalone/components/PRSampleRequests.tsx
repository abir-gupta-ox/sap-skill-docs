'use client';

interface SampleRequest {
  title: string;
  color: { bg: string; text: string };
  code: string;
}

// Purchase Requisition Sample Requests
const sampleRequests: SampleRequest[] = [
  {
    title: 'POST - Create PR from Work Order',
    color: { bg: '#fefcbf', text: '#975a16' },
    code: `curl -X POST http://localhost:3001/api/sap/mm/purchase-requisition \\
  -H "Content-Type: application/json" \\
  -H "X-SAP-User: OXMAINT_SYNC" \\
  -d '{
    "BSART": "NB",
    "TXZ01": "Conveyor Belt Replacement - Urgent",
    "MENGE": 10,
    "MEINS": "M",
    "WERKS": "IST1",
    "EKGRP": "001",
    "EKORG": "P001",
    "MATNR": "000000000010000001",
    "AUFNR": "WO-2024-001234",
    "KNTTP": "F",
    "PREIS": 2850.00,
    "WAERS": "TRY",
    "ZZOXMAINT_WO_REF": "OXMAINT-WO-12345"
  }'`
  },
  {
    title: 'POST - Approve PR (Approval Callback)',
    color: { bg: '#c6f6d5', text: '#22543d' },
    code: `curl -X POST http://localhost:3001/api/sap/mm/purchase-requisition/approval \\
  -H "Content-Type: application/json" \\
  -d '{
    "BANFN": "0010000002",
    "FRGST": "R",
    "ZZAPPROVER_ID": "ADMIN",
    "ZZAPPROVER_NAME": "John Smith",
    "ZZAPPROVAL_NOTES": "Approved for procurement"
  }'

# FRGST Values:
# "R" = Released (Approved)
# "X" = Rejected
# "P" = Pending Approval
# ""  = Not Released`
  },
  {
    title: 'POST - Reject PR (Approval Callback)',
    color: { bg: '#fed7d7', text: '#c53030' },
    code: `curl -X POST http://localhost:3001/api/sap/mm/purchase-requisition/approval \\
  -H "Content-Type: application/json" \\
  -d '{
    "BANFN": "0010000002",
    "FRGST": "X",
    "ZZAPPROVER_ID": "ADMIN",
    "ZZAPPROVAL_NOTES": "Budget not available for Q1"
  }'`
  },
  {
    title: 'GET - Check PR Approval Status',
    color: { bg: '#bee3f8', text: '#2b6cb0' },
    code: `# Get approval status for specific PR
curl "http://localhost:3001/api/sap/mm/purchase-requisition/approval?BANFN=0010000002"

# Get all PRs with specific release status
curl "http://localhost:3001/api/sap/mm/purchase-requisition/approval?FRGST=R"`
  },
  {
    title: 'POST - Convert PR to PO (ME59N)',
    color: { bg: '#e9d8fd', text: '#553c9a' },
    code: `curl -X POST http://localhost:3001/api/sap/mm/purchase-order \\
  -H "Content-Type: application/json" \\
  -d '{
    "BANFN": "0010000001",
    "BNFPO": "00010",
    "LIFNR": "VENDOR001"
  }'

# Response includes:
# - EBELN: Generated PO Number
# - EBELP: PO Item Number
# - ZZSAP_DOC_NO: SAP Document Reference
# - PR status updated to "C" (Converted)`
  },
];

export default function PRSampleRequests() {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(450px, 1fr))', gap: '20px' }}>
      {sampleRequests.map((request, index) => (
        <div key={index} style={{
          background: '#fff',
          borderRadius: '8px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          overflow: 'hidden'
        }}>
          <div style={{ padding: '15px 20px', borderBottom: '1px solid #e2e8f0', background: request.color.bg }}>
            <h4 style={{ margin: 0, fontSize: '14px', color: request.color.text }}>{request.title}</h4>
          </div>
          <pre style={{
            margin: 0,
            padding: '15px 20px',
            background: '#1a202c',
            color: '#e2e8f0',
            fontSize: '11px',
            overflow: 'auto',
            maxHeight: '300px'
          }}>
            {request.code}
          </pre>
        </div>
      ))}
    </div>
  );
}
