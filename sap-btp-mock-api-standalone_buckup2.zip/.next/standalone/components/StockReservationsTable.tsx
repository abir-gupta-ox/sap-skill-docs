'use client';

import { SAPStockReservation } from '@/types/sap';

interface StockReservationsTableProps {
  stockReservations: SAPStockReservation[];
  loading: boolean;
  srCount: number;
}

const SAP_PLANTS: Record<string, string> = {
  'IST1': 'Terminal 1',
  'IST2': 'Terminal 2',
  'ISTC': 'Cargo Terminal',
  'ISTM': 'Maintenance',
  'ISTR': 'Runway Ops',
};

const formatSAPDate = (sapDate?: string): string => {
  if (!sapDate || sapDate.length !== 8) return '-';
  const year = sapDate.substring(0, 4);
  const month = sapDate.substring(4, 6);
  const day = sapDate.substring(6, 8);
  return `${day}/${month}/${year}`;
};

export default function StockReservationsTable({
  stockReservations,
  loading,
  srCount
}: StockReservationsTableProps) {
  return (
    <div style={{
      background: '#fff',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
      overflow: 'hidden',
      marginBottom: '30px'
    }}>
      <div style={{
        padding: '15px 20px',
        borderBottom: '1px solid #e2e8f0',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <h3 style={{ margin: 0, fontSize: '16px', color: '#2d3748' }}>Stock Reservations in Database</h3>
        <span style={{
          background: '#bee3f8',
          color: '#2b6cb0',
          padding: '4px 12px',
          borderRadius: '20px',
          fontSize: '13px',
          fontWeight: '500'
        }}>
          {srCount} records
        </span>
      </div>

      {loading ? (
        <div style={{ padding: '40px', textAlign: 'center', color: '#718096' }}>
          Loading stock reservations...
        </div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
            <thead>
              <tr style={{ background: '#f7fafc' }}>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Reservation</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Material</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Plant / SLoc</th>
                <th style={{ padding: '12px 16px', textAlign: 'right', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Quantity</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>Req Date</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: '600', color: '#4a5568', borderBottom: '2px solid #e2e8f0' }}>WO</th>
              </tr>
            </thead>
            <tbody>
              {stockReservations.length === 0 ? (
                <tr>
                  <td colSpan={6} style={{ padding: '30px', textAlign: 'center', color: '#718096' }}>
                    No stock reservations found. Create one using the API!
                  </td>
                </tr>
              ) : (
                stockReservations.map((sr) => (
                  <tr key={`${sr.RSNUM}-${sr.RSPOS}`} style={{ borderBottom: '1px solid #e2e8f0' }}>
                    <td style={{ padding: '12px 16px' }}>
                      <div style={{ fontFamily: 'monospace', fontSize: '12px', color: '#4a5568' }}>
                        {sr.RSNUM}
                      </div>
                      <div style={{ fontSize: '11px', color: '#a0aec0' }}>
                        Item {sr.RSPOS}
                      </div>
                    </td>
                    <td style={{ padding: '12px 16px', color: '#2d3748' }}>
                      {sr.MATNR ? (
                        <div style={{ fontFamily: 'monospace', fontSize: '12px' }}>
                          {sr.MATNR}
                        </div>
                      ) : (
                        <span style={{ color: '#a0aec0' }}>-</span>
                      )}
                    </td>
                    <td style={{ padding: '12px 16px', color: '#4a5568' }}>
                      <div>{sr.WERKS}</div>
                      <div style={{ fontSize: '11px', color: '#a0aec0' }}>
                        {SAP_PLANTS[sr.WERKS] || 'Plant'} / {sr.LGORT || '-'}
                      </div>
                    </td>
                    <td style={{ padding: '12px 16px', textAlign: 'right', fontFamily: 'monospace', color: '#4a5568' }}>
                      {sr.BDMNG} {sr.MEINS}
                    </td>
                    <td style={{ padding: '12px 16px', color: '#4a5568', fontSize: '13px' }}>
                      {formatSAPDate(sr.BDTER)}
                    </td>
                    <td style={{ padding: '12px 16px', color: '#4a5568', fontSize: '13px' }}>
                      {sr.AUFNR || '-'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
