'use client';

interface SampleRequest {
  title: string;
  color: { bg: string; text: string };
  code: string;
}

// Goods Receipt Sample Requests
const sampleRequests: SampleRequest[] = [
  {
    title: 'POST - Goods Receipt for Work Order (161)',
    color: { bg: '#fefcbf', text: '#975a16' },
    code: `curl -X POST http://localhost:3001/api/sap/mm/goods-movement \\
  -H "Content-Type: application/json" \\
  -H "X-SAP-User: OXMAINT_SYNC" \\
  -d '{
    "BWART": "161",
    "MATNR": "000000000010000001",
    "WERKS": "IST1",
    "LGORT": "WH01",
    "MENGE": 5,
    "MEINS": "EA",
    "AUFNR": "WO-2024-001234",
    "SGTXT": "BHS Conveyor Belt for maintenance",
    "ZZOXMAINT_WO_REF": "OXMAINT-WO-12345"
  }'`
  }
];

export default function GRSampleRequests() {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(450px, 1fr))', gap: '20px' }}>
      {sampleRequests.map((request, index) => (
        <div key={index} style={{
          background: '#fff',
          borderRadius: '8px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          overflow: 'hidden'
        }}>
          <div style={{ padding: '15px 20px', borderBottom: '1px solid #e2e8f0', background: request.color.bg }}>
            <h4 style={{ margin: 0, fontSize: '14px', color: request.color.text }}>{request.title}</h4>
          </div>
          <pre style={{
            margin: 0,
            padding: '15px 20px',
            background: '#1a202c',
            color: '#e2e8f0',
            fontSize: '11px',
            overflow: 'auto',
            maxHeight: '300px'
          }}>
            {request.code}
          </pre>
        </div>
      ))}
    </div>
  );
}
