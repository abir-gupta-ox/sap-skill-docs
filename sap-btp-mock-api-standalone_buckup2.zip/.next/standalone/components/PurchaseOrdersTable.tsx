'use client';

import { SAPPurchaseOrder } from '@/types/sap';

interface PurchaseOrdersTableProps {
  purchaseOrders: SAPPurchaseOrder[];
  loading: boolean;
  poCount: number;
}

const statusColors: Record<string, { bg: string; text: string }> = {
  'O': { bg: '#c6f6d5', text: '#22543d' },  // Open - Green
  'P': { bg: '#fefcbf', text: '#975a16' },  // Partially Delivered - Yellow
  'C': { bg: '#bee3f8', text: '#2b6cb0' },  // Completed - Blue
  'X': { bg: '#fed7d7', text: '#c53030' },  // Deleted - Red
  'B': { bg: '#e9d8fd', text: '#553c9a' },  // Blocked - Purple
};

const statusLabels: Record<string, string> = {
  'O': 'Open',
  'P': 'Partial',
  'C': 'Completed',
  'X': 'Deleted',
  'B': 'Blocked',
};

export default function PurchaseOrdersTable({ purchaseOrders, loading, poCount }: PurchaseOrdersTableProps) {
  return (
    <div style={{
      background: '#fff',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
      overflow: 'hidden',
      marginBottom: '30px'
    }}>
      <div style={{ padding: '15px 20px', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h3 style={{ margin: 0, fontSize: '16px', color: '#2d3748' }}>Purchase Orders (ME23N)</h3>
        <span style={{ background: '#edf2f7', padding: '4px 12px', borderRadius: '12px', fontSize: '14px', color: '#4a5568' }}>
          {poCount} records
        </span>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
          <thead>
            <tr style={{ background: '#f7fafc' }}>
              <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #e2e8f0', fontWeight: '600', color: '#4a5568' }}>PO Number</th>
              <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #e2e8f0', fontWeight: '600', color: '#4a5568' }}>Item</th>
              <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #e2e8f0', fontWeight: '600', color: '#4a5568' }}>Vendor</th>
              <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #e2e8f0', fontWeight: '600', color: '#4a5568' }}>Description</th>
              <th style={{ padding: '12px 15px', textAlign: 'right', borderBottom: '1px solid #e2e8f0', fontWeight: '600', color: '#4a5568' }}>Qty</th>
              <th style={{ padding: '12px 15px', textAlign: 'right', borderBottom: '1px solid #e2e8f0', fontWeight: '600', color: '#4a5568' }}>Net Value</th>
              <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #e2e8f0', fontWeight: '600', color: '#4a5568' }}>Plant</th>
              <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #e2e8f0', fontWeight: '600', color: '#4a5568' }}>PR Ref</th>
              <th style={{ padding: '12px 15px', textAlign: 'center', borderBottom: '1px solid #e2e8f0', fontWeight: '600', color: '#4a5568' }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={9} style={{ padding: '40px', textAlign: 'center', color: '#718096' }}>
                  Loading purchase orders...
                </td>
              </tr>
            ) : purchaseOrders.length === 0 ? (
              <tr>
                <td colSpan={9} style={{ padding: '40px', textAlign: 'center', color: '#718096' }}>
                  No purchase orders found. Convert a PR to PO to create one.
                </td>
              </tr>
            ) : (
              purchaseOrders.map((po, index) => {
                const status = po.STATU || 'O';
                const colors = statusColors[status] || statusColors['O'];
                return (
                  <tr key={index} style={{ borderBottom: '1px solid #e2e8f0' }}>
                    <td style={{ padding: '12px 15px' }}>
                      <code style={{ background: '#edf2f7', padding: '2px 6px', borderRadius: '4px', fontSize: '12px' }}>
                        {po.EBELN}
                      </code>
                    </td>
                    <td style={{ padding: '12px 15px', color: '#718096' }}>{po.EBELP}</td>
                    <td style={{ padding: '12px 15px', fontWeight: '500' }}>{po.LIFNR}</td>
                    <td style={{ padding: '12px 15px', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {po.TXZ01}
                    </td>
                    <td style={{ padding: '12px 15px', textAlign: 'right' }}>
                      {po.MENGE} {po.MEINS}
                    </td>
                    <td style={{ padding: '12px 15px', textAlign: 'right', fontWeight: '500' }}>
                      {po.NETWR?.toLocaleString()} {po.WAERS}
                    </td>
                    <td style={{ padding: '12px 15px' }}>{po.WERKS}</td>
                    <td style={{ padding: '12px 15px', color: '#718096', fontSize: '12px' }}>
                      {po.BANFN ? `${po.BANFN}/${po.BNFPO}` : '-'}
                    </td>
                    <td style={{ padding: '12px 15px', textAlign: 'center' }}>
                      <span style={{
                        background: colors.bg,
                        color: colors.text,
                        padding: '2px 8px',
                        borderRadius: '4px',
                        fontSize: '12px',
                        fontWeight: '500'
                      }}>
                        {statusLabels[status] || status}
                      </span>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
