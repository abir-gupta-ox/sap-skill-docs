// Cloud Foundry startup script with error logging
const path = require('path');

// Set the port from CF environment
process.env.PORT = process.env.PORT || 3001;
process.env.HOSTNAME = '0.0.0.0';

console.log('[Startup] Starting SAP BTP Mock API...');
console.log('[Startup] PORT:', process.env.PORT);
console.log('[Startup] NODE_ENV:', process.env.NODE_ENV);
console.log('[Startup] VCAP_APPLICATION:', process.env.VCAP_APPLICATION ? 'set' : 'not set');
console.log('[Startup] CWD:', process.cwd());

try {
  // Load the Next.js standalone server
  require('./.next/standalone/server.js');
} catch (error) {
  console.error('[Startup] Failed to start server:', error);
  process.exit(1);
}
