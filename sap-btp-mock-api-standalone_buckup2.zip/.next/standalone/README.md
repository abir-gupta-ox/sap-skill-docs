# SAP BTP Mock API

Mock SAP BTP API for OXmaint Material Master (MM) Integration.

## Local Development

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Server runs on http://localhost:3001
```

## API Endpoints

### Materials Management (MM)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/sap/mm/material` | List all materials |
| GET | `/api/sap/mm/material?material_number=XXX` | Get specific material |
| GET | `/api/sap/mm/material?plant=1000` | Filter by plant |
| GET | `/api/sap/mm/material?search=bearing` | Search materials |
| POST | `/api/sap/mm/material` | Create material (MM-001) |
| PUT | `/api/sap/mm/material` | Update material (MM-002) |
| DELETE | `/api/sap/mm/material?material_number=XXX` | Delete material |

### Health Check

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |

## Sample Requests

### Create Material (MM-001)

```bash
curl -X POST http://localhost:3001/api/sap/mm/material \
  -H "Content-Type: application/json" \
  -d '{
    "material_type": "ERSA",
    "material_group": "SPARE",
    "description": "Bearing Assembly SKF 6205",
    "base_unit": "EA",
    "plant": "1000",
    "storage_location": "0001",
    "safety_stock": 10,
    "reorder_point": 20,
    "planned_delivery_time": 5
  }'
```

### Response

```json
{
  "success": true,
  "message": "Material MAT-2024-0006 created successfully in SAP",
  "data": {
    "material_number": "MAT-2024-0006",
    "material_type": "ERSA",
    "material_group": "SPARE",
    "description": "Bearing Assembly SKF 6205",
    "base_unit": "EA",
    "plant": "1000",
    "storage_location": "0001",
    "mrp_type": "PD",
    "lot_size": "EX",
    "safety_stock": 10,
    "reorder_point": 20,
    "planned_delivery_time": 5,
    "created_at": "2024-01-20T10:30:00.000Z",
    "created_by": "OXMAINT_SYNC",
    "sap_document_number": "SAP-DOC-1705746600000-1234",
    "sync_status": "synced"
  },
  "sap_document_number": "SAP-DOC-1705746600000-1234",
  "timestamp": "2024-01-20T10:30:00.000Z"
}
```

## Valid Values

### Material Types
- `HAWA` - Trading Goods
- `FERT` - Finished Product
- `HALB` - Semi-Finished Product
- `ROH` - Raw Material
- `ERSA` - Spare Parts
- `NLAG` - Non-Stock Material
- `VERP` - Packaging Material

### Material Groups
- `SPARE` - Spare Parts
- `MAINT` - Maintenance Materials
- `TOOL` - Tools & Equipment
- `LUBR` - Lubricants
- `ELEC` - Electrical Components
- `MECH` - Mechanical Components
- `SAFE` - Safety Equipment
- `CONS` - Consumables

### Plants
- `1000` - Main Plant
- `1100` - Production Unit A
- `1200` - Production Unit B
- `2000` - Warehouse Central
- `3000` - Service Center

## Deploy to SAP BTP Cloud Foundry

### Prerequisites
1. SAP BTP Account with Cloud Foundry enabled
2. Cloud Foundry CLI installed
3. Node.js 18+

### Deployment Steps

```bash
# 1. Login to Cloud Foundry
cf login -a https://api.cf.us10.hana.ondemand.com

# 2. Build the application
npm run build

# 3. Deploy to SAP BTP
cf push

# Or use MTA deployment
mbt build
cf deploy mta_archives/sap-btp-mock-api_1.0.0.mtar
```

### Update manifest.yaml

Before deploying, update the route in `manifest.yaml` with your BTP subdomain:
```yaml
routes:
  - route: sap-btp-mock-api.cfapps.<your-region>.hana.ondemand.com
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| PORT | Server port | 3001 |
| NODE_ENV | Environment | development |

## Integration with OXmaint

Once deployed, update the OXmaint SAP integration settings:

1. Go to SAP Integration page
2. Update Configuration with your BTP API URL
3. Test connection using the Sync dialog

Example API URL: `https://sap-btp-mock-api.cfapps.us10.hana.ondemand.com`
